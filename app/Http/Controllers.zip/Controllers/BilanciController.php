<?php

namespace App\Http\Controllers;

ini_set('max_input_vars', 5000);

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests;
use App;
use Illuminate\Support\Facades\DB;
use lyquidity\xml\QName;
use lyquidity\XPath2\XPath2Exception;
use XBRL\XBRL_Instance;
use App\Models\Bilanci;
use App\Models\Account;
use App\Models\AnalisisType;
use function Livewire\str;

class BilanciController extends Controller
{

    /**
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $bilancis = Bilanci::paginate(25);

        return view('bilanci.index', compact('bilancis'));
    }

    /**
     * @return mixed
     */
    public function create()
    {

        $accounts = Account::pluck('name','id')->all();
        return view('bilanci.create', compact('accounts'));
    }


    /**
     * @return mixed
     */
    public function recap(Request $request)
    {
        global $use_xbrl_functions; $use_xbrl_functions = true;

        $jsonData = array();

        $file = $request->file()['xbrl'];
        $instance = null;

        $result = XBRL_Instance:: FromInstanceDocumentWithExtensionTaxonomy( $file->getPathName(),  __DIR__ . '/../../../../taxonomies/2018-11-04/itcc-ci-2018-11-04.xsd', 'XBRL', $instance );
        $contexts = ($result->getContexts()->getContexts());
//dd($contexts);
        ksort($contexts);
        $dSupport = array_keys($contexts);
        $iSupport = array_keys($contexts);

        foreach ($iSupport as $sup){
            if(str_contains($sup, 'd_') || str_contains($sup, '_d')){
                unset($iSupport[array_search($sup, $iSupport)]);
            }
        }

        $supp_i = array();
        foreach ($iSupport as $i){
            $supp_i[] = $i;
        }

//        dd($dSupport);

        foreach ($dSupport as $sup){
            if(str_contains($sup, 'i_') || str_contains($sup, '_i')){
                unset($dSupport[array_search($sup, $dSupport)]);
            }
        }

        $supp_d = array();
        foreach ($dSupport as $d){
            $supp_d[] = $d;
        }

//        dd($supp_i, $supp_d);
        //        dd($support);




        $currentCntxt_i = $supp_i[0];
        $prevCntxt_i = $supp_i[1];

        $currentCntxt_d = $supp_d[0];
        $prevCntxt_d = $supp_d[1];

        //dd($currentCntxt_i,  $prevCntxt_i, $currentCntxt_d, $prevCntxt_d);

//        dd($currentCntxt, $prevCntxt);
        $date = array();


        foreach ($contexts as $data=>$val){
            $date[] = $val['period']['startDate'];
            $date[] = $val['period']['endDate'];
//            dd($date);
        }
        $ordDate = array_reverse(array_unique($date, SORT_STRING));
        sort($ordDate);
        //dd($ordDate);

        $jsonData['prevYear'] = $ordDate[0].' '.$ordDate[1];
//        dd($jsonData['currentYear']);
        $jsonData['currentYear'] = $ordDate[2].' '.$ordDate[3];
        //dd($currentYear, $prevYear);
//        dd($jsonData['currentYear'], $jsonData['prevYear']);

        $elements = $result->getElements();
        $elements = $elements->getElements();
//	    dd($elements);

        foreach($elements as $elemento) {

            if (count($elemento)==2){
                $current = array_shift($elemento);
                $prev = array_shift($elemento);

                $valuePrev = 0;
                $valueCurr = 0;

                if(isset($current['value'])) {
                    $valueCurr = $current['value'];
                }

                if(isset($prev['value'])) {
                    $valuePrev = $prev['value'];
                }

                $jsonData['current'][$current['taxonomy_element']['name']] = $valueCurr;
                $jsonData['prev'][$prev['taxonomy_element']['name']] = $valuePrev;
            }

            if (count($elemento)==1){
                $data = array_shift($elemento);
//            dd($data);

                if (str_contains($data['contextRef'], $currentCntxt_d) || str_contains($data['contextRef'], $currentCntxt_i)){
                    $value = 0;
                    if(isset($data['value'])) {
                        $value = $data['value'];

                    }
                    if (is_numeric($value) && !(str_contains($data['taxonomy_element']['name'], 'Anagrafic'))){
                        $jsonData['current'][$data['taxonomy_element']['name']] = $value;
                    }
                    else{
                        $jsonData['anagrafic'][$data['taxonomy_element']['name']] = $value;
                    }
                }

                if (str_contains($data['contextRef'], $prevCntxt_d) || str_contains($data['contextRef'], $prevCntxt_i)){
                    $value = 0;
                    if(isset($data['value'])) {
                        $value = $data['value'];
                    }
                    if (is_numeric($value)){
                        $jsonData['prev'][$data['taxonomy_element']['name']] = $value;
                    }
                    else{
                        $jsonData['anagrafic'][$data['taxonomy_element']['name']] = $value;
                    }
                }


            }
        }

        $voci = DB::table('vocis')->get();
        $gradi = array();

        foreach ($voci as $voce){
            if ($voce->voce_padre == null || $voce->voce_padre == ""){
                $h1[$voce->name] = $voce->extended_name;
                $gradi[$voce->name] = [];
            }
            else {
                foreach ($voci as $voci1) {
                    if ($voce->voce_padre == $voci1->name) {
                        if ($voci1->voce_padre == null || $voci1->voce_padre == ""){
                            $gradi[$voci1->name][$voce->name] = [];
                        }
                        else{
                            foreach ($voci as $voci2) {
                                if ($voci1->voce_padre == $voci2->name) {
                                    if ($voci2->voce_padre == null || $voci2->voce_padre == "") {
                                        $gradi[$voci2->name][$voci1->name][$voce->name] = [];
                                    }
                                    else{
                                        foreach ($voci as $voci3) {
                                            if ($voci2->voce_padre == $voci3->name) {
                                                if ($voci3->voce_padre == null || $voci3->voce_padre == "") {
                                                    $gradi[$voci3->name][$voci2->name][$voci1->name][$voce->name] = [];
                                                }
                                                else{
                                                    foreach ($voci as $voci4) {
                                                        if ($voci3->voce_padre == $voci4->name) {
                                                            if ($voci4->voce_padre == null || $voci4->voce_padre == "") {
                                                                $gradi[$voci4->name][$voci3->name][$voci2->name][$voci1->name][$voce->name] = [];
                                                            }
                                                            else{
                                                                foreach ($voci as $voci5) {
                                                                    if ($voci4->voce_padre == $voci5->name) {
                                                                        if ($voci5->voce_padre == null || $voci5->voce_padre == "") {
                                                                            $gradi[$voci4->name][$voci4->name][$voci3->name][$voci2->name][$voci1->name][$voce->name] = [];
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }


        $vociExt = array();

        foreach ($voci as $voce){
            $vociExt[$voce->name] = $voce->extended_name;
        }

//	    dd($request->input('account_id'));
//        ksort($jsonData['current']);
        return view('bilanci.recap')->with(['jsonData' => $jsonData, 'gradi'=>$gradi, 'vociExt'=>$vociExt,'account_id' => $request->input('account_id')]);
    }



    /**
     * @return mixed
     */
    public function store(Request $request)
    {
//        dd($jsonData);
        $jsonData = array();
        $jsonDataPrev = array();
        $jsonDataAnag = array();

        foreach($request->input() as $singlereq => $singleValue) {
            if (stripos($singlereq, 'curr')){
                str_replace('Anagrafici', '', $singlereq);
                $jsonData[str_replace('_curr', '', $singlereq)] = $singleValue;
            }
            else if(stripos($singlereq, 'prev')){
                $jsonDataPrev[str_replace('_prev', '', $singlereq)] = $singleValue;
            }
            if (stripos($singlereq, 'anag')){
                $singlereq = str_replace('_curr', '', $singlereq);
                $jsonDataAnag[str_replace('_anag', '', $singlereq)] = $singleValue;
            }
        }

        $jsonDB = json_encode($jsonData);
        $jsonPrevDB = json_encode($jsonDataPrev);
        $jsonAnagDB = json_encode($jsonDataAnag);

        $accountId = $request->input('account_id');
        $currentYear = $request->input('currYear');
        $prevYear = $request->input('prevYear');

        $bilancio = Bilanci::create([
            'json_data' => $jsonDB,
            'account_id' => $accountId,
            'json_data_prev' => $jsonPrevDB,
            'json_data_anag' => $jsonAnagDB,
            'current_year' => $currentYear,
            'prev_year' => $prevYear,
            'year' => $currentYear,
        ]);



        return view('bilanci.store', $bilancio)->with(['jsonData' => $jsonData, 'jsonPrevDB'=>$jsonPrevDB, 'jsonAnagDB'=>$jsonAnagDB, 'currentYear'=>$currentYear, 'prevYear'=>$prevYear]);
    }


    /**
     * @param  User  $user
     *
     * @return mixed
     */
    public function show($id)
    {
        $bilancio = Bilanci::find($id);
        $attributes = $bilancio->getAttributes();

        $voci = DB::table('vocis')->get();
        $gradi = array();

        foreach ($voci as $voce){
            if ($voce->voce_padre == null || $voce->voce_padre == ""){
                $h1[$voce->name] = $voce->extended_name;
                $gradi[$voce->name] = [];
            }
            else {
                foreach ($voci as $voci1) {
                    if ($voce->voce_padre == $voci1->name) {
                        if ($voci1->voce_padre == null || $voci1->voce_padre == ""){
                            $gradi[$voci1->name][$voce->name] = [];
                        }
                        else{
                            foreach ($voci as $voci2) {
                                if ($voci1->voce_padre == $voci2->name) {
                                    if ($voci2->voce_padre == null || $voci2->voce_padre == "") {
                                        $gradi[$voci2->name][$voci1->name][$voce->name] = [];
                                    }
                                    else{
                                        foreach ($voci as $voci3) {
                                            if ($voci2->voce_padre == $voci3->name) {
                                                if ($voci3->voce_padre == null || $voci3->voce_padre == "") {
                                                    $gradi[$voci3->name][$voci2->name][$voci1->name][$voce->name] = [];
                                                }
                                                else{
                                                    foreach ($voci as $voci4) {
                                                        if ($voci3->voce_padre == $voci4->name) {
                                                            if ($voci4->voce_padre == null || $voci4->voce_padre == "") {
                                                                $gradi[$voci4->name][$voci3->name][$voci2->name][$voci1->name][$voce->name] = [];
                                                            }
                                                            else{
                                                                foreach ($voci as $voci5) {
                                                                    if ($voci4->voce_padre == $voci5->name) {
                                                                        if ($voci5->voce_padre == null || $voci5->voce_padre == "") {
                                                                            $gradi[$voci4->name][$voci4->name][$voci3->name][$voci2->name][$voci1->name][$voce->name] = [];
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }


        $vociExt = array();

        foreach ($voci as $voce){
            $vociExt[$voce->name] = $voce->extended_name;
        }

        $jsonData['current'] = json_decode($attributes['json_data'], true);
        $jsonData['prev'] = json_decode($attributes['json_data_prev'], true);
        $jsonData['anagrafic'] = json_decode($attributes['json_data_anag'], true);
        $jsonData['currentYear'] = $attributes['current_year'];
        $jsonData['prevYear'] = $attributes['prev_year'];
        return view('bilanci.show')->with(['jsonData' => $jsonData, 'vociExt'=>$vociExt, 'gradi'=>$gradi]);
    }

    /**
     * @param  DeleteUserRequest  $request
     * @param  User  $user
     *
     * @return mixed
     * @throws \App\Exceptions\GeneralException
     */
    public function destroy(Bilanci $bilancio)
    {
        $attributes = $bilancio->getAttributes();
        $idDel = $attributes['id'];
        $bilanciSing = Bilanci::find($idDel);
        $bilanciSing->delete(); //delete the client

        return redirect()->route('bilanci.index')->withFlashSuccess(__('The Bilancio was successfully deleted.'));
    }


    public function datatable() {

        $bilancis = Bilanci::paginate(25);

        return view('bilanci.datatable', compact('bilancis'));
    }

    public function delete($id){
        $bilancio = Bilanci::find($id);

        $bilancio->delete();
        return back();
    }

    public function showCurrent(Request $request) {

        $bilancioId = $request->input('bilancioId');
        $bilancio = Bilanci::where('id', $bilancioId)->get();
        $jsonData = $bilancio->jsonData;

        return view('bilanci.recap')->with(['jsonData' => $jsonData, 'account_id' => 0]);
    }
}
