<?php

namespace App\Http\Controllers;

ini_set('max_input_vars', 5000);

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Http\Requests;
use App;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use lyquidity\xml\QName;
use lyquidity\XPath2\XPath2Exception;
use PhpParser\Node\Stmt\Foreach_;
use Symfony\Component\Process\Exception\ProcessFailedException;
use XBRL\XBRL_Instance;
use App\Models\Bilanci;
use App\Models\Account;
use App\Models\cr;
use Symfony\Component\Process\Process;

class CentraleRischiController extends Controller
{

    public function truncateCR(){
        cr::truncate();


        return back();
    }

    /**
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $bilancis = Bilanci::paginate(25);

        return view('bilanci.index', compact('bilancis'));
    }

    /**
     * @return mixed
     */
    public function create()
    {
        $accounts = Account::pluck('name','id')->all();

        return view('centralerischi.create', compact('accounts'));
    }


    public function recap(Request $request)
    {
        $recordId = false;
        $extension = 'pdf';
        $filename = rand(11111111, 99999999) . '.' . $extension;
        $request->file('centrale_rischi')->move(
            base_path() . '/public/pdfcr/', $filename
        );
        $filePath = base_path() . '/public/pdfcr/' . $filename;
        $process = new Process(['sudo','python3', 'crExtractor.py',$filePath]);

        $process->setTimeout(10000);

        try {
            $process->run();
            if (!$process->isSuccessful()) {
                throw new ProcessFailedException($process);
            }
        } catch (ProcessFailedException $e) {
            dd($e);
        }

        if (!$process->isSuccessful()) {
            throw new ProcessFailedException($process);
        } else {


            $jsonData = $process->getOutput();

            $jsonArray = json_decode($jsonData);

//            dd($jsonArray);

            $crData = array();
            $currentMonth = false;
            $currentYear = false;
            $currentIntermediario = 'false';
            $currentCreditType = false;
            $currentCategoryArray = false;
            $currentGarante = false;

//            dd($jsonArray);

            foreach($jsonArray as $singleJsonArray) {
                foreach ($singleJsonArray as $key => $value) {
                    $cleanRow = (object)array_filter((array)$value, 'strlen');
                    foreach ($cleanRow as $singleRow) {
                        if (strpos($singleRow, 'DATA DI RIFERIMENTO:') !== false) {
                            $date = explode(' ', next($cleanRow));

                            $month = $date[0];
                            $year = $date[1];

                            if (!$currentYear || $year != $currentYear) {
                                $currentYear = $year;
                                if (!array_key_exists($year, $crData)) {
                                    $crData[$currentYear] = array();
                                }
                            }
                            if (!$currentMonth || $month != $currentMonth) {
                                $currentMonth = $month;
                            }
                            if (!array_key_exists($month, $crData[$currentYear])) {
                                $crData[$currentYear][$currentMonth] = array();
                            }
                        }
                        if ($singleRow == 'Intermediario:') {
                            $intermed = next($cleanRow);
                            if (!$currentIntermediario || $intermed != $currentIntermediario) {
                                $currentIntermediario = $intermed;

                                if(!array_key_exists($currentMonth, $crData[$currentYear])) {
                                    $crData[$currentYear][$currentMonth] = array();
                                    if (!array_key_exists($currentIntermediario, $crData[$currentYear][$currentMonth])) {
                                        $crData[$currentYear][$currentMonth][$currentIntermediario] = array();
                                    }
                                }
                            }
                        }
                        if (strpos($singleRow, 'Crediti per cassa') !== false) {
                            if (!$currentCreditType || $currentCreditType != 'Cassa') {
                                $currentCreditType = 'Cassa';
                                if (!array_key_exists($currentIntermediario, $crData[$currentYear][$currentMonth])) {
                                    $crData[$currentYear][$currentMonth][$currentIntermediario] = array();
                                    if (!array_key_exists($currentCreditType, $crData[$currentYear][$currentMonth][$currentIntermediario])) {
                                        $crData[$currentYear][$currentMonth][$currentIntermediario][$currentCreditType] = array();
                                    }
                                }
                            }
                        }
                        if (strpos($singleRow, 'Crediti di firma') !== false) {
                            if (!$currentCreditType || $currentCreditType != 'Firma') {
                                $currentCreditType = 'Firma';
                                if (!array_key_exists($currentIntermediario, $crData[$currentYear][$currentMonth])) {
                                    $crData[$currentYear][$currentMonth][$currentIntermediario] = array();
                                    if (!array_key_exists($currentCreditType, $crData[$currentYear][$currentMonth][$currentIntermediario])) {
                                        $crData[$currentYear][$currentMonth][$currentIntermediario][$currentCreditType] = array();
                                    }
                                }
                            }
                        }
                        if (strpos($singleRow, 'Sezione informativa') !== false) {
                            if (!$currentCreditType || $currentCreditType != 'Informativa') {
                                $currentCreditType = 'Informativa';
                                if (!array_key_exists($currentIntermediario, $crData[$currentYear][$currentMonth])) {
                                    $crData[$currentYear][$currentMonth][$currentIntermediario] = array();
                                    if (!array_key_exists($currentCreditType, $crData[$currentYear][$currentMonth][$currentIntermediario])) {
                                        $crData[$currentYear][$currentMonth][$currentIntermediario][$currentCreditType] = array();
                                    }
                                }
                            }
                        }
                        if (strpos($singleRow, 'Garanzie ricevute') !== false) {
                            if (!$currentCreditType || $currentCreditType != 'Garanzie') {
                                $currentCreditType = 'Garanzie';
                                if (!array_key_exists($currentIntermediario, $crData[$currentYear][$currentMonth])) {
                                    $crData[$currentYear][$currentMonth][$currentIntermediario] = array();
                                    if (!array_key_exists($currentCreditType, $crData[$currentYear][$currentMonth][$currentIntermediario])) {
                                        $crData[$currentYear][$currentMonth][$currentIntermediario][$currentCreditType] = array();
                                    }
                                }
                            }
                        }
                        if (strpos($singleRow, 'Sofferenze') !== false) {
                            if (!$currentCreditType || $currentCreditType != 'Sofferenze') {
                                $currentCreditType = 'Sofferenze';
                                if (!array_key_exists($currentIntermediario, $crData[$currentYear][$currentMonth])) {
                                    $crData[$currentYear][$currentMonth][$currentIntermediario] = array();
                                    if (!array_key_exists($currentCreditType, $crData[$currentYear][$currentMonth][$currentIntermediario])) {
                                        $crData[$currentYear][$currentMonth][$currentIntermediario][$currentCreditType] = array();
                                    }
                                }
                            }
                        }
                        if (strpos($singleRow, 'Categoria') !== false) {
                            $categoriaArray = array();
                            for ($i = 0; $i <= count((array)$cleanRow); $i++) {

                                $categoriaArray[next($cleanRow)] = array();
                            }
                            $currentCategoryArray = $categoriaArray;
                        }
                        if ((strpos($singleRow, 'RISCHI A') !== false && strlen($singleRow) < 20) || strpos($singleRow, 'GARANZIE CONNESSE') !== false || strpos($singleRow, 'SOFFERENZE') !== false || strpos($singleRow, 'CREDITI') !== false || strpos($singleRow, 'GARANZIE RICEVUTE') !== false) {
                            foreach ($currentCategoryArray as $arrKey => $arrValue) {
                                if ($arrKey == 'Categoria') {
                                    $currentCategoryArray['Categoria'] = $singleRow;
                                } else {
                                    $currentCategoryArray[$arrKey] = next($cleanRow);
                                }
                            }
                            $crData[$currentYear][$currentMonth][$currentIntermediario][$currentCreditType][] = $currentCategoryArray;
                        }
                        if (strpos($singleRow, 'codice censito') !== false) {
                            if (!$currentGarante || $currentGarante != $singleRow) {
                                $currentGarante = $singleRow;
                            }
                        }
                        if (strpos($singleRow, 'Valore Garanzia') !== false && strlen($singleRow) < 50) {
                            $valoreGaranzia = str_replace('Valore Garanzia', '', $singleRow);
                            $crData[$currentYear][$currentMonth][$currentIntermediario]['Garanti'][$currentGarante]['Valore Garanzie'] = trim($valoreGaranzia);
                        }

                        if (strpos($singleRow, 'Importo Garantito') !== false) {
                            $valoreGaranzia = str_replace('Importo Garantito', '', $singleRow);
                            $crData[$currentYear][$currentMonth][$currentIntermediario]['Garanti'][$currentGarante]['Importo Garantito'] = trim($valoreGaranzia);
                        }
                    }
                }
            }
            $cleanCR = $crData;
//            dd($cleanCR);
            $arraytmp = [];
            $tensioniAnnuali = array();
            $crediti_perdita = array();
            $sofferenze = array();
            $soldini = array();
            $sconfini = array();
            $yearlyDivision = array();
            $sconfiniPerAnniBanche= array();
            $tensioniLineCtredito = array();

//            dd($cleanCR['2017']['dicembre']);

//            dd($cleanCR);

            foreach ($cleanCR as $anno=>$months) {
                foreach ($months as $mese => $data) {
                    foreach ($data as $singleBank => $keys) {
                        foreach ($keys as $index => $value) {
                            if ($index == 'Firma'){
                                $array = $value;
                                foreach ($array as $key => $val) {
                                    foreach ($val as $chiave => $valore) {
                                        $chiave = str_replace(array("\r\n", "\n", "\r"), ' ', $chiave);
                                        $valore = str_replace(array("\r\n", "\n", "\r"), ' ', $valore);
                                        $arraytmp[$chiave] = $valore;
                                    }
                                    $categoria = $arraytmp['Categoria'];
                                    $accordato = str_replace('.', '', $arraytmp['Accordato']);
                                    $accordatoOperativo = str_replace('.', '', $arraytmp['Accordato Operativo']);
                                    $utilizzato = str_replace('.', '', $arraytmp['Utilizzato']);
                                    $durataResidua = isset($arraytmp['Durata Residua']) ? $arraytmp['Durata Residua'] : 'N/A';
                                    $durataOriginaria = isset($arraytmp['Durata Originaria']) ? $arraytmp['Durata Originaria'] : 'N/A';
                                    $localizzazione = isset($arraytmp['Localizzazione']) ? $arraytmp['Localizzazione'] : 'N/A';
                                    $divisa = isset($arraytmp['Divisa']) ? $arraytmp['Divisa'] : 'N/A';
                                    $tipoGaranzia = isset($arraytmp['Tipo Garanzia']) ? $arraytmp['Tipo Garanzia'] : 'N/A';
                                    $statoRapporto = isset($arraytmp['Stato Rapporto']) ? $arraytmp['Stato Rapporto'] : 'N/A';
                                    $tipoAttivita = isset($arraytmp['Tipo Attività']) ? $arraytmp['Tipo Attività'] : 'N/A';
                                    $ruoloAffidato = isset($arraytmp['Ruolo Affidato']) ? $arraytmp['Ruolo Affidato'] : 'N/A';
                                    $importExport = isset($arraytmp['Import Export']) ? $arraytmp['Import Export'] : 'N/A';
                                    $saldo_medio = isset($arraytmp['Saldo Medio']) ? $arraytmp['Saldo Medio'] : 'N/A';
                                    $saldo_medio = str_replace('.', '', $saldo_medio);
                                    $importo_garantito = isset($arraytmp['Importo Garantito']) ? $arraytmp['Importo Garantito'] : 'N/A';
                                    $importo_garantito = str_replace('.', '', $importo_garantito);


                                    $cr = new cr;

                                    $cr->anno = $anno;
                                    $cr->mese = $mese;
                                    $cr->account_id = 1;
                                    $cr->nome_banca = $singleBank;
                                    $cr->sezione = $index;
                                    $cr->categoria = $categoria;
                                    $cr->accordato = $accordato;
                                    $cr->accordato_operativo = $accordatoOperativo;
                                    $cr->utilizzato = $utilizzato;
                                    $cr->durata_residua = $durataResidua;
                                    $cr->durata_originaria = $durataOriginaria;
                                    $cr->localizzazione = $localizzazione;
                                    $cr->divisa = $divisa;
                                    $cr->tipo_garanzia = $tipoGaranzia;
                                    $cr->stato_rapporto = $statoRapporto;
                                    $cr->tipo_attivita = $tipoAttivita;
                                    $cr->ruolo_affidato = $ruoloAffidato;
                                    $cr->import_export = $importExport;
                                    $cr->saldo_medio = $saldo_medio;
                                    $cr->importo_garantito = $importo_garantito;
                                    $cr->save();
                                }
                            }
                            if ($index == 'Garanzie'){
                                $array = $value;
                                foreach ($array as $key => $val) {
                                    foreach ($val as $chiave => $valore) {
                                        $chiave = str_replace(array("\r\n", "\n", "\r"), ' ', $chiave);
                                        $valore = str_replace(array("\r\n", "\n", "\r"), ' ', $valore);
                                        $arraytmp[$chiave] = $valore;
                                    }
//                                    dump($arraytmp);
                                    $categoria = $arraytmp['Categoria'];
                                    $accordato = '';
                                    $accordatoOperativo = '';
                                    $utilizzato = '';
                                    $durataResidua = '';
                                    $durataOriginaria = '';
                                    $localizzazione = isset($arraytmp['Localizzazione']) ? $arraytmp['Localizzazione'] : 'N/A';
                                    $divisa = '';
                                    $tipoGaranzia = isset($arraytmp['Tipo Garanzia']) ? $arraytmp['Tipo Garanzia'] : 'N/A';
                                    $statoRapporto = isset($arraytmp['Stato Rapporto']) ? $arraytmp['Stato Rapporto'] : 'N/A';
                                    $tipoAttivita = '';
                                    $ruoloAffidato = '';
                                    $importExport = '';
                                    $saldo_medio = '';
                                    $importo_garantito = isset($arraytmp['Importo Garantito']) ? $arraytmp['Importo Garantito'] : 'N/A';
                                    $garantito = isset($arraytmp['Garantito']) ? $arraytmp['Garantito'] : 'N/A';
                                    $garanzia = isset($arraytmp['Valore Garanzia']) ? $arraytmp['Valore Garanzia'] : 'N/A';


                                    $cr = new cr;

                                    $cr->anno = $anno;
                                    $cr->mese = $mese;
                                    $cr->account_id = 1;
                                    $cr->nome_banca = $singleBank;
                                    $cr->sezione = $index;
                                    $cr->categoria = $categoria;
                                    $cr->accordato = $accordato;
                                    $cr->accordato_operativo = $accordatoOperativo;
                                    $cr->utilizzato = $utilizzato;
                                    $cr->durata_residua = $durataResidua;
                                    $cr->durata_originaria = $durataOriginaria;
                                    $cr->localizzazione = $localizzazione;
                                    $cr->divisa = $divisa;
                                    $cr->tipo_garanzia = $tipoGaranzia;
                                    $cr->stato_rapporto = $statoRapporto;
                                    $cr->tipo_attivita = $tipoAttivita;
                                    $cr->ruolo_affidato = $ruoloAffidato;
                                    $cr->import_export = $importExport;
                                    $cr->saldo_medio = $saldo_medio;
                                    $cr->importo_garantito = $importo_garantito;
                                    $cr->garantito = $garantito;
                                    $cr->garanzia = $garanzia;
                                    $cr->save();
                                }
                            }

                            if ($index == 'Sofferenze'){
                                $array = $value;
                                foreach ($array as $key => $val) {
                                    foreach ($val as $chiave => $valore) {
                                        $chiave = str_replace(array("\r\n", "\n", "\r"), ' ', $chiave);
                                        $valore = str_replace(array("\r\n", "\n", "\r"), ' ', $valore);
                                        $arraytmp[$chiave] = $valore;
                                    }
//                                    dump($arraytmp);
                                    $categoria = $arraytmp['Categoria'];
                                    $accordato = str_replace('.', '', $arraytmp['Accordato']);
                                    $accordatoOperativo = str_replace('.', '', $arraytmp['Accordato Operativo']);
                                    $utilizzato = str_replace('.', '', $arraytmp['Utilizzato']);
                                    $durataResidua = isset($arraytmp['Durata Residua']) ? $arraytmp['Durata Residua'] : 'N/A';
                                    $durataOriginaria = isset($arraytmp['Durata Originaria']) ? $arraytmp['Durata Originaria'] : 'N/A';
                                    $localizzazione = isset($arraytmp['Localizzazione']) ? $arraytmp['Localizzazione'] : 'N/A';
                                    $divisa = isset($arraytmp['Divisa']) ? $arraytmp['Divisa'] : 'N/A';
                                    $tipoGaranzia = isset($arraytmp['Tipo Garanzia']) ? $arraytmp['Tipo Garanzia'] : 'N/A';
                                    $statoRapporto = isset($arraytmp['Stato Rapporto']) ? $arraytmp['Stato Rapporto'] : 'N/A';
                                    $tipoAttivita = isset($arraytmp['Tipo Attività']) ? $arraytmp['Tipo Attività'] : 'N/A';
                                    $ruoloAffidato = isset($arraytmp['Ruolo Affidato']) ? $arraytmp['Ruolo Affidato'] : 'N/A';
                                    $importExport = isset($arraytmp['Import Export']) ? $arraytmp['Import Export'] : 'N/A';
                                    $saldo_medio = isset($arraytmp['Saldo Medio']) ? $arraytmp['Saldo Medio'] : 'N/A';
                                    $importo_garantito = isset($arraytmp['Importo Garantito']) ? $arraytmp['Importo Garantito'] : 'N/A';

                                    $cr = new cr;

                                    $cr->anno = $anno;
                                    $cr->mese = $mese;
                                    $cr->account_id = 1;
                                    $cr->nome_banca = $singleBank;
                                    $cr->sezione = $index;
                                    $cr->categoria = $categoria;
                                    $cr->accordato = $accordato;
                                    $cr->accordato_operativo = $accordatoOperativo;
                                    $cr->utilizzato = $utilizzato;
                                    $cr->durata_residua = $durataResidua;
                                    $cr->durata_originaria = $durataOriginaria;
                                    $cr->localizzazione = $localizzazione;
                                    $cr->divisa = $divisa;
                                    $cr->tipo_garanzia = $tipoGaranzia;
                                    $cr->stato_rapporto = $statoRapporto;
                                    $cr->tipo_attivita = $tipoAttivita;
                                    $cr->ruolo_affidato = $ruoloAffidato;
                                    $cr->import_export = $importExport;
                                    $cr->saldo_medio = $saldo_medio;
                                    $cr->importo_garantito = $importo_garantito;
                                    $cr->save();
                                }
                            }
                            if ($index == 'Cassa') {
                                $array = $value;
                                foreach ($array as $key => $val) {
                                    foreach ($val as $chiave => $valore) {
                                        $chiave = str_replace(array("\r\n", "\n", "\r"), ' ', $chiave);
                                        $valore = str_replace(array("\r\n", "\n", "\r"), ' ', $valore);
                                        $arraytmp[$chiave] = $valore;
                                    }
                                    $categoria = $arraytmp['Categoria'];
                                    $accordato = str_replace('.', '', $arraytmp['Accordato']);
                                    $accordatoOperativo = str_replace('.', '', $arraytmp['Accordato Operativo']);
                                    $utilizzato = str_replace('.', '', $arraytmp['Utilizzato']);
                                    $durataResidua = isset($arraytmp['Durata Residua']) ? $arraytmp['Durata Residua'] : '';
                                    $durataOriginaria = isset($arraytmp['Durata Originaria']) ? $arraytmp['Durata Originaria'] : '';
                                    $localizzazione = isset($arraytmp['Localizzazione']) ? $arraytmp['Localizzazione'] : '';
                                    $divisa = isset($arraytmp['Divisa']) ? $arraytmp['Divisa'] : '';
                                    $tipoGaranzia = isset($arraytmp['Tipo Garanzia']) ? $arraytmp['Tipo Garanzia'] : '';
                                    $statoRapporto = isset($arraytmp['Stato Rapporto']) ? $arraytmp['Stato Rapporto'] : '';
                                    $tipoAttivita = isset($arraytmp['Tipo Attività']) ? $arraytmp['Tipo Attività'] : '';
                                    $ruoloAffidato = isset($arraytmp['Ruolo Affidato']) ? $arraytmp['Ruolo Affidato'] : '';
                                    $importExport = isset($arraytmp['Import Export']) ? $arraytmp['Import Export'] : '';
                                    $saldo_medio = isset($arraytmp['Saldo Medio']) ? $arraytmp['Saldo Medio'] : 'N/A';
                                    $importo_garantito = isset($arraytmp['Importo Garantito']) ? $arraytmp['Importo Garantito'] : 'N/A';

                                    $cr = new cr;

                                    $cr->anno = $anno;
                                    $cr->mese = $mese;
                                    $cr->account_id = 1;
                                    $cr->nome_banca = $singleBank;
                                    $cr->sezione = $index;
                                    $cr->categoria = $categoria;
                                    $cr->accordato = $accordato;
                                    $cr->accordato_operativo = $accordatoOperativo;
                                    $cr->utilizzato = $utilizzato;
                                    $cr->durata_residua = $durataResidua;
                                    $cr->durata_originaria = $durataOriginaria;
                                    $cr->localizzazione = $localizzazione;
                                    $cr->divisa = $divisa;
                                    $cr->tipo_garanzia = $tipoGaranzia;
                                    $cr->stato_rapporto = $statoRapporto;
                                    $cr->tipo_attivita = $tipoAttivita;
                                    $cr->ruolo_affidato = $ruoloAffidato;
                                    $cr->import_export = $importExport;
                                    $cr->saldo_medio = $saldo_medio;
                                    $cr->importo_garantito = $importo_garantito;
                                    $cr->save();
                                }
                            }
                            if ($index == 'Informativa') {

                                $array = $value;
                                foreach ($array as $key => $val) {
                                    foreach ($val as $chiave => $valore) {
                                        $chiave = str_replace(array("\r\n", "\n", "\r"), ' ', $chiave);
                                        $valore = str_replace(array("\r\n", "\n", "\r"), ' ', $valore);
                                        $arraytmp[$chiave] = $valore;
                                    }
                                    $categoria = $arraytmp['Categoria'];
                                    $accordato = '';
                                    $accordatoOperativo = '';
                                    $utilizzato = '';
                                    $durataResidua = '';
                                    $durataOriginaria = '';
                                    $localizzazione = $arraytmp['Localizzazione'];
                                    $divisa = '';
                                    $tipoGaranzia = '';
                                    $statoRapporto = $arraytmp['Stato Rapporto'];
                                    $tipoAttivita = '';
                                    $ruoloAffidato = '';
                                    $importExport = '';
                                    $saldo_medio = isset($arraytmp['Saldo Medio']) ? $arraytmp['Saldo Medio'] : 'N/A';
                                    $importo_garantito = isset($arraytmp['Importo Garantito']) ? $arraytmp['Importo Garantito'] : 'N/A';
                                    if ($statoRapporto == 'Crediti impagati' || str_contains($categoria, 'A PERDITA')){
                                        $importo = isset($arraytmp['Importo']) ? $arraytmp['Importo'] : 'N/A';
                                        $importo_garantito = str_replace('.', '', $importo);
                                    }

                                    $cr = new cr;

                                    $cr->anno = $anno;
                                    $cr->mese = $mese;
                                    $cr->account_id = 1;
                                    $cr->nome_banca = $singleBank;
                                    $cr->sezione = $index;
                                    $cr->categoria = $categoria;
                                    $cr->accordato = $accordato;
                                    $cr->accordato_operativo = $accordatoOperativo;
                                    $cr->utilizzato = $utilizzato;
                                    $cr->durata_residua = $durataResidua;
                                    $cr->durata_originaria = $durataOriginaria;
                                    $cr->localizzazione = $localizzazione;
                                    $cr->divisa = $divisa;
                                    $cr->tipo_garanzia = $tipoGaranzia;
                                    $cr->stato_rapporto = $statoRapporto;
                                    $cr->tipo_attivita = $tipoAttivita;
                                    $cr->ruolo_affidato = $ruoloAffidato;
                                    $cr->import_export = $importExport;
                                    $cr->saldo_medio = $saldo_medio;
                                    $cr->importo_garantito = $importo_garantito;
                                    $cr->save();
                                }
                            }
                        }
                    }
                }
            }

            return Redirect::route('admin.cr.centralerischi.datatable');
        }
    }

    /**
     * @return mixed
     */
    public function store(Request $request)
    {
        $jsonData = array();
        foreach($request->input() as $singlereq => $singleValue) {
            $jsonData[$singlereq] = $singleValue;
        }

        $jsonDB = json_encode($jsonData);
        $accountId = $request->input('account_id');

        $bilancio = Bilanci::create([
            'name' => $jsonData['DatiAnagraficiDenominazione'],
            'json_data' => $jsonDB,
            'account_id' => $accountId,
        ]);

        return view('bilanci.store', $bilancio)->with(['jsonData' => $jsonData]);
    }




    /**
     * @param  DeleteUserRequest  $request
     * @param  User  $user
     *
     * @return mixed
     * @throws \App\Exceptions\GeneralException
     */
    public function destroy(Bilanci $bilancio)
    {
        $attributes = $bilancio->getAttributes();
        $idDel = $attributes['id'];
        $bilanciSing = Bilanci::find($idDel);
        $bilanciSing->delete(); //delete the client

        return redirect()->route('admin.bilanci.bilancio.index')->withFlashSuccess(__('The Bilancio was successfully deleted.'));
    }


    public function datatable() {

        $accounts = Account::All();
        $crs = cr::select('anno','mese')->get();
        $crData = array();

        $periods = array();
        $mesiList = [0=>'gennaio', 1=>'febbraio', 2=>'marzo',3=>'aprile' ,4=>'maggio', 5=>'giugno', 6=>'luglio', 7=>'agosto', 8=>'settembre', 9=>'ottobre', 10=>'novembre', 11=>'dicembre'];

        foreach ($crs as $data=>$value){
            $periods[$value->anno][$value->mese] = null;
            $periods[$value->anno][$value->mese] = array_search($value->mese, $mesiList);
            asort($periods[$value->anno]);
        }

        ksort($periods);

        return view('centralerischi.allcr',compact('periods', 'accounts', 'crData'));
    }

    public function crAndamentale(Request $request){

        $crAndamentaleData = $request->all();
        $periods = array();

        $mesiList = [0=>'gennaio', 1=>'febbraio', 2=>'marzo',3=>'aprile' ,4=>'maggio', 5=>'giugno', 6=>'luglio', 7=>'agosto', 8=>'settembre', 9=>'ottobre', 10=>'novembre', 11=>'dicembre'];

        foreach ($crAndamentaleData as $data=>$value){
            if (str_contains($data, 'token')){
            }
            else{
                $anno = explode('-',$data)[0];
                $mese = explode('-',$data)[1];
                $periods[$anno][$mese] = array_search($mese, $mesiList);
                asort($periods[$anno]);
            }
        }

        foreach ($periods as $anno=>$mesi){
            foreach ($mesi as $mese=>$index){
                $crs[$anno][$mese] = cr::where('anno',$anno)
                    ->where('mese',$mese)
                    ->get();
            }
        }

        $cleanCR = array();

        $rapportiContestati = 0;

        foreach ($crs as $anno=>$mesi){
            foreach ($mesi as $mese=>$items){
                foreach ($items as $item=>$data){
                    $tmp = array();

                    if ($data->categoria == 'GARANZIE RICEVUTE'){
                        $tmp['Localizzazione'] = $data->localizzazione;
                        $tmp['Stato Rapporto'] = $data->stato_rapporto;
                        $tmp['Tipo Garanzia'] = $data->tipo_garanzia;
                        $tmp['Importo Garantito'] = $data->importo_garantito;
                        $tmp['Valore Garanzia'] = $data->garanzia;
                        $tmp['Garantito'] = $data->garantito;


                        $cleanCR[$data->anno][$data->mese][$data->nome_banca][$data->sezione][$data->categoria][] = $tmp;
//                        dd($cleanCR);
                    }
                    else{
                        $tmp['Localizzazione'] = $data->localizzazione;
                        $tmp['Durata Originaria'] = $data->durata_originaria;
                        $tmp['Durata Residua'] = $data->durata_residua;
                        $tmp['Divisa'] = $data->divisa;
                        $tmp['Import Export'] = $data->import_export;
                        $tmp['Tipo Attività'] = $data->tipo_attivita;
                        $tmp['Stato Rapporto'] = $data->stato_rapporto;
                        $tmp['Tipo Garanzia'] = $data->tipo_garanzia;
                        $tmp['Ruolo Affidato'] = $data->ruolo_affidato;
                        $tmp['Accordato'] = $data->accordato;
                        $tmp['Accordato Operativo'] = $data->accordato_operativo;
                        $tmp['Utilizzato'] = $data->utilizzato;
                        $tmp['Saldo Medio'] = $data->saldo_medio;
                        $tmp['Importo Garantito'] = $data->importo_garantito;

                        $cleanCR[$data->anno][$data->mese][$data->nome_banca][$data->sezione][$data->categoria][] = $tmp;

                        if (!str_contains($data->stato_rapporto, 'non contestati') && str_contains($data->stato_rapporto, 'contestati')){
                            $rapportiContestati++;
                        }
                    }
                }
            }
        }

        $arrayIntermediari = array();
        $tensioniAnnuali = array();
        $crediti_perdita = array();
        $sofferenze = array();
        $soldini = array();
        $soldiniConMesi = array();
        $sconfini = array();
        $yearlyDivision = array();
        $sconfiniPerAnniBanche= array();
        $tensioniLineCtredito = array();
        $arrayImpagati = array();
        $arrayScaduti = array();
        $arrayContestati = array();

        $sconfiniAnnoMeseBanca = array();
        $arrayGaranzieRicevute = array();

//        dd($cleanCR);
        $support = array();
        $conteggioMesi = 0;

        foreach($cleanCR as $singleYearKey => $months) {
            $conteggioMesi = 0;
            foreach($months as $singleMonthKey => $banks) {
                $currentMonth = $singleMonthKey;
                if (!isset($prevMonth)){
                    $prevMonth = $currentMonth;
                }
                $conteggioMesi++;
                foreach($banks as $bankKey => $creditRow) {
                    $arrayIntermediari[$bankKey] = array();
                    foreach($creditRow as $singleCreditRowTypeKey => $singleCreditValue) {
                        if($singleCreditRowTypeKey == 'Cassa') {
                            foreach ($singleCreditValue as $credit=>$vals) {
                                foreach ($vals as $key=>$value){
                                $Categoria = $credit;
                                $localizzazione = $value['Localizzazione'];
                                $durataOriginaria = $value['Durata Originaria'];
                                $durataResidua = $value['Durata Residua'];
                                $divisa = $value['Divisa'];
                                $importExport = $value['Import Export'];
                                $tipoAttivita = $value['Tipo Attività'];
                                $statoRapporto = $value['Stato Rapporto'];
                                $tipoGaranzia = $value['Tipo Garanzia'];
                                $ruoloAffidato = $value['Ruolo Affidato'];
                                $accordato = $value['Accordato'];
                                $accordatoOperativo = $value['Accordato Operativo'];
                                $utilizzato = $value['Utilizzato'];



                                $currentRow = $Categoria . ' ' . $accordato . ' ' . $accordatoOperativo . ' ' . $tipoGaranzia;

                                if (str_contains($statoRapporto, 'Rapporti contestati')){
                                    $arrayContestati[$singleYearKey][$singleMonthKey][$bankKey][$Categoria][$currentRow] = $utilizzato;
                                }

                                    $isSameRow = false;

                                if (isset($prevRow)) {
                                    if ($currentRow == $prevRow) {
                                        $isSameRow = true;
                                    }
                                }

                                if ($accordato != '') {

                                    if (!array_key_exists($singleYearKey, $sconfiniPerAnniBanche)) {
                                        $sconfiniPerAnniBanche[$singleYearKey] = array();
                                    }

                                    if (!array_key_exists($singleYearKey, $sconfiniAnnoMeseBanca)) {
                                        $sconfiniAnnoMeseBanca[$singleYearKey] = array();
                                    }

                                    if (!array_key_exists($singleMonthKey, $sconfiniAnnoMeseBanca[$singleYearKey])) {
                                        $sconfiniAnnoMeseBanca[$singleYearKey][$singleMonthKey] = array();
                                    }

                                    if (!array_key_exists($bankKey, $sconfiniPerAnniBanche[$singleYearKey])) {
                                        $sconfiniPerAnniBanche[$singleYearKey][$bankKey] = array();
                                    }

                                    if (!array_key_exists($bankKey, $sconfiniAnnoMeseBanca)) {
                                        $sconfiniAnnoMeseBanca[$singleYearKey][$singleMonthKey][$bankKey] = array();
                                    }

                                    if (!array_key_exists($credit, $sconfiniPerAnniBanche[$singleYearKey][$bankKey])) {
                                        $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria] = array();
                                    }

                                    if (!array_key_exists($credit, $sconfiniAnnoMeseBanca)) {
                                        $sconfiniAnnoMeseBanca[$singleYearKey][$singleMonthKey][$bankKey][$Categoria] = array();
                                    }

                                    if (!array_key_exists($currentRow, $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria])) {
                                        $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow] = array();
                                    }

                                    if (!array_key_exists($currentRow, $sconfiniAnnoMeseBanca)) {
                                        $sconfiniAnnoMeseBanca[$singleYearKey][$singleMonthKey][$bankKey][$Categoria][$currentRow]['Presenza'] = false;
                                        $sconfiniAnnoMeseBanca[$singleYearKey][$singleMonthKey][$bankKey][$Categoria][$currentRow]['Utilizzato'] = 0;
                                        $sconfiniAnnoMeseBanca[$singleYearKey][$singleMonthKey][$bankKey][$Categoria][$currentRow]['Accordato Operativo'] = 0;
                                    }

                                }

                                if ($utilizzato > $accordatoOperativo) {
                                    // PER BANCHE ANNI

                                    $sconfiniAnnoMeseBanca[$singleYearKey][$singleMonthKey][$bankKey][$Categoria][$currentRow]['Presenza'] = true;
                                    $sconfiniAnnoMeseBanca[$singleYearKey][$singleMonthKey][$bankKey][$Categoria][$currentRow]['Utilizzato'] = $utilizzato;
                                    $sconfiniAnnoMeseBanca[$singleYearKey][$singleMonthKey][$bankKey][$Categoria][$currentRow]['Accordato Operativo'] = $accordatoOperativo;

                                    if (!$isSameRow){
                                        $valoriSconfiniMeseBanca[$singleYearKey][$currentMonth][$bankKey][$Categoria][$currentRow] = $accordato-$utilizzato;
                                    }

                                    if (!array_key_exists('TotaleSconfini', $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow])) {

                                        $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TotaleSconfini'] = 1;
                                        $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TensioneLineaCredito'] = false;

                                    } else {

//                                      //SE NON è SETTATA LA SETTO A 1, SE è SETTATA LA INCREMENTO DI 1

                                        if ($sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TotaleSconfini'] < 3) {

                                            //SE NON SIAMO IN SITUAZIONE DI TENSIONE

                                            $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TensioneLineaCredito'] = false;

                                        } else {

                                            //SE SIAMO IN TENSIONE, DICIAMO PER QUALE ANNO E LINEA DI CREDITO

                                            if (!array_key_exists($singleYearKey, $tensioniLineCtredito)) {

                                                $tensioniLineCtredito[$singleYearKey] = array();

                                            }

                                            $tensioniLineCtredito[$singleYearKey][$Categoria][$currentRow] = true;


                                            $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TensioneLineaCredito'] = true;

                                        }

                                        $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TotaleSconfini'] = ($sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TotaleSconfini'] + 1);
                                        if ($sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TotaleSconfini'] >= 3) {
                                            $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TensioneLineaCredito'] = true;
                                        }
                                    }

                                } else {

//                                    dump($sconfiniPerAnniBanche, $Categoria);

                                    if (!array_key_exists($Categoria, $sconfiniPerAnniBanche[$singleYearKey][$bankKey])){
                                        $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria] = array();
                                    }
                                    if (!array_key_exists('TotaleSconfini', $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow])) {

                                        $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TotaleSconfini'] = 0;
                                        $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TensioneLineaCredito'] = false;

                                    }

                                    if (!($sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TotaleSconfini'] >= 3)) {

                                        //SE NON SIAMO IN SITUAZIONE DI TENSIONE

                                        $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TensioneLineaCredito'] = false;

                                    } else {

                                        if (!array_key_exists($singleYearKey, $tensioniLineCtredito)) {

                                            $tensioniLineCtredito[$singleYearKey] = array();

                                        }

                                        $tensioniLineCtredito[$singleYearKey][$Categoria][$currentRow] = true;


                                        $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TensioneLineaCredito'] = true;

                                    }

                                }

                                //SE NON HO SCONFINATO
                                if (str_contains($Categoria, 'SCADENZA')) {
                                    if (isset($value['Tipo Attività'])) {
                                        $TipoAttività = $value['Tipo Attività'];
                                    }
                                }
                                $prevRow = $Categoria . ' ' . $accordato . ' ' . $accordatoOperativo . ' ' . $tipoGaranzia;

                                $prevRow = str_contains($Categoria, 'SCADENZA') ? $currentRow . ' ' . $tipoAttivita : $currentRow;
                                if (!$isSameRow) {
                                    $soldini[$singleYearKey][$bankKey][$currentRow]['Accordato Operativo'] = str_replace('.', '', $accordatoOperativo);
                                    $soldini[$singleYearKey][$bankKey][$currentRow]['Utilizzato'] = str_replace('.', '', $utilizzato);
                                    $soldiniConMesi[$singleYearKey][$singleMonthKey][$bankKey][$currentRow]['Accordato Operativo'] = str_replace('.', '', $accordatoOperativo);
                                    $soldiniConMesi[$singleYearKey][$singleMonthKey][$bankKey][$currentRow]['Utilizzato'] = str_replace('.', '', $utilizzato);
                                }
                            }
                            }
                        }
                        // IMPAGATI
                        if($singleCreditRowTypeKey == 'Informativa') {
                            foreach ($singleCreditValue as $credit=>$arrayValori) {
                                foreach ($arrayValori as $data=>$valori){
                                    if (isset($credit)) {
                                        if ($credit == 'SOFFERENZE - CREDITI PASSATI A PERDITA') {
                                            $crediti_perdita[$singleYearKey][$singleMonthKey][$bankKey] = $valori['Importo Garantito'];
                                        }
                                    }
                                    if ($credit == 'RISCHI AUTOLIQUIDANTI - CREDITI SCADUTI'){
                                        if ($valori['Stato Rapporto'] == 'Crediti impagati'){
                                        $arrayScaduti[$singleYearKey][$singleMonthKey][$bankKey][$valori['Stato Rapporto']] = $valori['Importo Garantito'];
                                        }
                                    }
                                    if (isset($valori['Stato Rapporto'])) {
                                        if ($valori['Stato Rapporto'] == 'Crediti impagati') {
                                            $arrayImpagati[$singleYearKey][$singleMonthKey][$bankKey][$valori['Importo Garantito']] = $valori['Importo Garantito'];
                                        }
                                    }
                                }
                            }
                        }
                        if($singleCreditRowTypeKey == 'Sofferenze') {
//                            dump($singleCreditValue);
                            foreach ($singleCreditValue as $credit=>$arrayValori) {
                                foreach ($arrayValori as $data=>$valori){
                                if (isset($credit)) {
//                                    dd($valori);
                                    $sofferenze[$singleYearKey][$singleMonthKey][$bankKey][$valori['Tipo Garanzia']] = $valori['Utilizzato'];
                                   }
                                }
                            }
                        }
                        if($singleCreditRowTypeKey == 'Garanzie') {
//                            dump($singleCreditValue);
                            foreach ($singleCreditValue as $credit=>$arrayValori) {
//                                dd($credit, $arrayValori);
                                foreach ($arrayValori as $data=>$valori){
//                                    dump($valori);
                                    if (isset($arrayGaranzieRicevute[$singleYearKey][$singleMonthKey][$bankKey])) {
                                        $arrayGaranzieRicevute[$singleYearKey][$singleMonthKey][$bankKey]['Importo Garantito'] = $valori['Importo Garantito'];
                                        $arrayGaranzieRicevute[$singleYearKey][$singleMonthKey][$bankKey]['Garantito'] = $valori['Garantito'];
                                        $arrayGaranzieRicevute[$singleYearKey][$singleMonthKey][$bankKey]['Stato Rapporto'] = $valori['Stato Rapporto'];
                                        $arrayGaranzieRicevute[$singleYearKey][$singleMonthKey][$bankKey]['Valore Garanzia'] = $valori['Valore Garanzia'];
                                        $arrayGaranzieRicevute[$singleYearKey][$singleMonthKey][$bankKey]['Tipo Garanzia'] = $valori['Tipo Garanzia'];
                                    }
                                    else if (isset($valori['Garantito'])){
                                        $arrayGaranzieRicevute[$singleYearKey][$singleMonthKey][$bankKey] = array();
                                        $arrayGaranzieRicevute[$singleYearKey][$singleMonthKey][$bankKey]['Importo Garantito'] = $valori['Importo Garantito'];
                                        $arrayGaranzieRicevute[$singleYearKey][$singleMonthKey][$bankKey]['Garantito'] = $valori['Garantito'];
                                        $arrayGaranzieRicevute[$singleYearKey][$singleMonthKey][$bankKey]['Stato Rapporto'] = $valori['Stato Rapporto'];
                                        $arrayGaranzieRicevute[$singleYearKey][$singleMonthKey][$bankKey]['Valore Garanzia'] = $valori['Valore Garanzia'];
                                        $arrayGaranzieRicevute[$singleYearKey][$singleMonthKey][$bankKey]['Tipo Garanzia'] = $valori['Tipo Garanzia'];
                                    }
                                }
                            }
                        }
                    }
                }
                $prevMonth = $currentMonth;
            }
        }

//        dd($valoriSconfiniMeseBanca);

        foreach ($soldini as $anno => $banca){
            foreach ($banca as $nomeBanca=>$val){
                foreach ($val as $data=>$value){
                    if (!isset($soldini[$anno][$nomeBanca]['Totale Accordato Operativo'])){
                        $soldini[$anno][$nomeBanca]['Totale Accordato Operativo'] = 0;
                        $soldini[$anno][$nomeBanca]['Totale Utilizzato'] = 0;
                    }
                    $soldini[$anno][$nomeBanca]['Totale Accordato Operativo'] += $value['Accordato Operativo'];
                    $soldini[$anno][$nomeBanca]['Totale Utilizzato'] += $value['Utilizzato'];
                }
            }
        }

        $sconfinoAnnuale = false;
        $arraySconfiniAnnuali = array();
        $conteggioSconfini = 0;


        foreach ($sconfiniPerAnniBanche as $anno => $arrayBanche){
            foreach ($arrayBanche as $nomeBanca=>$arrayRischi){
                foreach ($arrayRischi as $risk=> $righe) {
                    foreach ($righe as $row=>$tensione){
                        if ($tensione['TotaleSconfini'] > 0){
                            $sconfinoAnnuale = true;
                        }
                    }
                    if ($sconfinoAnnuale){
                        $arraySconfiniAnnuali[$anno][$risk] = true;
                        $sconfinoAnnuale = false;
                    }
                }
            }
        }

        $sconfiniGeneral = array();
        foreach($sconfiniPerAnniBanche as $singleYear => $banks) {
            foreach ($banks as $singleBank => $riskType) {
                foreach ($riskType as $singleRisk => $riskRow) {
                    foreach ($riskRow as $singleRiskRow => $riskData) {
                        $sconfiniGeneral[$singleYear][$singleBank][$singleRisk]['TotaleSconfini'] = 0;
                    }
                }
            }
        }

        $tensioniLine = array();
        foreach($sconfiniPerAnniBanche as $singleYear => $banks) {
            foreach ($banks as $singleBank => $riskType) {
                foreach ($riskType as $singleRisk => $riskRow) {
                    foreach ($riskRow as $singleRiskRow => $riskData) {
                        $sconfiniGeneral[$singleYear][$singleBank][$singleRisk]['TotaleSconfini'] = $sconfiniGeneral[$singleYear][$singleBank][$singleRisk]['TotaleSconfini']+$riskData['TotaleSconfini'];
                        if($riskData['TensioneLineaCredito']) {
                            $tensioniLine[$singleYear][$singleRisk] = true;
                        }
                    }
                }
            }
        }


        $firstYear = array_key_first($periods);

        $lastYear = array_key_last($periods);

        $inizioPeriodo = $firstYear.' '.array_key_first($periods[$firstYear]);
        $finePeriodo = $lastYear.' '.array_key_last($periods[$lastYear]);

        $presenzaEntro90gg = array();
        $presenzaEntro180gg = array();
        $presenzaOltre180gg = array();
        $presenzeGeneral = array();
        $sconfiniAnnoMese = array();
        $contMesi = 0;
        $contSconfini = array();
        $importoSconfini = array();

//        dd($sconfiniAnnoMeseBanca);

        foreach ($sconfiniAnnoMeseBanca as $anno=>$arrayMesi){
            if (!isset($contMesi)){
                $contMesi = 0;
            }
            foreach ($arrayMesi as $mese=>$arrayBanche){
                $contMesi++;
                foreach ($arrayBanche as $banca=>$lineeCredito){
                    foreach ($lineeCredito as $singolaLinea=>$rows){
                        foreach ($rows as $row=>$data){
                            if ($data['Presenza'] == true){
                                if (!isset($contSconfini[$anno][$banca][$singolaLinea][$row])){
                                    $contSconfini[$anno][$banca][$singolaLinea][$row] = 1;
                                }
                                else{
                                    $contSconfini[$anno][$banca][$singolaLinea][$row] = ($contSconfini[$anno][$banca][$singolaLinea][$row])+1;
                                }
                                if (isset($contSconfini[$anno][$banca][$singolaLinea][$row])){
                                    if ($contSconfini[$anno][$banca][$singolaLinea][$row] == $contMesi){
                                        $presenzaEntro90gg[$anno][$banca][$singolaLinea][$row]['Presenza'] = true;
                                        $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA MENO DI 90 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Utilizzato'] = $data['Utilizzato'];
                                        $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA MENO DI 90 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Importo Sconfinamento'] = $data['Accordato Operativo']-$data['Utilizzato'];

                                        if($data['Accordato Operativo'] == 0){
                                            $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA MENO DI 90 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Accordato nullo';
                                        }

                                        if ($singolaLinea == 'RISCHI A SCADENZA'){
                                            if (($data['Accordato Operativo'] / $data['Utilizzato']) < 1){
                                                $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA MENO DI 90 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Utilizzo anomalo, probabile errata segnalazione';
                                            }
                                            else if(($data['Accordato Operativo'] / $data['Utilizzato']) > 1){
                                                $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA MENO DI 90 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Presenza di rate insolute probabile errata segnalazione';
                                            }
                                        }

                                        if (str_contains($singolaLinea, 'RISCHI AUTOLIQUIDANTI')){
                                            if (($data['Utilizzato'] - $data['Accordato Operativo']) > 0){
                                                $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA MENO DI 90 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Sconfino da verificare, possibile errore di valuta';
                                            }
                                        }

                                    }
                                    if ($contMesi > 3){
                                        if ($contMesi > 6){
                                            if ($contSconfini[$anno][$banca][$singolaLinea][$row] == $contMesi){
                                                $presenzaOltre180gg[$anno][$banca][$singolaLinea][$row]['Presenza'] = true;
                                                //SEGNALINO
                                                $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Utilizzato'] = $data['Utilizzato'];
                                                $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Importo Sconfinamento'] = $data['Accordato Operativo']-$data['Utilizzato'];

                                                if($data['Accordato Operativo'] == 0){
                                                    $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Accordato nullo';
                                                }

                                                if ($singolaLinea == 'RISCHI A SCADENZA'){
                                                    if (($data['Accordato Operativo'] / $data['Utilizzato']) < 1){
                                                        $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Utilizzo anomalo, probabile errata segnalazione';
                                                    }
                                                    else if(($data['Accordato Operativo'] / $data['Utilizzato']) > 1){
                                                        $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Presenza di rate insolute probabile errata segnalazione';
                                                    }
                                                }

                                                if (str_contains($singolaLinea,'RISCHI AUTOLIQUIDANTI')){
                                                    if (($data['Utilizzato'] - $data['Accordato Operativo']) > 0){
                                                        $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Sconfino da verificare, possibile errore di valuta';
                                                    }
                                                }
                                            }
                                        }
                                        else if ($contSconfini[$anno][$banca][$singolaLinea][$row] == $contMesi){
                                            $presenzaEntro180gg[$anno][$banca][$singolaLinea][$row]['Presenza'] = true;
                                            $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 90 GIORNI E MENO DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Utilizzato'] = $data['Utilizzato'];
                                            $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 90 GIORNI E MENO DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Importo Sconfinamento'] = $data['Accordato Operativo']-$data['Utilizzato'];

                                            if($data['Accordato Operativo'] == 0){
                                                $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 90 GIORNI E MENO DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Accordato nullo';
                                            }

                                            if ($singolaLinea == 'RISCHI A SCADENZA'){
                                                if (($data['Accordato Operativo'] / $data['Utilizzato']) < 1){
                                                    $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 90 GIORNI E MENO DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Utilizzo anomalo, probabile errata segnalazione';
                                                }
                                                else if(($data['Accordato Operativo'] / $data['Utilizzato']) > 1){
                                                    $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 90 GIORNI E MENO DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Presenza di rate insolute probabile errata segnalazione';
                                                }
                                            }

                                            if (str_contains($singolaLinea,'RISCHI AUTOLIQUIDANTI')){
                                                if (($data['Utilizzato'] - $data['Accordato Operativo']) > 0){
                                                    $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 90 GIORNI E MENO DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Sconfino da verificare, possibile errore di valuta';
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        $analisiIndebitamento = array();
        $mediaAnalisiIndebitamento = array();

        foreach($soldiniConMesi as $singleYear=>$multipleMonths){
            foreach ($multipleMonths as $singleMonth=>$multipleBanks){
                foreach($multipleBanks as $singleBank=>$data) {
                    foreach ($data as $key=>$value){
                        if (str_contains($key, 'A SCADENZA')){
                            if (!isset($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A SCADENZA']['Accordato Operativo']) && !isset($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A SCADENZA']['Utilizzato'])){
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A SCADENZA']['Accordato Operativo'] = 0;
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A SCADENZA']['Utilizzato'] = 0;
                                $mediaAnalisiIndebitamento['RISCHI A SCADENZA']['Accordato Operativo'] = 0;
                                $mediaAnalisiIndebitamento['RISCHI A SCADENZA']['Utilizzato'] = 0;
                            }
                            else{
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A SCADENZA']['Accordato Operativo'] = ($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A SCADENZA']['Accordato Operativo'])+$value['Accordato Operativo'];
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A SCADENZA']['Utilizzato'] = ($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A SCADENZA']['Accordato Operativo'])+$value['Accordato Operativo'];
                                $mediaAnalisiIndebitamento['RISCHI A SCADENZA']['Accordato Operativo'] = ($mediaAnalisiIndebitamento['RISCHI A SCADENZA']['Accordato Operativo'])+$value['Accordato Operativo'];
                                $mediaAnalisiIndebitamento['RISCHI A SCADENZA']['Utilizzato'] = ($mediaAnalisiIndebitamento['RISCHI A SCADENZA']['Utilizzato'])+$value['Utilizzato'];
                            }
                        }
                        if (str_contains($key, 'A REVOCA')){
                            if (!isset($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A REVOCA']['Accordato Operativo']) && !isset($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A REVOCA']['Utilizzato'])){
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A REVOCA']['Accordato Operativo'] = 0;
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A REVOCA']['Utilizzato'] = 0;
                                $mediaAnalisiIndebitamento['RISCHI A REVOCA']['Accordato Operativo'] = 0;
                                $mediaAnalisiIndebitamento['RISCHI A REVOCA']['Utilizzato'] = 0;
                            }
                            else{
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A REVOCA']['Accordato Operativo'] = ($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A REVOCA']['Accordato Operativo'])+$value['Accordato Operativo'];
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A REVOCA']['Utilizzato'] = ($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A REVOCA']['Accordato Operativo'])+$value['Accordato Operativo'];
                                $mediaAnalisiIndebitamento['RISCHI A REVOCA']['Accordato Operativo'] = ($mediaAnalisiIndebitamento['RISCHI A REVOCA']['Accordato Operativo'])+$value['Accordato Operativo'];
                                $mediaAnalisiIndebitamento['RISCHI A REVOCA']['Utilizzato'] = ($mediaAnalisiIndebitamento['RISCHI A REVOCA']['Utilizzato'])+$value['Utilizzato'];
                            }
                        }
                        if (str_contains($key, 'AUTOLIQUIDANTI')){
                            if (!isset($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI AUTOLIQUIDANTI - CREDITI SCADUTI']['Accordato Operativo']) && !isset($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI AUTOLIQUIDANTI - CREDITI SCADUTI']['Utilizzato'])){
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI AUTOLIQUIDANTI - CREDITI SCADUTI']['Accordato Operativo'] = 0;
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI AUTOLIQUIDANTI - CREDITI SCADUTI']['Utilizzato'] = 0;
                                $mediaAnalisiIndebitamento['RISCHI AUTOLIQUIDANTI']['Accordato Operativo'] = 0;
                                $mediaAnalisiIndebitamento['RISCHI AUTOLIQUIDANTI']['Utilizzato'] = 0;
                            }
                            else{
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI AUTOLIQUIDANTI - CREDITI SCADUTI']['Accordato Operativo'] = ($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI AUTOLIQUIDANTI']['Accordato Operativo'])+$value['Accordato Operativo'];
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI AUTOLIQUIDANTI - CREDITI SCADUTI']['Utilizzato'] = ($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI AUTOLIQUIDANTI']['Accordato Operativo'])+$value['Accordato Operativo'];
                                $mediaAnalisiIndebitamento['RISCHI AUTOLIQUIDANTI']['Accordato Operativo'] = ($mediaAnalisiIndebitamento['RISCHI AUTOLIQUIDANTI']['Accordato Operativo'])+$value['Accordato Operativo'];
                                $mediaAnalisiIndebitamento['RISCHI AUTOLIQUIDANTI']['Utilizzato'] = ($mediaAnalisiIndebitamento['RISCHI AUTOLIQUIDANTI']['Utilizzato'])+$value['Utilizzato'];
                            }
                        }
                    }
                }
            }
        }

        $arraySofferenze = array();

        foreach ($sofferenze as $singoloAnno=>$arrayMesi){
            foreach ($arrayMesi as $singoloMese=>$arrayBanche){
                $arraySofferenze[$singoloAnno][$singoloMese] = 0;
                foreach ($arrayBanche as $rows){
                    foreach ($rows as $rowKey=>$rowValue){
                        $arraySofferenze[$singoloAnno][$singoloMese] = ($arraySofferenze[$singoloAnno][$singoloMese])+$rowValue;
                    }
                }
            }
        }

        $arrayCreditiPerdita = array();

        foreach ($crediti_perdita as $singoloAnno=>$arrayMesi){
            foreach ($arrayMesi as $singoloMese=>$arrayBanche){
                $arrayCreditiPerdita[$singoloAnno][$singoloMese] = 0;
                foreach ($arrayBanche as $singolaBanca=>$bancaValue){
                    $arrayCreditiPerdita[$singoloAnno][$singoloMese] = ($arrayCreditiPerdita[$singoloAnno][$singoloMese])+$bancaValue;
                }
            }
        }

        $mesiContestati = array();

        foreach ($arrayContestati as $singoloAnno=>$arrayMesi){
            foreach ($arrayMesi as $singoloMese=>$arrayBanche){
                $mesiContestati[$singoloAnno][$singoloMese] = 0;
                foreach ($arrayBanche as $singolaBanca=>$arrayCategoria){
                    foreach ($arrayCategoria as $singolaCategoria=>$multipleRows){
                        foreach ($multipleRows as $singleRow=>$data){
                            $mesiContestati[$singoloAnno][$singoloMese] = ($mesiContestati[$singoloAnno][$singoloMese])+$data;
                        }
                    }
                }
            }
        }

        $scadutiPerMese = array();
        $arrayImpagatiGeneral = array();

        foreach ($arrayScaduti as $singoloAnno=>$arrayMesi){
            foreach ($arrayMesi as $singoloMese=>$arrayBanche){
                $scadutiPerMese[$singoloAnno][$singoloMese] = 0;
                foreach ($arrayBanche as $singolaBanca=>$bancaValue){
                    $scadutiPerMese[$singoloAnno][$singoloMese] = ($scadutiPerMese[$singoloAnno][$singoloMese])+$bancaValue['Crediti impagati'];
                }
            }
        }

        foreach ($arrayImpagati as $singoloAnno=>$arrayMesi){
            foreach ($arrayMesi as $singoloMese=>$arrayBanche){
                $arrayImpagatiGeneral[$singoloAnno][$singoloMese] = 0;
                foreach ($arrayBanche as $singolaBanca=>$bancaValue){
                    foreach ($bancaValue as $key=>$val){
                        $arrayImpagatiGeneral[$singoloAnno][$singoloMese] = ($arrayImpagatiGeneral[$singoloAnno][$singoloMese])+$key;
                    }
                }
            }
        }

        foreach($mediaAnalisiIndebitamento as $singleLine=>$data){
            $mediaAnalisiIndebitamento[$singleLine]['Accordato Operativo'] = $data['Accordato Operativo']/$contMesi;
            $mediaAnalisiIndebitamento[$singleLine]['Utilizzato'] = $data['Utilizzato']/$contMesi;
        }

        $totaleSconfini = array();

        foreach($sconfiniAnnoMeseBanca as $singleYear=>$multipleMonths){
            foreach ($multipleMonths as $singleMonth=>$multipleBanks){
                foreach ($multipleBanks as $singleBank=>$multipleLines){
                    foreach ($multipleLines as $singleLine=>$multipleRows){
                        foreach ($multipleRows as $singleRow=>$data){
                            if (!isset($totaleSconfini[$singleLine])){
                                $totaleSconfini[$singleLine] = 0;
                            }
                            if ($data['Presenza'] == true){
                                $totaleSconfini[$singleLine] = ($totaleSconfini[$singleLine])+($data['Accordato Operativo']-$data['Utilizzato']);
                            }
                        }
                    }
                }
            }
        }

        foreach ($totaleSconfini as $singleLine=>$data){
            $mediaAnalisiIndebitamento[$singleLine]['Sconfinamenti'] = $data/$contMesi;
        }

        $arrayIndebitamentoEntro180 = array();
        $arrayIndebitamentoOltre180 = array();

        //        dd($importoSconfini);

        foreach ($importoSconfini as $differentPeriods=>$differentYears){
            if ($differentPeriods == 'ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 90 GIORNI E MENO DI 180 GIORNI'){
                foreach ($differentYears as $singleYear=>$multipleMonths){
                    foreach ($multipleMonths as $singleMonth=>$multipleBanks){
                        $arrayIndebitamentoEntro180[$singleYear][$singleMonth] = 0;
                        foreach ($multipleBanks as $singleBank=>$multipleCreditLines){
                            foreach ($multipleCreditLines as $singleLine=>$multipleRows){
                                foreach ($multipleRows as $singleRow=>$data){
                                    $arrayIndebitamentoEntro180[$singleYear][$singleMonth] = ($arrayIndebitamentoEntro180[$singleYear][$singleMonth]) + $data['Importo Sconfinamento'];
                                }
                            }
                        }
                    }
                }
            }
            if ($differentPeriods == 'ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 180 GIORNI'){
                foreach ($differentYears as $singleYear=>$multipleMonths){
                    foreach ($multipleMonths as $singleMonth=>$multipleBanks){
                        $arrayIndebitamentoEntro180[$singleYear][$singleMonth] = 0;
                        foreach ($multipleBanks as $singleBank=>$multipleCreditLines){
                            foreach ($multipleCreditLines as $singleLine=>$multipleRows){
                                foreach ($multipleRows as $singleRow=>$data){
                                    $arrayIndebitamentoOltre180[$singleYear][$singleMonth] = ($arrayIndebitamentoEntro180[$singleYear][$singleMonth]) + $data['Importo Sconfinamento'];
                                }
                            }
                        }
                    }
                }
            }
        }

        $tensioni = array();

//        dd($sconfiniPerAnniBanche);

        foreach ($sconfiniPerAnniBanche as $anno=>$banche){
            foreach ($banche as $banca=>$creditLines) {
                foreach ($creditLines as $lineaCredito=>$rows){
                    foreach ($rows as $row=>$value){
                        if (isset($value['TensioneLineaCredito']) && $value['TensioneLineaCredito'] == true){
                            $tensioni[$lineaCredito] = true;
                        }
                    }
                }
            }
        }

        $sconfiniScadenza = 0;
        $sconfiniRevoca = 0;
        $sconfiniAutoliquidanti = 0;

        foreach($sconfiniGeneral as $anno=>$banks){
            foreach ($banks as $banca=>$lineeCredito){
                foreach ($lineeCredito as $data=>$value){
                    if ($data == 'RISCHI A SCADENZA' && $value['TotaleSconfini'] != 0){
                        $sconfiniScadenza += $value['TotaleSconfini'];
                    }
                    if ($data == 'RISCHI A REVOCA' && $value['TotaleSconfini'] != 0){
                        $sconfiniRevoca += $value['TotaleSconfini'];
                    }
                    if ($data == 'RISCHI AUTOLIQUIDANTI' && $value['TotaleSconfini'] != 0){
                        $sconfiniAutoliquidanti += $value['TotaleSconfini'];
                    }
                }
            }
        }

        $presenzaSconfini = !(($sconfiniScadenza == 0 && $sconfiniRevoca == 0 && $sconfiniAutoliquidanti == 0));


        $scoreCR = 0;
        if (!isset($tensioni['RISCHI A REVOCA'])){
            $scoreCR += 0.55;
        }

        if (!isset($tensioni['RISCHI AUTOLIQUIDANTI'])){
            $scoreCR += 0.55;
        }

        if (!isset($tensioni['RISCHI A SCADENZA'])){
            $scoreCR += 0.55;
        }

        if (count($arrayImpagati)<1){
            $scoreCR += 1;
        }

        if (!$presenzaSconfini){
            $scoreCR += 1;
        }

        if (count($presenzaEntro180gg)<1){
            $scoreCR +=1.1;
        }

        if (count($presenzaOltre180gg)<1){
            $scoreCR += 1.2;
        }

        if (count($sofferenze)<1){
            $scoreCR += 1.35;
        }
        if (count($crediti_perdita)<1){
            $scoreCR += 1.35;
        }



        $latestYear = array_key_last($soldiniConMesi);
        $latestMonth = array_key_last($soldiniConMesi[$latestYear]);

        $soldiniLastMonth[$latestYear] = $soldiniConMesi[$latestYear][$latestMonth];

        foreach ($soldiniLastMonth as $anno => $banca){
            foreach ($banca as $nomeBanca=>$val){
                foreach ($val as $data=>$value){
                    if (!isset($soldiniLastMonth[$anno][$nomeBanca]['Totale Accordato Operativo'])){
                        $soldiniLastMonth[$anno][$nomeBanca]['Totale Accordato Operativo'] = 0;
                        $soldiniLastMonth[$anno][$nomeBanca]['Totale Utilizzato'] = 0;
                    }
                    $soldiniLastMonth[$anno][$nomeBanca]['Totale Accordato Operativo'] += $value['Accordato Operativo'];
                    $soldiniLastMonth[$anno][$nomeBanca]['Totale Utilizzato'] += $value['Utilizzato'];
                }
            }
        }

        return view('centralerischi.crandamentale',compact('mediaAnalisiIndebitamento','latestMonth','latestYear','soldiniLastMonth','arrayIntermediari','arrayImpagatiGeneral','scoreCR','presenzaSconfini','sconfiniAutoliquidanti','sconfiniRevoca','sconfiniScadenza','arrayIndebitamentoEntro180','arrayIndebitamentoOltre180','periods','scadutiPerMese','arrayImpagati', 'arraySofferenze', 'arrayCreditiPerdita', 'mesiContestati','sofferenze','crediti_perdita','arrayContestati','arrayScaduti','arrayImpagati','analisiIndebitamento','importoSconfini','presenzaEntro180gg','presenzaOltre180gg','crediti_perdita','sofferenze','sconfiniPerAnniBanche','rapportiContestati','arrayBanche','arrayImpagati','inizioPeriodo','finePeriodo','sconfiniGeneral','cleanCR','soldini','tensioniLineCtredito','arraySconfiniAnnuali','tensioniLine'));
    }
}
