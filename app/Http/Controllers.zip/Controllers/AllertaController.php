<?php

namespace App\Http\Controllers;

use App\Models\Account;
use App\Models\Analisi;
use App\Models\Bilanci;
use App\Models\indici;
use App\Models\range;
use App\Models\cr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AllertaController extends Controller
{

    public function questionarioSistemaAllerta(Request $request){
        $risposte = $request->all();

        $arrayRisposte = array();

        foreach ($risposte as $index=>$value){
            if (str_contains($index, '_desc')){
                $exploded = explode('_', $index);
                if (isset($risposte[$exploded[0].'_'.$exploded[1]])){
                    $arrayRisposte[$exploded[1]]['Esito'] = 'Si';
                    $arrayRisposte[$exploded[1]]['Motivazione'] = $value;
                }
                else{
                    $arrayRisposte[$exploded[1]]['Esito'] = 'No';
                    $arrayRisposte[$exploded[1]]['Motivazione'] = $value == null ? '' : $value ;
                }
            }
        }

        foreach ($arrayRisposte as $data=>$values){
            DB::table('questionario')
                ->where('parameter', $data)
                ->update(['result'=>$values['Esito'], 'details'=>$values['Motivazione'], 'date'=>date("Y/m/d")]);
        }

        return back();
    }


    public function forwardLooking(Request $request){
        $risposte = $request->all();

        DB::table('forwardLooking')->truncate();

        foreach ($risposte as $index=>$singleAnswer){
            if (str_contains($index,'forwardLooking')){
                DB::table('forwardLooking')->insert([
                    ['question'=>$index, 'answer'=>$singleAnswer,'date'=>date("Y/m/d")]
                ]);
            }
        }

        return back();
    }

    public function index(){
        $accounts =  Account::all();
        return view ('allerta.index', compact(['accounts']));
    }

    public function selezione(Request $request){
        $idAzienda = $request->input('account_id');
        $account = Account::find($idAzienda);
        $bilanci = Bilanci::where('account_id',$idAzienda)->get();
        $cr = DB::table('centralerischi')
            ->where('account_id',$idAzienda)
            ->get();

        return view('allerta.selezione',compact('account','bilanci','cr'));
    }

    public function analisi(Request $request){
        if (isset($questionario)){
            return view('allerta.questionario');
        }
        else{
            $accountId = $request->input('account_id');
            $bilanci = $request->input('multiselectBilanci');
            $centralirischi = $request->input('multiselectCR');
            foreach ($centralirischi as $data){
                $year = explode('_',$data)[0];
                $month = explode('_',$data)[1];
                $arrayCR[] = $this->analisiCR($year, $month);
            }

            foreach ($bilanci as $data=>$value){
                try {
                    $analisi = Analisi::where(['account_id'=>$accountId,'bilanci_id'=>$value])->get();
                    if (count($analisi) == 0){
                        Analisi::create(['account_id'=>$accountId,'bilanci_id'=>$value]);
                    }
                    $id = $analisi[0]->id;

                    $supporto = $this->analisiBilancio($id);


                    $anni = (Bilanci::where('id',$value)->get(['current_year']))[0]->current_year;
                    $date = explode(' ',$anni);
                    $anno = date('Y', strtotime($date[0]));

                    $analisiCompleta[$anno]['dataAnalisis'] = $supporto['dataAnalisis'];
                    $analisiCompleta[$anno]['indiciBilancio'] = $supporto['indiciBilancio'];

                    foreach ($analisiCompleta as $anno=>$array){
                        $basic[$anno]['PN NEGATIVO'] = $array['dataAnalisis']['PN_NEGATIVO'];
                        $basic[$anno]['OF RICAVI'] = $array['dataAnalisis']['OF_RICAVI'];
                        $basic[$anno]['ADEGUATEZZA PATRIMONIALE'] = $array['dataAnalisis']['ADEGUATEZZA_PATRIMONIALE'];
                        $basic[$anno]['RITORNO LIQUIDO ATTIVO'] = $array['dataAnalisis']['RITORNO_LIQUIDO_ATTIVO'];
                        $basic[$anno]["LIQUIDITA'"] = $array['dataAnalisis']['LIQUIDITA'];
                        $basic[$anno]["INDEBITAMENTO PREVIDENZIALE TRIBUTARIO"] = $array['dataAnalisis']['INDEBITAMENTO_PREVIDENZIALE_TRIBUTARIO'];

                        $advanced[$anno]['PN NEGATIVO'] = $array['dataAnalisis']['PN_NEGATIVO'];
                        $advanced[$anno]['ANDAMENTO DEL FATTURATO'] = $array['dataAnalisis']['Andamento_Del_Fatturato'];
                        $advanced[$anno]['ANDAMENTO DEL MOL'] = $array['dataAnalisis']['ANDAMENTO_DEL_MOL'];
                        $advanced[$anno]['ROI'] = $array['dataAnalisis']['ROI'];
                        $advanced[$anno]['ROS'] = $array['dataAnalisis']['ROS'];
                        $advanced[$anno]['ROE'] = $array['dataAnalisis']['ROE'];
                        $advanced[$anno]['EBITDA FATTURATO'] = $array['dataAnalisis']['EBITDA_FATTURATO'];
                        $advanced[$anno]['ANDAMENTO DEI MEZZI PROPRI'] = $array['dataAnalisis']['Andamento_Dei_Mezzi_Propri'];
                        $advanced[$anno]['MARGINE STRUTTURA PRIMARIO'] = $array['dataAnalisis']['Margine_Struttura_Primario'];
                        $advanced[$anno]['MARGINE STRUTTURA SECONDARIO SEMPLIFICATO'] = $array['dataAnalisis']['Margine_Struttura_Secondario_Semplificato'];
                        $advanced[$anno]['MARGINE STRUTTURA SECONDARIO ORDINARIO'] = $array['dataAnalisis']['Margine_Struttura_Secondario_Ordinario'];
                        $advanced[$anno]['ATTIVITA A BREVE PASSIVITA A BREVE SEMPLIFICATO'] = $array['dataAnalisis']['Attivita_a_breve_Passività_a_Breve_Semplificato'];
                        $advanced[$anno]['ATTIVITA A BREVE PASSIVITA A BREVE ORDINARIO'] = $array['dataAnalisis']['Attivita_a_breve_Passività_a_Breve_Ordinario'];
                        $advanced[$anno]['ACID TEST SEMPLIFICATO'] = $array['dataAnalisis']['ACID_TEST_Semplificato'];
                        $advanced[$anno]['ACID TEST ORDINARIO'] = $array['dataAnalisis']['ACID_TEST_Ordinario'];
                        $advanced[$anno]['ACID TEST'] = $array['dataAnalisis']['AcidTest'];
                        $advanced[$anno]['AUTONOMIA FINANZIARIA'] = $array['dataAnalisis']['AUTONOMIA_FINANZIARIA'];
                        $advanced[$anno]['LIVELLO INVESTIMENTI AZIENDALI'] = $array['dataAnalisis']['LIVELLO_INVESTIMENTI_AZIENDALI'];
                        $advanced[$anno]['PFN EBITDA'] = $array['dataAnalisis']['PFN_EBITDA'];
                        $advanced[$anno]['PESO ONERI FINANZIARI'] = $array['dataAnalisis']['Peso_Oneri_Finanziari'];
                        $advanced[$anno]['COPERTURA LORDA DEGLI ONERI FINANZIARI'] = $array['dataAnalisis']['Copertura_Lorda_degli_Oneri_Finanziari'];
                        $advanced[$anno]['EBIT OF'] = $array['dataAnalisis']['EBIT_OF'];
                        $advanced[$anno]['COSTO DEL PERSONALE'] = $array['dataAnalisis']['Costo_del_personale'];
                        $advanced[$anno]['CF ATTIVO'] = $array['dataAnalisis']['CF_ATTIVO'];
                        $advanced[$anno]['INDICE DI INDEBITAMENTO'] = $array['dataAnalisis']['Indice_di_Indebitamento'];
                        $advanced[$anno]['SALDO DEBITI VS FISCO'] = $array['dataAnalisis']['SALDO_DEBITI_VS_FISCO'];

                    }

                } catch (Exception $exception) {
                    var_dump( $exception->getMessage());exit;
                    return back()->withInput()
                        ->withErrors(['unexpected_error' => 'Unexpected error occurred while trying to process your request.']);
                }
            }
            return view('allerta.analisi', compact(['basic','advanced']));
        }

    }

    public function analisiBilancio($id)
    {

        $analisi = Analisi::with('bilanci')->with('account')->with('analisisType')->findOrFail($id);

        $bilancioJSON = json_decode($analisi->bilanci['json_data']);
        $bilancioJSONprev = json_decode($analisi->bilanci['json_data_prev']);
        $dataAnalisis = array();


        $TotaleAttivo = (isset($bilancioJSON->TotaleAttivo) ? $bilancioJSON->TotaleAttivo : 0);
        $CostiProduzioneAltriAccantonamenti = (isset($bilancioJSON->CostiProduzioneAltriAccantonamenti) ? $bilancioJSON->CostiProduzioneAltriAccantonamenti : 0);
        $CostiProduzioneAmmortamentiSvalutazioniTotaleAmmortamentiSvalutazioni = (isset($bilancioJSON->CostiProduzioneAmmortamentiSvalutazioniTotaleAmmortamentiSvalutazioni) ? $bilancioJSON->CostiProduzioneAmmortamentiSvalutazioniTotaleAmmortamentiSvalutazioni : 0);
        $TotaleCreditiVersoSociVersamentiAncoraDovuti = (isset($bilancioJSON->TotaleCreditiVersoSociVersamentiAncoraDovuti) ? $bilancioJSON->TotaleCreditiVersoSociVersamentiAncoraDovuti : 0);
        $TotalePatrimonioNetto = (isset($bilancioJSON->TotalePatrimonioNetto) ? $bilancioJSON->TotalePatrimonioNetto : 0);
        $PN_NEGATIVO = $TotalePatrimonioNetto-$TotaleCreditiVersoSociVersamentiAncoraDovuti;
        $dataAnalisis['PN_NEGATIVO'] = $PN_NEGATIVO;
        $DebitiAltriDebitiEsigibiliEntroEsercizioSuccessivo = (isset($bilancioJSON->DebitiAltriDebitiEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->DebitiAltriDebitiEsigibiliEntroEsercizioSuccessivo : $val = (isset($bilancioJSONprev->DebitiAltriDebitiEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSONprev->DebitiAltriDebitiEsigibiliEntroEsercizioSuccessivo : 0));
        $UtilePerditaEsercizio = (isset($bilancioJSON->UtilePerditaEsercizio) ? $bilancioJSON->UtilePerditaEsercizio : 0);

        // Valori bilancio
        // ### OF_RICAVI ###
        $ProventiOneriFinanziariInteressiAltriOneriFinanziariTotaleInteressiAltriOneriFinanziari = (isset($bilancioJSON->ProventiOneriFinanziariInteressiAltriOneriFinanziariTotaleInteressiAltriOneriFinanziari) ? $bilancioJSON->ProventiOneriFinanziariInteressiAltriOneriFinanziariTotaleInteressiAltriOneriFinanziari : 0);
        $ValoreProduzioneRicaviVenditePrestazioni = (isset($bilancioJSON->ValoreProduzioneRicaviVenditePrestazioni) ? $bilancioJSON->ValoreProduzioneRicaviVenditePrestazioni : 0);;
        $OF_RICAVI = number_format((float)($ProventiOneriFinanziariInteressiAltriOneriFinanziariTotaleInteressiAltriOneriFinanziari/$ValoreProduzioneRicaviVenditePrestazioni) * 100, 2, ',', '.');
        $dataAnalisis['OF_RICAVI'] = $OF_RICAVI.'%';

        // ### ADEGUATEZZA_PATRIMONIALE ###
        $TotaleDebiti = (isset($bilancioJSON->TotaleDebiti) ? $bilancioJSON->TotaleDebiti : 0);
        $PassivoRateiRisconti = (isset($bilancioJSON->PassivoRateiRisconti) ? $bilancioJSON->PassivoRateiRisconti : 0);
        $ADEGUATEZZA_PATRIMONIALE = number_format((float)($PN_NEGATIVO/($TotaleDebiti+$PassivoRateiRisconti)) * 100, 2, ',', '.');
        $dataAnalisis['ADEGUATEZZA_PATRIMONIALE'] = $ADEGUATEZZA_PATRIMONIALE.'%';

        // ### RITORNO_LIQUIDO_ATTIVO ###
        $DebitiEsigibiliEntroEsercizioSuccessivo = isset($bilancioJSON->DebitiEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->DebitiEsigibiliEntroEsercizioSuccessivo : 0;
        $TotaleDisponibilitaLiquide = (isset($bilancioJSON->TotaleDisponibilitaLiquide) ? $bilancioJSON->TotaleDisponibilitaLiquide : $val = (isset($bilancioJSONprev->TotaleDisponibilitaLiquide) ? $bilancioJSONprev->TotaleDisponibilitaLiquide : 0));
        $AttivoRateiRisconti = (isset($bilancioJSON->AttivoRateiRisconti) ? $bilancioJSON->AttivoRateiRisconti : 0);
        $TotaleAttivitaFinanziarieNonCostituisconoImmobilizzazioni = (isset($bilancioJSON->TotaleAttivitaFinanziarieNonCostituisconoImmobilizzazioni) ? $bilancioJSON->TotaleAttivitaFinanziarieNonCostituisconoImmobilizzazioni : 0);
        $TotaleRimanenze = (isset($bilancioJSON->TotaleRimanenze) ? $bilancioJSON->TotaleRimanenze : 0);
        $TotaleCrediti = (isset($bilancioJSON->TotaleCrediti) ? $bilancioJSON->TotaleCrediti : 0);
        $formula = ($TotaleRimanenze+$TotaleCrediti+$TotaleAttivitaFinanziarieNonCostituisconoImmobilizzazioni+$TotaleDisponibilitaLiquide+$AttivoRateiRisconti)/($DebitiEsigibiliEntroEsercizioSuccessivo+$PassivoRateiRisconti);
        $RITORNO_LIQUIDO_ATTIVO = number_format((float)$formula * 100, 2, ',', '.');
        $dataAnalisis['RITORNO_LIQUIDO_ATTIVO'] = $RITORNO_LIQUIDO_ATTIVO.'%';


        // ### LIQUIDITA ###
        $CostiProduzioneAccantonamentiRischi = (isset($bilancioJSON->CostiProduzioneAccantonamentiRischi) ? $bilancioJSON->CostiProduzioneAccantonamentiRischi : 0);
        $ProventiOneriFinanziariInteressiAltriOneriFinanziariTotaleInteressiAltriOneriFinanziari = $bilancioJSON->ProventiOneriFinanziariInteressiAltriOneriFinanziariTotaleInteressiAltriOneriFinanziari;
        $ValoreProduzioneRicaviVenditePrestazioni = $bilancioJSON->ValoreProduzioneRicaviVenditePrestazioni;
        $LIQUIDITA = number_format((float)(($UtilePerditaEsercizio+$CostiProduzioneAmmortamentiSvalutazioniTotaleAmmortamentiSvalutazioni+ $CostiProduzioneAccantonamentiRischi + $CostiProduzioneAltriAccantonamenti)/$TotaleAttivo), 2, ',', '.') ;
        $dataAnalisis['LIQUIDITA'] = $LIQUIDITA.'%';

        // ### INDEBITAMENTO_PREVIDENZIALE_TRIBUTARIO ###
        $ProventiOneriFinanziariInteressiAltriOneriFinanziariTotaleInteressiAltriOneriFinanziari = $bilancioJSON->ProventiOneriFinanziariInteressiAltriOneriFinanziariTotaleInteressiAltriOneriFinanziari;
        $ValoreProduzioneRicaviVenditePrestazioni = $bilancioJSON->ValoreProduzioneRicaviVenditePrestazioni;
        $INDEBITAMENTO_PREVIDENZIALE_TRIBUTARIO = number_format((float)$ProventiOneriFinanziariInteressiAltriOneriFinanziariTotaleInteressiAltriOneriFinanziari/$ValoreProduzioneRicaviVenditePrestazioni, 2, ',', '.');
        $dataAnalisis['INDEBITAMENTO_PREVIDENZIALE_TRIBUTARIO'] = $INDEBITAMENTO_PREVIDENZIALE_TRIBUTARIO;


        // INDICI ADVANCED

        //### Andamento del fatturato
        $ValoreProduzioneRicaviVenditePrestazioniCurr = (isset($bilancioJSON->ValoreProduzioneRicaviVenditePrestazioni) ? $bilancioJSON->ValoreProduzioneRicaviVenditePrestazioni : 0);
        $ValoreProduzioneRicaviVenditePrestazioniPrev = (isset($bilancioJSONprev->ValoreProduzioneRicaviVenditePrestazioni) ? $bilancioJSONprev->ValoreProduzioneRicaviVenditePrestazioni : 0);
        $AndamentoDelFatturato = number_format((float)(-(1-(($ValoreProduzioneRicaviVenditePrestazioniCurr)/($ValoreProduzioneRicaviVenditePrestazioniPrev)))) * 100, 2, ',', '.');
        $dataAnalisis['Andamento_Del_Fatturato'] = $AndamentoDelFatturato.'%';
        //        dd($AndamentoDelFatturato);

        // ANDAMENTO DEL MOL
        $TotaleValoreProduzione = (isset($bilancioJSON->TotaleValoreProduzione) ? $bilancioJSON->TotaleValoreProduzione : 0);
        $CostiProduzioneMateriePrimeSussidiarieConsumoMerci = (isset($bilancioJSON->CostiProduzioneMateriePrimeSussidiarieConsumoMerci) ? $bilancioJSON->CostiProduzioneMateriePrimeSussidiarieConsumoMerci : 0);
        $CostiProduzioneGodimentoBeniTerzi = (isset($bilancioJSON->CostiProduzioneGodimentoBeniTerzi) ? $bilancioJSON->CostiProduzioneGodimentoBeniTerzi : 0);
        $CostiProduzioneServizi = (isset($bilancioJSON->CostiProduzioneServizi) ? $bilancioJSON->CostiProduzioneServizi : 0);
        $CostiProduzionePersonaleTotaleCostiPersonale = (isset($bilancioJSON->CostiProduzionePersonaleTotaleCostiPersonale) ? $bilancioJSON->CostiProduzionePersonaleTotaleCostiPersonale : 0);
        $CostiProduzioneVariazioniRimanenzeMateriePrimeSussidiarieConsumoMerci = (isset($bilancioJSON->CostiProduzioneVariazioniRimanenzeMateriePrimeSussidiarieConsumoMerci) ? $bilancioJSON->CostiProduzioneVariazioniRimanenzeMateriePrimeSussidiarieConsumoMerci : 0);
        $CostiProduzioneOneriDiversiGestione = (isset($bilancioJSON->CostiProduzioneOneriDiversiGestione) ? $bilancioJSON->CostiProduzioneOneriDiversiGestione : 0);

        $TotaleValoreProduzionePrecedente = (isset($bilancioJSONprev->TotaleValoreProduzione) ? $bilancioJSONprev->TotaleValoreProduzione : 0);
        $CostiProduzioneMateriePrimeSussidiarieConsumoMerciPrecedente = (isset($bilancioJSONprev->CostiProduzioneMateriePrimeSussidiarieConsumoMerci) ? $bilancioJSONprev->CostiProduzioneMateriePrimeSussidiarieConsumoMerci : 0);
        $CostiProduzioneGodimentoBeniTerziPrecedente = (isset($bilancioJSONprev->CostiProduzioneGodimentoBeniTerzi) ? $bilancioJSONprev->CostiProduzioneGodimentoBeniTerzi : 0);
        $CostiProduzioneServiziPrecedente = (isset($bilancioJSONprev->CostiProduzioneServizi) ? $bilancioJSONprev->CostiProduzioneServizi : 0);
        $CostiProduzionePersonaleTotaleCostiPersonalePrecedente = (isset($bilancioJSONprev->CostiProduzionePersonaleTotaleCostiPersonale) ? $bilancioJSONprev->CostiProduzionePersonaleTotaleCostiPersonale : 0);
        $CostiProduzioneVariazioniRimanenzeMateriePrimeSussidiarieConsumoMerciPrecedente = (isset($bilancioJSONprev->CostiProduzioneVariazioniRimanenzeMateriePrimeSussidiarieConsumoMerci) ? $bilancioJSONprev->CostiProduzioneVariazioniRimanenzeMateriePrimeSussidiarieConsumoMerci : 0);
        $CostiProduzioneOneriDiversiGestionePrecedente = (isset($bilancioJSONprev->CostiProduzioneOneriDiversiGestione) ? $bilancioJSONprev->CostiProduzioneOneriDiversiGestione : 0);


        $MOLcurr = $TotaleValoreProduzione - $CostiProduzioneMateriePrimeSussidiarieConsumoMerci - $CostiProduzioneGodimentoBeniTerzi - $CostiProduzioneServizi - $CostiProduzionePersonaleTotaleCostiPersonale - $CostiProduzioneVariazioniRimanenzeMateriePrimeSussidiarieConsumoMerci - $CostiProduzioneOneriDiversiGestione;
        $MOLprev = $TotaleValoreProduzionePrecedente - $CostiProduzioneMateriePrimeSussidiarieConsumoMerciPrecedente - $CostiProduzioneGodimentoBeniTerziPrecedente - $CostiProduzioneServiziPrecedente - $CostiProduzionePersonaleTotaleCostiPersonalePrecedente - $CostiProduzioneVariazioniRimanenzeMateriePrimeSussidiarieConsumoMerciPrecedente - $CostiProduzioneOneriDiversiGestionePrecedente;

        $AndamentoMOL = -(1-($MOLcurr/$MOLprev));
        $dataAnalisis['ANDAMENTO_DEL_MOL'] = $AndamentoMOL;

        // ### ROI
        $DifferenzaValoreCostiProduzione = (isset($bilancioJSON->DifferenzaValoreCostiProduzione) ? $bilancioJSON->DifferenzaValoreCostiProduzione : 0);
        $ROI = number_format((float)($DifferenzaValoreCostiProduzione/$TotaleAttivo), 2, ',', '.');
        $dataAnalisis['ROI'] = $ROI.'%';

        // ### ROS
        $ROS = number_format((float)($DifferenzaValoreCostiProduzione/$ValoreProduzioneRicaviVenditePrestazioni), 2, ',', '.');
        $dataAnalisis['ROS'] = $ROS.'%';

        //### ROE
//        dd($UtilePerditaEsercizio);
        $ROE = number_format((float)($UtilePerditaEsercizio/$TotalePatrimonioNetto), 2, ',', '.');
        $dataAnalisis['ROE'] = $ROE.'%';

        //### EBITDA/Fatturato
        $EBITDA_FATTURATO = number_format((float)(($TotaleValoreProduzione-$CostiProduzioneMateriePrimeSussidiarieConsumoMerci-$CostiProduzioneServizi-$CostiProduzioneGodimentoBeniTerzi-$CostiProduzionePersonaleTotaleCostiPersonale-$CostiProduzioneVariazioniRimanenzeMateriePrimeSussidiarieConsumoMerci-$CostiProduzioneOneriDiversiGestione)/$ValoreProduzioneRicaviVenditePrestazioni), 2, ',', '.') ;
        $dataAnalisis['EBITDA_FATTURATO'] = $EBITDA_FATTURATO.'%';

        //### Andamento dei mezzi propri

        $TotalePatrimonioNettoCurr = (isset($bilancioJSON->TotalePatrimonioNetto) ? $bilancioJSON->TotalePatrimonioNetto : 0);
        $TotalePatrimonioNettoPrev = (isset($bilancioJSONprev->TotalePatrimonioNetto) ? $bilancioJSONprev->TotalePatrimonioNetto : 0);
        $AndamentoDeiMezziPropri = number_format((float)(($TotalePatrimonioNettoCurr/$TotalePatrimonioNettoPrev)-1), 2, ',', '.') ;
        $dataAnalisis['Andamento_Dei_Mezzi_Propri'] = $AndamentoDeiMezziPropri.'%';
//        dd($AndamentoDeiMezziPropri);

        //### Margine Struttura Primario
        $TotaleImmobilizzazioni = (isset($bilancioJSON->TotaleImmobilizzazioni) ? $bilancioJSON->TotaleImmobilizzazioni : 0);
        $Margine_Struttura_Primario = number_format((float)($TotalePatrimonioNetto/$TotaleImmobilizzazioni), 2, ',', '.') ;
        $dataAnalisis['Margine_Struttura_Primario'] = $Margine_Struttura_Primario.'%';

        //### Margine Struttura Secondario
        $TrattamentoFineRapportoLavoroSubordinato = (isset($bilancioJSON->TrattamentoFineRapportoLavoroSubordinato) ? $bilancioJSON->TrattamentoFineRapportoLavoroSubordinato : 0);
        $DebitiObbligazioniEsigibiliOltreEsercizioSuccessivo = (isset($bilancioJSON->DebitiObbligazioniEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSON->DebitiObbligazioniEsigibiliOltreEsercizioSuccessivo : 0);
        $DebitiObbligazioniConvertibiliEsigibiliOltreEsercizioSuccessivo = (isset($bilancioJSON->DebitiObbligazioniConvertibiliEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSON->DebitiObbligazioniConvertibiliEsigibiliOltreEsercizioSuccessivo : 0);
        $DebitiDebitiVersoSociFinanziamentiEsigibiliOltreEsercizioSuccessivo = (isset($bilancioJSON->DebitiDebitiVersoSociFinanziamentiEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSON->DebitiDebitiVersoSociFinanziamentiEsigibiliOltreEsercizioSuccessivo : $val = (isset($bilancioJSONprev->DebitiDebitiVersoSociFinanziamentiEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSONprev->DebitiDebitiVersoSociFinanziamentiEsigibiliOltreEsercizioSuccessivo : 0));
        $DebitiDebitiVersoBancheEsigibiliOltreEsercizioSuccessivo = (isset($bilancioJSON->DebitiDebitiVersoBancheEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSON->DebitiDebitiVersoBancheEsigibiliOltreEsercizioSuccessivo : 0);
        $DebitiDebitiVersoAltriFinanziatoriEsigibiliOltreEsercizioSuccessivo = (isset($bilancioJSON->DebitiDebitiVersoAltriFinanziatoriEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSON->DebitiDebitiVersoAltriFinanziatoriEsigibiliOltreEsercizioSuccessivo : 0);
        $DebitiAccontiEsigibiliOltreEsercizioSuccessivo = (isset($bilancioJSON->DebitiAccontiEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSON->DebitiAccontiEsigibiliOltreEsercizioSuccessivo : 0);
        $DebitiDebitiVersoFornitoriEsigibiliOltreEsercizioSuccessivo = (isset($bilancioJSON->DebitiDebitiVersoFornitoriEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSON->DebitiDebitiVersoFornitoriEsigibiliOltreEsercizioSuccessivo : 0);
        $DebitiDebitiRappresentatiTitoliCreditoEsigibiliOltreEsercizioSuccessivo = (isset($bilancioJSON->DebitiDebitiRappresentatiTitoliCreditoEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSON->DebitiDebitiRappresentatiTitoliCreditoEsigibiliOltreEsercizioSuccessivo : 0);
        $DebitiDebitiVersoImpreseControllateEsigibiliOltreEsercizioSuccessivo = (isset($bilancioJSON->DebitiDebitiVersoImpreseControllateEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSON->DebitiDebitiVersoImpreseControllateEsigibiliOltreEsercizioSuccessivo : 0);
        $DebitiDebitiVersoImpreseCollegateEsigibiliOltreEsercizioSuccessivo = (isset($bilancioJSON->DebitiDebitiVersoImpreseCollegateEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSON->DebitiDebitiVersoImpreseCollegateEsigibiliOltreEsercizioSuccessivo : 0);
        $DebitiDebitiVersoControllantiEsigibiliOltreEsercizioSuccessivo = (isset($bilancioJSON->DebitiDebitiVersoControllantiEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSON->DebitiDebitiVersoControllantiEsigibiliOltreEsercizioSuccessivo : 0);
        $DebitiDebitiVersoIstitutiPrevidenzaSicurezzaSocialeEsigibiliOltreEsercizioSuccessivo = (isset($bilancioJSON->DebitiDebitiVersoIstitutiPrevidenzaSicurezzaSocialeEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSON->DebitiDebitiVersoIstitutiPrevidenzaSicurezzaSocialeEsigibiliOltreEsercizioSuccessivo : 0);
        $DebitiAltriDebitiEsigibiliOltreEsercizioSuccessivo = (isset($bilancioJSON->DebitiAltriDebitiEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSON->DebitiAltriDebitiEsigibiliOltreEsercizioSuccessivo : $val = (isset($bilancioJSONprev->DebitiAltriDebitiEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSONprev->DebitiAltriDebitiEsigibiliOltreEsercizioSuccessivo : 0));
        $DebitiDebitiTributariEsigibiliOltreEsercizioSuccessivo = (isset($bilancioJSON->DebitiDebitiTributariEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSON->DebitiDebitiTributariEsigibiliOltreEsercizioSuccessivo : $val = (isset($bilancioJSONprev->DebitiDebitiTributariEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSONprev->DebitiDebitiTributariEsigibiliOltreEsercizioSuccessivo : 0));
        $DebitiEsigibiliOltreEsercizioSuccessivo = isset($bilancioJSON->DebitiEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSON->DebitiEsigibiliOltreEsercizioSuccessivo : 0;


        $QuarantaTre = $DebitiObbligazioniEsigibiliOltreEsercizioSuccessivo+$DebitiObbligazioniConvertibiliEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoSociFinanziamentiEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoBancheEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoAltriFinanziatoriEsigibiliOltreEsercizioSuccessivo+$DebitiAccontiEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoFornitoriEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiRappresentatiTitoliCreditoEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoImpreseControllateEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoImpreseCollegateEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoControllantiEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiTributariEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoIstitutiPrevidenzaSicurezzaSocialeEsigibiliOltreEsercizioSuccessivo+$DebitiAltriDebitiEsigibiliEntroEsercizioSuccessivo; //(isset($bilancioJSON->DebitiOltreEsercizioSuccessivo) ? $bilancioJSON->DebitiOltreEsercizioSuccessivo : 0);

        $Margine_Struttura_Secondario_Semplificato = number_format((float)(($TotalePatrimonioNetto+$TrattamentoFineRapportoLavoroSubordinato+$DebitiObbligazioniEsigibiliOltreEsercizioSuccessivo+$DebitiObbligazioniConvertibiliEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoSociFinanziamentiEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoBancheEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoAltriFinanziatoriEsigibiliOltreEsercizioSuccessivo+$DebitiAccontiEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoFornitoriEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiRappresentatiTitoliCreditoEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoImpreseControllateEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoImpreseCollegateEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoControllantiEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoIstitutiPrevidenzaSicurezzaSocialeEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiTributariEsigibiliOltreEsercizioSuccessivo+$DebitiAltriDebitiEsigibiliOltreEsercizioSuccessivo)/$TotaleImmobilizzazioni), 2, ',', '.') ;
        $Margine_Struttura_Secondario_Ordinario = number_format((float)(($TotalePatrimonioNetto+$TrattamentoFineRapportoLavoroSubordinato+$QuarantaTre)/$TotaleImmobilizzazioni), 2, ',', '.') ;
        $dataAnalisis['Margine_Struttura_Secondario_Semplificato'] = $Margine_Struttura_Secondario_Semplificato.'%';
        $dataAnalisis['Margine_Struttura_Secondario_Ordinario'] = $Margine_Struttura_Secondario_Ordinario.'%';
        // CURRENT RADIO (VEDI INDICE RITORNO LIQUIDO ATT)


        //### Attivita a breve / Passività a Breve
//        dd($bilancioJSON, $bilancioJSONprev);

        // TRENTACINQUE
        $CreditiVersoImpreseControllateEsigibiliEntroEsercizioSuccessivo = (isset($bilancioJSON->CreditiVersoImpreseControllateEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->CreditiVersoImpreseControllateEsigibiliEntroEsercizioSuccessivo : 0);
        $CreditiVersoImpreseCollegateEsigibiliEntroEsercizioSuccessivo = (isset($bilancioJSON->CreditiVersoImpreseCollegateEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->CreditiVersoImpreseCollegateEsigibiliEntroEsercizioSuccessivo : 0);
        $CreditiVersoControllantiEsigibiliEntroEsercizioSuccessivo = (isset($bilancioJSON->CreditiVersoControllantiEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->CreditiVersoControllantiEsigibiliEntroEsercizioSuccessivo : 0);
        $CreditiVersoControllantiEsigibiliOltreEsercizioSuccessivo = (isset($bilancioJSON->CreditiVersoControllantiEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSON->CreditiVersoControllantiEsigibiliOltreEsercizioSuccessivo : 0);
        $CreditiCreditiTributariEsigibiliEntroEsercizioSuccessivo = (isset($bilancioJSON->CreditiCreditiTributariEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->CreditiCreditiTributariEsigibiliEntroEsercizioSuccessivo : $val = (isset($bilancioJSONprev->CreditiCreditiTributariEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSONprev->CreditiCreditiTributariEsigibiliEntroEsercizioSuccessivo : 0));
        $CreditiVersoAltriEsigibiliEntroEsercizioSuccessivo = (isset($bilancioJSON->CreditiVersoAltriEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->CreditiVersoAltriEsigibiliEntroEsercizioSuccessivo : $val = (isset($bilancioJSONprev->CreditiVersoAltriEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSONprev->CreditiVersoAltriEsigibiliEntroEsercizioSuccessivo : 0));
        $TrentaCinque = $CreditiVersoImpreseControllateEsigibiliEntroEsercizioSuccessivo+$CreditiVersoImpreseCollegateEsigibiliEntroEsercizioSuccessivo+$CreditiVersoControllantiEsigibiliEntroEsercizioSuccessivo+$CreditiCreditiTributariEsigibiliEntroEsercizioSuccessivo+$CreditiVersoAltriEsigibiliEntroEsercizioSuccessivo;
        $CreditiCreditiTributariTotaleCreditiTributari = (isset($bilancioJSON->CreditiCreditiTributariTotaleCreditiTributari) ? $bilancioJSON->CreditiCreditiTributariTotaleCreditiTributari : $val = (isset($bilancioJSONprev->CreditiCreditiTributariTotaleCreditiTributari) ? $bilancioJSONprev->CreditiCreditiTributariTotaleCreditiTributari : 0));

        // QUARANTANOVE
        $DebitiObbligazioniConvertibiliEsigibiliEntroEsercizioSuccessivo = (isset($bilancioJSON->DebitiObbligazioniConvertibiliEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->DebitiObbligazioniConvertibiliEsigibiliEntroEsercizioSuccessivo : 0);
        $DebitiDebitiVersoSociFinanziamentiEsigibiliEntroEsercizioSuccessivo = (isset($bilancioJSON->DebitiDebitiVersoSociFinanziamentiEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->DebitiDebitiVersoSociFinanziamentiEsigibiliEntroEsercizioSuccessivo : 0);
        $DebitiDebitiVersoBancheEsigibiliEntroEsercizioSuccessivo = (isset($bilancioJSON->DebitiDebitiVersoBancheEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->DebitiDebitiVersoBancheEsigibiliEntroEsercizioSuccessivo : $val = (isset($bilancioJSONprev->DebitiDebitiVersoBancheEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSONprev->DebitiDebitiVersoBancheEsigibiliEntroEsercizioSuccessivo : 0));
        $DebitiDebitiVersoAltriFinanziatoriEsigibiliEntroEsercizioSuccessivo = (isset($bilancioJSON->DebitiDebitiVersoAltriFinanziatoriEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->DebitiDebitiVersoAltriFinanziatoriEsigibiliEntroEsercizioSuccessivo : 0);
        $DebitiAccontiEsigibiliEntroEsercizioSuccessivo = (isset($bilancioJSON->DebitiAccontiEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->DebitiAccontiEsigibiliEntroEsercizioSuccessivo : 0);
        $DebitiDebitiVersoFornitoriEsigibiliEntroEsercizioSuccessivo = (isset($bilancioJSON->DebitiDebitiVersoFornitoriEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->DebitiDebitiVersoFornitoriEsigibiliEntroEsercizioSuccessivo : $val = (isset($bilancioJSONprev->DebitiDebitiVersoFornitoriEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSONprev->DebitiDebitiVersoFornitoriEsigibiliEntroEsercizioSuccessivo : 0));
        $DebitiDebitiRappresentatiTitoliCreditoEsigibiliEntroEsercizioSuccessivo = (isset($bilancioJSON->DebitiDebitiRappresentatiTitoliCreditoEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->DebitiDebitiRappresentatiTitoliCreditoEsigibiliEntroEsercizioSuccessivo : 0);
        $DebitiDebitiVersoImpreseControllateEsigibiliEntroEsercizioSuccessivo = (isset($bilancioJSON->DebitiDebitiVersoImpreseControllateEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->DebitiDebitiVersoImpreseControllateEsigibiliEntroEsercizioSuccessivo : 0);
        $DebitiDebitiVersoImpreseCollegateEsigibiliEntroEsercizioSuccessivo = (isset($bilancioJSON->DebitiDebitiVersoImpreseCollegateEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->DebitiDebitiVersoImpreseCollegateEsigibiliEntroEsercizioSuccessivo : 0);
        $DebitiDebitiVersoControllantiEsigibiliEntroEsercizioSuccessivo = (isset($bilancioJSON->DebitiDebitiVersoControllantiEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->DebitiDebitiVersoControllantiEsigibiliEntroEsercizioSuccessivo : 0);
        $DebitiDebitiTributariEsigibiliEntroEsercizioSuccessivo = (isset($bilancioJSON->DebitiDebitiTributariEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->DebitiDebitiTributariEsigibiliEntroEsercizioSuccessivo : $val = (isset($bilancioJSONprev->DebitiDebitiTributariEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSONprev->DebitiDebitiTributariEsigibiliEntroEsercizioSuccessivo : 0));
        $DebitiDebitiVersoIstitutiPrevidenzaSicurezzaSocialeEsigibiliEntroEsercizioSuccessivo = (isset($bilancioJSON->DebitiDebitiVersoIstitutiPrevidenzaSicurezzaSocialeEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->DebitiDebitiVersoIstitutiPrevidenzaSicurezzaSocialeEsigibiliEntroEsercizioSuccessivo : $val = (isset($bilancioJSONprev->DebitiDebitiVersoIstitutiPrevidenzaSicurezzaSocialeEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSONprev->DebitiDebitiVersoIstitutiPrevidenzaSicurezzaSocialeEsigibiliEntroEsercizioSuccessivo : 0));
        $DebitiObbligazioniEsigibiliEntroEsercizioSuccessivo = (isset($bilancioJSON->DebitiObbligazioniEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->DebitiObbligazioniEsigibiliEntroEsercizioSuccessivo : 0);
        $QuarantaNove = $DebitiObbligazioniConvertibiliEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoSociFinanziamentiEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoBancheEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoAltriFinanziatoriEsigibiliEntroEsercizioSuccessivo+$DebitiAccontiEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoFornitoriEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiRappresentatiTitoliCreditoEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoImpreseControllateEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoImpreseCollegateEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoControllantiEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiTributariEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoIstitutiPrevidenzaSicurezzaSocialeEsigibiliEntroEsercizioSuccessivo+$DebitiAltriDebitiEsigibiliEntroEsercizioSuccessivo+$DebitiObbligazioniEsigibiliEntroEsercizioSuccessivo;
        $CreditiVersoClientiEsigibiliEntroEsercizioSuccessivo = (isset($bilancioJSON->CreditiVersoClientiEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->CreditiVersoClientiEsigibiliEntroEsercizioSuccessivo : 0);


        $Attivita_a_breve_Passivita_a_Breve_Semplificato = number_format((float)((($TotaleDisponibilitaLiquide+$TrentaCinque+$TotaleRimanenze+$TotaleAttivitaFinanziarieNonCostituisconoImmobilizzazioni+$AttivoRateiRisconti)/($QuarantaNove+$PassivoRateiRisconti))), 2, ',', '.') ;
        $Attivita_a_breve_Passivita_a_Breve_Ordinario = number_format((float)((($TotaleDisponibilitaLiquide+$CreditiVersoClientiEsigibiliEntroEsercizioSuccessivo+$CreditiVersoImpreseControllateEsigibiliEntroEsercizioSuccessivo+$CreditiVersoImpreseCollegateEsigibiliEntroEsercizioSuccessivo+$CreditiVersoControllantiEsigibiliEntroEsercizioSuccessivo+$CreditiCreditiTributariEsigibiliEntroEsercizioSuccessivo+$CreditiVersoAltriEsigibiliEntroEsercizioSuccessivo+$TotaleRimanenze+$TotaleAttivitaFinanziarieNonCostituisconoImmobilizzazioni+$AttivoRateiRisconti)/($DebitiObbligazioniConvertibiliEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoSociFinanziamentiEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoBancheEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoAltriFinanziatoriEsigibiliEntroEsercizioSuccessivo+$DebitiAccontiEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoFornitoriEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiRappresentatiTitoliCreditoEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoImpreseControllateEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoImpreseCollegateEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoControllantiEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiTributariEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoIstitutiPrevidenzaSicurezzaSocialeEsigibiliEntroEsercizioSuccessivo+$DebitiAltriDebitiEsigibiliEntroEsercizioSuccessivo+$DebitiObbligazioniEsigibiliEntroEsercizioSuccessivo+$PassivoRateiRisconti))), 2, ',', '.') ;
        $dataAnalisis['Attivita_a_breve_Passività_a_Breve_Semplificato'] = $Attivita_a_breve_Passivita_a_Breve_Semplificato.'%';
        $dataAnalisis['Attivita_a_breve_Passività_a_Breve_Ordinario'] = $Attivita_a_breve_Passivita_a_Breve_Ordinario.'%';

        // ACID TEST

        $AcidTest = number_format((float)(($TotaleCrediti + $TotaleAttivitaFinanziarieNonCostituisconoImmobilizzazioni + $TotaleDisponibilitaLiquide + $AttivoRateiRisconti)/($DebitiEsigibiliEntroEsercizioSuccessivo+$PassivoRateiRisconti)), 2, ',', '.') ;
        $ACID_TEST_Semplificato = number_format((float)((($TotaleDisponibilitaLiquide+$TrentaCinque+$TotaleRimanenze+$TotaleAttivitaFinanziarieNonCostituisconoImmobilizzazioni+$AttivoRateiRisconti-$TotaleRimanenze)/($QuarantaNove+$PassivoRateiRisconti))), 2, ',', '.') ;
        $ACID_TEST_Ordinario = number_format((float)((($TotaleDisponibilitaLiquide+$CreditiVersoClientiEsigibiliEntroEsercizioSuccessivo+$CreditiVersoImpreseControllateEsigibiliEntroEsercizioSuccessivo+$CreditiVersoImpreseCollegateEsigibiliEntroEsercizioSuccessivo+$CreditiVersoControllantiEsigibiliEntroEsercizioSuccessivo+$CreditiCreditiTributariEsigibiliEntroEsercizioSuccessivo+$CreditiVersoAltriEsigibiliEntroEsercizioSuccessivo+$TotaleRimanenze+$TotaleAttivitaFinanziarieNonCostituisconoImmobilizzazioni+$AttivoRateiRisconti-$TotaleRimanenze)/($DebitiObbligazioniConvertibiliEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoSociFinanziamentiEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoBancheEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoAltriFinanziatoriEsigibiliEntroEsercizioSuccessivo+$DebitiAccontiEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoFornitoriEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiRappresentatiTitoliCreditoEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoImpreseControllateEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoImpreseCollegateEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoControllantiEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiTributariEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoIstitutiPrevidenzaSicurezzaSocialeEsigibiliEntroEsercizioSuccessivo+$DebitiAltriDebitiEsigibiliEntroEsercizioSuccessivo+$DebitiObbligazioniEsigibiliEntroEsercizioSuccessivo+$PassivoRateiRisconti))), 2, ',', '.') ;
        $dataAnalisis['ACID_TEST_Semplificato'] = $ACID_TEST_Semplificato.'%';
        $dataAnalisis['ACID_TEST_Ordinario'] = $ACID_TEST_Ordinario.'%';
        $dataAnalisis['AcidTest'] = $AcidTest.'%';



        // AUTONOMIA FINANZIARIA
        $AUTONOMIA_FINANZIARIA = number_format((float)(($TotalePatrimonioNetto/($TotalePatrimonioNetto+$TotaleDebiti))), 2, ',', '.') ;
        $dataAnalisis['AUTONOMIA_FINANZIARIA'] = $AUTONOMIA_FINANZIARIA.'%';

        // LIVELLO INVESTIMENTI AZIENDALI
        $LIVELLO_INVESTIMENTI_AZIENDALI = number_format((float)($TotalePatrimonioNetto/$TotaleAttivo), 2, ',', '.') ;
        $dataAnalisis['LIVELLO_INVESTIMENTI_AZIENDALI'] = $LIVELLO_INVESTIMENTI_AZIENDALI.'%';

        // PFN / EBITDA
        $ImmobilizzazioniFinanziarieCreditiTotaleCrediti = (isset($bilancioJSON->ImmobilizzazioniFinanziarieCreditiTotaleCrediti) ? $bilancioJSON->ImmobilizzazioniFinanziarieCreditiTotaleCrediti : 0);
        $PFN_EBITDA = number_format((float)(($DebitiObbligazioniEsigibiliEntroEsercizioSuccessivo+$DebitiObbligazioniEsigibiliOltreEsercizioSuccessivo+$DebitiObbligazioniConvertibiliEsigibiliEntroEsercizioSuccessivo+$DebitiObbligazioniConvertibiliEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoSociFinanziamentiEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoSociFinanziamentiEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoSociFinanziamentiEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoBancheEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoBancheEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoAltriFinanziatoriEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoAltriFinanziatoriEsigibiliOltreEsercizioSuccessivo+$TotaleDisponibilitaLiquide+$ImmobilizzazioniFinanziarieCreditiTotaleCrediti)/($TotaleValoreProduzione+$CostiProduzioneMateriePrimeSussidiarieConsumoMerci+$CostiProduzioneServizi+$CostiProduzioneGodimentoBeniTerzi+$CostiProduzionePersonaleTotaleCostiPersonale+$CostiProduzioneVariazioniRimanenzeMateriePrimeSussidiarieConsumoMerci+$CostiProduzioneOneriDiversiGestione)), 2, ',', '.') ;
        $dataAnalisis['PFN_EBITDA'] = $PFN_EBITDA.'%';

        // Peso Oneri Finanziari (OF/Fatturato)
        $Peso_Oneri_Finanziari = number_format((float)($ProventiOneriFinanziariInteressiAltriOneriFinanziariTotaleInteressiAltriOneriFinanziari/$ValoreProduzioneRicaviVenditePrestazioni),  2, ',', '.');
        $dataAnalisis['Peso_Oneri_Finanziari'] = $Peso_Oneri_Finanziari.'%';

        // Copertura Lorda degli Oneri Finanziari
        $Copertura_Lorda_degli_Oneri_Finanziari = number_format((float)(($TotaleValoreProduzione-$CostiProduzioneMateriePrimeSussidiarieConsumoMerci-$CostiProduzioneServizi-$CostiProduzioneGodimentoBeniTerzi-$CostiProduzionePersonaleTotaleCostiPersonale-$CostiProduzioneVariazioniRimanenzeMateriePrimeSussidiarieConsumoMerci-$CostiProduzioneOneriDiversiGestione)/$ProventiOneriFinanziariInteressiAltriOneriFinanziariTotaleInteressiAltriOneriFinanziari), 2, ',', '.') ;
        $dataAnalisis['Copertura_Lorda_degli_Oneri_Finanziari'] = $Copertura_Lorda_degli_Oneri_Finanziari.'%';

        // EBIT / OF
//        dd($CostiProduzioneAccantonamentiRischi);
        $EBIT_OF = number_format((float)(($TotaleValoreProduzione-$CostiProduzioneMateriePrimeSussidiarieConsumoMerci-$CostiProduzioneServizi-$CostiProduzioneGodimentoBeniTerzi-$CostiProduzionePersonaleTotaleCostiPersonale-$CostiProduzioneVariazioniRimanenzeMateriePrimeSussidiarieConsumoMerci-$CostiProduzioneOneriDiversiGestione-$CostiProduzioneAmmortamentiSvalutazioniTotaleAmmortamentiSvalutazioni-$CostiProduzioneAccantonamentiRischi-$CostiProduzioneAltriAccantonamenti)/$ProventiOneriFinanziariInteressiAltriOneriFinanziariTotaleInteressiAltriOneriFinanziari), 2, ',', '.') ;
        $dataAnalisis['EBIT_OF'] = $EBIT_OF.'%';

        //Costo del personale
        $Costo_del_personale = number_format((float)($CostiProduzionePersonaleTotaleCostiPersonale/$ValoreProduzioneRicaviVenditePrestazioni), 2, ',', '.') ;
        $dataAnalisis['Costo_del_personale'] = $Costo_del_personale.'%';

        // CF / Attivo
        $CreditiImposteAnticipateTotaleImposteAnticipate = (isset($bilancioJSON->CreditiImposteAnticipateTotaleImposteAnticipate) ? $bilancioJSON->CreditiImposteAnticipateTotaleImposteAnticipate : 0);
        $CF_ATTIVO = number_format((float)(($UtilePerditaEsercizio+$CostiProduzioneAccantonamentiRischi+$CostiProduzioneAltriAccantonamenti+$CostiProduzioneAmmortamentiSvalutazioniTotaleAmmortamentiSvalutazioni+$CreditiImposteAnticipateTotaleImposteAnticipate)/$TotaleAttivo), 2, ',', '.') ;
        $dataAnalisis['CF_ATTIVO'] = $CF_ATTIVO.'%';

        //Indice di Indebitamento (PFN/PN)
        $Indice_di_Indebitamento = number_format((float)(($DebitiObbligazioniEsigibiliEntroEsercizioSuccessivo+$DebitiObbligazioniEsigibiliOltreEsercizioSuccessivo+$DebitiObbligazioniConvertibiliEsigibiliEntroEsercizioSuccessivo+$DebitiObbligazioniConvertibiliEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoSociFinanziamentiEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoSociFinanziamentiEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoBancheEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoBancheEsigibiliOltreEsercizioSuccessivo+$DebitiDebitiVersoAltriFinanziatoriEsigibiliEntroEsercizioSuccessivo+$DebitiDebitiVersoAltriFinanziatoriEsigibiliOltreEsercizioSuccessivo-$TotaleDisponibilitaLiquide-$ImmobilizzazioniFinanziarieCreditiTotaleCrediti)/$TotalePatrimonioNetto), 2, ',', '.') ;
        $dataAnalisis['Indice_di_Indebitamento'] = $Indice_di_Indebitamento.'%';

//        dd($bilancioJSON, $bilancioJSONprev);

        $indiciBilancio = array();

        //SALDO DEBITI VS FISCO

        $DebitiDebitiTributariTotaleDebitiTributariCorrente = (isset($bilancioJSON->DebitiDebitiTributariTotaleDebitiTributari) ? $bilancioJSON->DebitiDebitiTributariTotaleDebitiTributari : 0);
        $FondiRischiOneriTrattamentoQuiescenzaObblighiSimiliCorrente = (isset($bilancioJSON->FondiRischiOneriTrattamentoQuiescenzaObblighiSimili) ? $bilancioJSON->FondiRischiOneriTrattamentoQuiescenzaObblighiSimili : 0);
        $ImposteRedditoEsercizioCorrentiDifferiteAnticipateTotaleImposteRedditoEsercizioCorrentiDifferiteAnticipatePrecedente = isset($bilancioJSONprev->ImposteRedditoEsercizioCorrentiDifferiteAnticipateTotaleImposteRedditoEsercizioCorrentiDifferiteAnticipate) ? $bilancioJSONprev->ImposteRedditoEsercizioCorrentiDifferiteAnticipateTotaleImposteRedditoEsercizioCorrentiDifferiteAnticipate : 0;
        $ImposteRedditoEsercizioCorrentiDifferiteAnticipateTotaleImposteRedditoEsercizioCorrentiDifferiteAnticipate= isset($bilancioJSON->ImposteRedditoEsercizioCorrentiDifferiteAnticipateTotaleImposteRedditoEsercizioCorrentiDifferiteAnticipate) ? $bilancioJSON->ImposteRedditoEsercizioCorrentiDifferiteAnticipateTotaleImposteRedditoEsercizioCorrentiDifferiteAnticipate : 0;

        $DifferenzaImposteReddito = ($ImposteRedditoEsercizioCorrentiDifferiteAnticipateTotaleImposteRedditoEsercizioCorrentiDifferiteAnticipate + $ImposteRedditoEsercizioCorrentiDifferiteAnticipateTotaleImposteRedditoEsercizioCorrentiDifferiteAnticipatePrecedente)/2;
        $SaldoDebitiVSFisco = ($FondiRischiOneriTrattamentoQuiescenzaObblighiSimiliCorrente + $DebitiDebitiTributariTotaleDebitiTributariCorrente)/$DifferenzaImposteReddito;
        $dataAnalisis['SALDO_DEBITI_VS_FISCO'] = $SaldoDebitiVSFisco;

        //!!! INDICI DI BILANCIO !!!

        // ### QUANTITA' IMPORTANTI ###

        //CAPITALE PROPRIO O PATRIMONIO NETTO O MEZZI PROPRI
        $CapitaleProprioPatrimonioNettoMezziPropriCorrente = $TotalePatrimonioNettoCurr;
        $indiciBilancio['QUANTITA IMPORTANTI']['CAPITALE PROPRIO O PATRIMONIO NETTO O MEZZI PROPRI'] = number_format((float)($CapitaleProprioPatrimonioNettoMezziPropriCorrente), 2, ',', '.').'€' ;

        //CAPITALE DI TERZI

        $CapitaleDiTerzi = $TotaleDebiti;
        $indiciBilancio['QUANTITA IMPORTANTI']['CAPITALE DI TERZI'] = number_format((float)($CapitaleDiTerzi), 2, ',', '.').'€' ;

        //PASSIVITA' CONSOLIDATE

        $PassivitaConsolidate = $TrattamentoFineRapportoLavoroSubordinato + $DebitiEsigibiliOltreEsercizioSuccessivo;
        $indiciBilancio['QUANTITA IMPORTANTI']['PASSIVITA CONSOLIDATE'] = number_format((float)($PassivitaConsolidate), 2, ',', '.').'€' ;

        //PASSIVITA CORRENTI O CIRCOLANTI

        $PassivitaCorrentiCircolanti = $DebitiEsigibiliEntroEsercizioSuccessivo + $PassivoRateiRisconti;
        $indiciBilancio['QUANTITA IMPORTANTI']['PASSIVITA CORRENTI O CIRCOLANTI'] = number_format((float)($PassivitaCorrentiCircolanti), 2, ',', '.').'€';

        //ATTIVO IMMOBILIZZATO O IMMOBILIZZAZIONI NETTE

        $AttivoImmobilizzatoImmobilizzazioniNette = $TotaleImmobilizzazioni;
        $indiciBilancio['QUANTITA IMPORTANTI']['ATTIVO IMMOBILIZZATO O IMMOBILIZZAZIONI NETTE'] = number_format((float)($AttivoImmobilizzatoImmobilizzazioniNette), 2, ',', '.').'€' ;

        //ATTIVO CORRENTE
//dd($bilancioJSON, $bilancioJSONprev);
        $CreditiVersoAltriTotaleCreditiVersoAltri = isset($bilancioJSON->CreditiVersoAltriTotaleCreditiVersoAltri) ? $bilancioJSON->CreditiVersoAltriTotaleCreditiVersoAltri : $var = isset($bilancioJSONprev->CreditiVersoAltriTotaleCreditiVersoAltri)? $bilancioJSONprev->CreditiVersoAltriTotaleCreditiVersoAltri:0;
        $CreditiVersoClientiTotaleCreditiVersoClienti = isset($bilancioJSON->CreditiVersoClientiTotaleCreditiVersoClienti) ? $bilancioJSON->CreditiVersoClientiTotaleCreditiVersoClienti : 0;
        $AttivoCorrente = $TotaleDisponibilitaLiquide + $CreditiVersoAltriEsigibiliEntroEsercizioSuccessivo + $CreditiImposteAnticipateTotaleImposteAnticipate + $CreditiCreditiTributariTotaleCreditiTributari + $CreditiVersoControllantiEsigibiliEntroEsercizioSuccessivo + $CreditiVersoImpreseCollegateEsigibiliEntroEsercizioSuccessivo + $CreditiVersoImpreseControllateEsigibiliEntroEsercizioSuccessivo + $CreditiVersoClientiTotaleCreditiVersoClienti + $TotaleRimanenze+  $TotaleAttivitaFinanziarieNonCostituisconoImmobilizzazioni + $AttivoRateiRisconti;
        $indiciBilancio['QUANTITA IMPORTANTI']['ATTIVO CORRENTE'] = number_format((float)($AttivoCorrente), 2, ',', '.').'€';

        //TOTALE ATTIVITA O IMPIEGHI O CAPITALE INVESTITO

        $TotaleAttivitaImpieghiCapitaleInvestito = $TotaleAttivo;
        $indiciBilancio['QUANTITA IMPORTANTI']['TOTALE ATTIVITA O IMPIEGHI O CAPITALE INVESTITO'] = number_format((float)($TotaleAttivitaImpieghiCapitaleInvestito), 2, ',', '.').'€' ;

        //RIMANENZE

        $Rimanenze = $TotaleRimanenze;
        $indiciBilancio['QUANTITA IMPORTANTI']['RIMANENZE'] = number_format((float)($Rimanenze), 2, ',', '.').'€' ;

        //UTILE O REDDITO NETTO D'ESERCIZIO

        $UtileRedditoNettoEsercizio = $UtilePerditaEsercizio;
        $indiciBilancio['QUANTITA IMPORTANTI']['UTILE O REDDITO NETTO D ESERCIZIO'] = number_format((float)($UtileRedditoNettoEsercizio), 2, ',', '.').'€' ;

        //UTILE NON DISTRIBUITO O ALTRE RISERVE

        $PatrimonioNettoAltreRiserveDistintamenteIndicateTotaleAltreRiserve = (isset($bilancioJSON->PatrimonioNettoAltreRiserveDistintamenteIndicateTotaleAltreRiserve) ? $bilancioJSON->PatrimonioNettoAltreRiserveDistintamenteIndicateTotaleAltreRiserve : 0);

        $UtileNonDistribuitoAltreRiserve = $PatrimonioNettoAltreRiserveDistintamenteIndicateTotaleAltreRiserve;
        $indiciBilancio['QUANTITA IMPORTANTI']['UTILE NON DISTRIBUITO O ALTRE RISERVE'] = number_format((float)($UtileNonDistribuitoAltreRiserve), 2, ',', '.').'€' ;

        //CREDITI

        $Crediti = $TotaleCrediti;
        $indiciBilancio['QUANTITA IMPORTANTI']['CREDITI'] = number_format((float)($Crediti), 2, ',', '.').'€' ;

        //CAPITALE OPERATIVO O CIRCOLANTE NETTO = ATTIVO CORRENTE - PASSIVO CORRENTE

        $CapitaleOperativoCircolanteNetto = $AttivoCorrente-$PassivitaCorrentiCircolanti;
        $indiciBilancio['QUANTITA IMPORTANTI']['CAPITALE OPERATIVO O CIRCOLANTE NETTO'] = number_format((float)($CapitaleOperativoCircolanteNetto), 2, ',', '.').'€' ;

        //VALORE DELLA PRODUZIONE

        $ValoreDellaProduzione = $TotaleValoreProduzione;
        $indiciBilancio['QUANTITA IMPORTANTI']['VALORE DELLA PRODUZIONE'] = number_format((float)($ValoreDellaProduzione), 2, ',', '.').'€' ;

        //VALORE AGGIUNTO
        $ValoreProduzioneVariazioniRimanenzeProdottiCorsoLavorazioneSemilavoratiFiniti = isset($bilancioJSON->ValoreProduzioneVariazioniRimanenzeProdottiCorsoLavorazioneSemilavoratiFiniti) ? $bilancioJSON->ValoreProduzioneVariazioniRimanenzeProdottiCorsoLavorazioneSemilavoratiFiniti : 0;
        $ValoreProduzioneVariazioniLavoriCorsoOrdinazione = isset($bilancioJSON->ValoreProduzioneVariazioniLavoriCorsoOrdinazione ) ? $bilancioJSON->ValoreProduzioneVariazioniLavoriCorsoOrdinazione  : $val = (isset($bilancioJSONprev->ValoreProduzioneVariazioniLavoriCorsoOrdinazione ) ? $bilancioJSONprev->ValoreProduzioneVariazioniLavoriCorsoOrdinazione  : 0);
        $ValoreProduzioneAltriRicaviProventiTotaleAltriRicaviProventi = isset($bilancioJSON->ValoreProduzioneAltriRicaviProventiTotaleAltriRicaviProventi) ? $bilancioJSON->ValoreProduzioneAltriRicaviProventiTotaleAltriRicaviProventi : 0;

        $ValoreAggiunto = $ValoreProduzioneRicaviVenditePrestazioni + $ValoreProduzioneVariazioniRimanenzeProdottiCorsoLavorazioneSemilavoratiFiniti + $ValoreProduzioneVariazioniLavoriCorsoOrdinazione + $ValoreProduzioneAltriRicaviProventiTotaleAltriRicaviProventi - $CostiProduzioneMateriePrimeSussidiarieConsumoMerci - $CostiProduzioneServizi - $CostiProduzioneGodimentoBeniTerzi - $CostiProduzioneVariazioniRimanenzeMateriePrimeSussidiarieConsumoMerci - $CostiProduzioneOneriDiversiGestione;
        $indiciBilancio['QUANTITA IMPORTANTI']['VALORE AGGIUNTO'] = number_format((float)($ValoreAggiunto), 2, ',', '.').'€' ;

//        dd($ValoreProduzioneRicaviVenditePrestazioni, $ValoreProduzioneVariazioniRimanenzeProdottiCorsoLavorazioneSemilavoratiFiniti, $ValoreProduzioneVariazioniLavoriCorsoOrdinazione, $ValoreProduzioneAltriRicaviProventiTotaleAltriRicaviProventi, $CostiProduzioneMateriePrimeSussidiarieConsumoMerci, $CostiProduzioneServizi, $CostiProduzioneGodimentoBeniTerzi, $CostiProduzioneOneriDiversiGestione, $CostiProduzioneVariazioniRimanenzeMateriePrimeSussidiarieConsumoMerci);

        //MARGINE OPERATIVO LORDO O EBITDA

        $MargineOperativoLordoEBITDA = $ValoreAggiunto-$CostiProduzionePersonaleTotaleCostiPersonale;
        $indiciBilancio['QUANTITA IMPORTANTI']['MARGINE OPERATIVO LORDO O EBITDA'] = number_format((float)($MargineOperativoLordoEBITDA), 2, ',', '.').'€' ;

        //MARGINE OPERATIVO NETTO O EBIT

        $CostiProduzioneAccantonamentiRiscfi = isset($bilancioJSON->CostiProduzioneAccantonamentiRiscfi) ? $bilancioJSON->CostiProduzioneAccantonamentiRiscfi : 0;

        $MargineOperativoNettoEBIT = $MargineOperativoLordoEBITDA-$CostiProduzioneAmmortamentiSvalutazioniTotaleAmmortamentiSvalutazioni-$CostiProduzioneAccantonamentiRiscfi - $CostiProduzioneAltriAccantonamenti ;
        $indiciBilancio['QUANTITA IMPORTANTI']['MARGINE OPERATIVO NETTO O EBIT'] = number_format((float)($MargineOperativoNettoEBIT), 2, ',', '.').'€' ;

        //ONERI FINANZIARI

        $OneriFinanziari = $ProventiOneriFinanziariInteressiAltriOneriFinanziariTotaleInteressiAltriOneriFinanziari;
        $indiciBilancio['QUANTITA IMPORTANTI']['ONERI FINANZIARI'] = number_format((float)($OneriFinanziari), 2, ',', '.').'€' ;

        //COSTO DEL VENDUTO O COSTO DELLA PRODUZIONE

        $TotaleCostiProduzione = isset($bilancioJSON->TotaleCostiProduzione) ? $bilancioJSON->TotaleCostiProduzione : 0;

        $CostoVendutoCostoProduzione = $TotaleCostiProduzione;
        $indiciBilancio['QUANTITA IMPORTANTI']['COSTO DEL VENDUTO O COSTO DELLA PRODUZIONE'] = number_format((float)($CostoVendutoCostoProduzione), 2, ',', '.').'€' ;

        //COSTO DEL PERSONALE

        $CostoPersonale = $CostiProduzionePersonaleTotaleCostiPersonale;
        $indiciBilancio['QUANTITA IMPORTANTI']['COSTO DEL PERSONALE'] = number_format((float)($CostoPersonale), 2, ',', '.').'€' ;

        //RISULTATO PRIMA DELLE IMPOSTE

        $RisultatoPrimaImposte = isset($bilancioJSON->RisultatoPrimaImposte) ? $bilancioJSON->RisultatoPrimaImposte : 0;

        $RisultatoPrimaDelleImposte = $RisultatoPrimaImposte;
        $indiciBilancio['QUANTITA IMPORTANTI']['RISULTATO PRIMA DELLE IMPOSTE'] = number_format((float)($RisultatoPrimaDelleImposte), 2, ',', '.').'€' ;

        //REDDITO O RISULTATO OPERATIVO

        $RedditoRisultatoOperativo = $DifferenzaValoreCostiProduzione;
        $indiciBilancio['QUANTITA IMPORTANTI']['REDDITO O RISULTATO OPERATIVO'] = number_format((float)($RedditoRisultatoOperativo), 2, ',', '.').'€' ;

        //FATTURATO O RICAVI DI VENDITE O TOTALE VENDITE

        $FatturatoRicaviVenditeTotaleVendite = $ValoreProduzioneRicaviVenditePrestazioni;
        $indiciBilancio['QUANTITA IMPORTANTI']['FATTURATO O RICAVI DI VENDITE O TOTALE VENDITE'] = number_format((float)($FatturatoRicaviVenditeTotaleVendite), 2, ',', '.').'€' ;

        //DISPONIBILITA LIQUIDE

        $DisponibilitaLiquide = $TotaleDisponibilitaLiquide;
        $indiciBilancio['QUANTITA IMPORTANTI']['DISPONIBILITA LIQUIDE'] = number_format((float)($DisponibilitaLiquide), 2, ',', '.').'€' ;

        //CREDITI FINANZIARI ENTRO ESERCIZIO IN CORSO

        $ImmobilizzazioniFinanziarieCreditiVersoImpreseControllateEsigibiliEntroEsercizioSuccessivo = isset($bilancioJSON->ImmobilizzazioniFinanziarieCreditiVersoImpreseControllateEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->ImmobilizzazioniFinanziarieCreditiVersoImpreseControllateEsigibiliEntroEsercizioSuccessivo : 0;
        $ImmobilizzazioniFinanziarieCreditiVersoControllantiEsigibiliEntroEsercizioSuccessivo = isset($bilancioJSON->ImmobilizzazioniFinanziarieCreditiVersoControllantiEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->ImmobilizzazioniFinanziarieCreditiVersoControllantiEsigibiliEntroEsercizioSuccessivo : 0;
        $ImmobilizzazioniFinanziarieCreditiVersoImpreseCollegateEsigibiliEntroEsercizioSuccessivo = isset($bilancioJSON->ImmobilizzazioniFinanziarieCreditiVersoImpreseCollegateEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->ImmobilizzazioniFinanziarieCreditiVersoImpreseCollegateEsigibiliEntroEsercizioSuccessivo : 0;
        $ImmobilizzazioniFinanziarieCreditiVersoAltriEsigibiliEntroEsercizioSuccessivo = isset($bilancioJSON->ImmobilizzazioniFinanziarieCreditiVersoAltriEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSON->ImmobilizzazioniFinanziarieCreditiVersoAltriEsigibiliEntroEsercizioSuccessivo : $val = (isset($bilancioJSONprev->ImmobilizzazioniFinanziarieCreditiVersoAltriEsigibiliEntroEsercizioSuccessivo) ? $bilancioJSONprev->ImmobilizzazioniFinanziarieCreditiVersoAltriEsigibiliEntroEsercizioSuccessivo : 0);

        $CreditiFinanziariEntroEsercizioInCorso = $ImmobilizzazioniFinanziarieCreditiVersoImpreseControllateEsigibiliEntroEsercizioSuccessivo + $ImmobilizzazioniFinanziarieCreditiVersoAltriEsigibiliEntroEsercizioSuccessivo + $ImmobilizzazioniFinanziarieCreditiVersoControllantiEsigibiliEntroEsercizioSuccessivo + $ImmobilizzazioniFinanziarieCreditiVersoImpreseCollegateEsigibiliEntroEsercizioSuccessivo;
        $indiciBilancio['QUANTITA IMPORTANTI']['CREDITI FINANZIARI ENTRO ESERCIZIO IN CORSO'] = number_format((float)($CreditiFinanziariEntroEsercizioInCorso), 2, ',', '.').'€' ;

        //DEBITI FINANZIARI
        $DebitiFinanziari = $DebitiObbligazioniEsigibiliEntroEsercizioSuccessivo + $DebitiObbligazioniEsigibiliOltreEsercizioSuccessivo + $DebitiObbligazioniConvertibiliEsigibiliEntroEsercizioSuccessivo + $DebitiObbligazioniConvertibiliEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiVersoSociFinanziamentiEsigibiliEntroEsercizioSuccessivo + $DebitiDebitiVersoSociFinanziamentiEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiVersoBancheEsigibiliEntroEsercizioSuccessivo + $DebitiDebitiVersoBancheEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiVersoAltriFinanziatoriEsigibiliEntroEsercizioSuccessivo + $DebitiDebitiVersoAltriFinanziatoriEsigibiliOltreEsercizioSuccessivo;
        $indiciBilancio['QUANTITA IMPORTANTI']['DEBITI FINANZIARI'] = number_format((float)($DebitiFinanziari), 2, ',', '.').'€' ;

        //DEBITI FINANZIARI OLTRE 12 MESI

        $DebitiFinanziariOltreDodiciMesi = $DebitiDebitiVersoAltriFinanziatoriEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiVersoBancheEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiVersoSociFinanziamentiEsigibiliOltreEsercizioSuccessivo + $DebitiObbligazioniConvertibiliEsigibiliOltreEsercizioSuccessivo + $DebitiObbligazioniEsigibiliOltreEsercizioSuccessivo;
        $indiciBilancio['QUANTITA IMPORTANTI']['DEBITI FINANZIARI OLTRE 12 MESI'] = number_format((float)($DebitiFinanziariOltreDodiciMesi), 2, ',', '.').'€' ;

        //DEBITI FINANZIARI OLTRE 12 MESI PAGATI NELL'ESERCIZIO

        $DebitiFinanziariOltreDodiciMesiPagatiEsercizio = null;
        $indiciBilancio['QUANTITA IMPORTANTI']['DEBITI FINANZIARI OLTRE 12 MESI PAGATI NELL ESERCIZIO'] = number_format((float)($DebitiFinanziariOltreDodiciMesiPagatiEsercizio), 2, ',', '.').'€' ;

        //DEBITI COMMERCIALI

        $DebitiCommerciali = $DebitiAltriDebitiEsigibiliOltreEsercizioSuccessivo + $DebitiAltriDebitiEsigibiliEntroEsercizioSuccessivo + $DebitiDebitiVersoIstitutiPrevidenzaSicurezzaSocialeEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiVersoIstitutiPrevidenzaSicurezzaSocialeEsigibiliEntroEsercizioSuccessivo + $DebitiDebitiTributariEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiTributariEsigibiliEntroEsercizioSuccessivo + $DebitiDebitiVersoControllantiEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiVersoControllantiEsigibiliEntroEsercizioSuccessivo + $DebitiDebitiVersoImpreseCollegateEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiVersoImpreseCollegateEsigibiliEntroEsercizioSuccessivo + $DebitiDebitiVersoImpreseControllateEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiVersoImpreseControllateEsigibiliEntroEsercizioSuccessivo + $DebitiDebitiRappresentatiTitoliCreditoEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiRappresentatiTitoliCreditoEsigibiliEntroEsercizioSuccessivo + $DebitiDebitiVersoFornitoriEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiVersoFornitoriEsigibiliEntroEsercizioSuccessivo + $DebitiAccontiEsigibiliOltreEsercizioSuccessivo +$DebitiAccontiEsigibiliEntroEsercizioSuccessivo;
        $indiciBilancio['QUANTITA IMPORTANTI']['DEBITI COMMERCIALI'] = number_format((float)($DebitiCommerciali), 2, ',', '.').'€' ;

        //PATRIMONIO NETTO

        $PatrimonioNetto = $TotalePatrimonioNetto;
        $indiciBilancio['QUANTITA IMPORTANTI']['PATRIMONIO NETTO'] = number_format((float)($PatrimonioNetto), 2, ',', '.').'€';

        $indiciBilancio['QUANTITA IMPORTANTI']['TOTALE ATTIVO'] =  number_format((float)($TotaleAttivo), 2, ',', '.').'€';


        //PFN

        $CreditiVersoImpreseCollegateEsigibiliOltreEsercizioSuccessivo = isset($bilancioJSON->CreditiVersoImpreseCollegateEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSON->CreditiVersoImpreseCollegateEsigibiliOltreEsercizioSuccessivo : 0;
        $CreditiVersoImpreseControllateEsigibiliOltreEsercizioSuccessivo = isset($bilancioJSON->CreditiVersoImpreseControllateEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSON->CreditiVersoImpreseControllateEsigibiliOltreEsercizioSuccessivo : 0;
        $CreditiVersoAltriEsigibiliOltreEsercizioSuccessivo = isset($bilancioJSON->CreditiVersoAltriEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSON->CreditiVersoAltriEsigibiliOltreEsercizioSuccessivo : $val = (isset($bilancioJSONprev->CreditiVersoAltriEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSONprev->CreditiVersoAltriEsigibiliOltreEsercizioSuccessivo : 0);

        $PFN = $TotaleDisponibilitaLiquide + $CreditiVersoImpreseControllateEsigibiliEntroEsercizioSuccessivo +  $CreditiVersoControllantiEsigibiliOltreEsercizioSuccessivo + $CreditiVersoControllantiEsigibiliEntroEsercizioSuccessivo + $CreditiVersoImpreseCollegateEsigibiliOltreEsercizioSuccessivo + $CreditiVersoImpreseCollegateEsigibiliEntroEsercizioSuccessivo + $CreditiVersoImpreseControllateEsigibiliOltreEsercizioSuccessivo + $CreditiVersoAltriEsigibiliOltreEsercizioSuccessivo + $CreditiVersoAltriEsigibiliEntroEsercizioSuccessivo - $DebitiObbligazioniEsigibiliEntroEsercizioSuccessivo - $DebitiObbligazioniEsigibiliEntroEsercizioSuccessivo - $DebitiDebitiVersoBancheEsigibiliOltreEsercizioSuccessivo - $DebitiDebitiVersoBancheEsigibiliEntroEsercizioSuccessivo - $DebitiDebitiVersoSociFinanziamentiEsigibiliEntroEsercizioSuccessivo - $DebitiDebitiVersoSociFinanziamentiEsigibiliOltreEsercizioSuccessivo - $DebitiObbligazioniConvertibiliEsigibiliOltreEsercizioSuccessivo - $DebitiObbligazioniConvertibiliEsigibiliEntroEsercizioSuccessivo - $DebitiObbligazioniEsigibiliOltreEsercizioSuccessivo - $DebitiDebitiVersoControllantiEsigibiliOltreEsercizioSuccessivo - $DebitiDebitiVersoControllantiEsigibiliEntroEsercizioSuccessivo - $DebitiDebitiVersoImpreseCollegateEsigibiliOltreEsercizioSuccessivo - $DebitiDebitiVersoImpreseCollegateEsigibiliEntroEsercizioSuccessivo - $DebitiDebitiVersoImpreseControllateEsigibiliOltreEsercizioSuccessivo - $DebitiDebitiVersoImpreseControllateEsigibiliEntroEsercizioSuccessivo - $DebitiDebitiRappresentatiTitoliCreditoEsigibiliOltreEsercizioSuccessivo - $DebitiDebitiRappresentatiTitoliCreditoEsigibiliEntroEsercizioSuccessivo - $DebitiDebitiVersoAltriFinanziatoriEsigibiliOltreEsercizioSuccessivo - $DebitiDebitiVersoAltriFinanziatoriEsigibiliEntroEsercizioSuccessivo;
        $indiciBilancio['QUANTITA IMPORTANTI']['PFN'] =  number_format((float)($PFN), 2, ',', '.').'€';

        // DEBITI VS BANCHE

        $DebitiDebitiVersoBancheTotaleDebitiVersoBanche = isset($bilancioJSON->DebitiDebitiVersoBancheTotaleDebitiVersoBanche) ? $bilancioJSON->DebitiDebitiVersoBancheTotaleDebitiVersoBanche: $val = isset($bilancioJSONprev->DebitiDebitiVersoBancheTotaleDebitiVersoBanche) ? $bilancioJSONprev->DebitiDebitiVersoBancheTotaleDebitiVersoBanche : 0;
        $DebitiVsBanche = $DebitiDebitiVersoBancheTotaleDebitiVersoBanche;
        $indiciBilancio['QUANTITA IMPORTANTI']['DEBITI VS BANCHE'] =  number_format((float)($DebitiVsBanche), 2, ',', '.').'€';

        //DEBITI FINANZIARI ENTRO 12 MESI

        $DebitiFinanziariEntroDodiciMesi = $DebitiObbligazioniEsigibiliEntroEsercizioSuccessivo + $DebitiObbligazioniConvertibiliEsigibiliEntroEsercizioSuccessivo + $DebitiDebitiVersoSociFinanziamentiEsigibiliEntroEsercizioSuccessivo + $DebitiDebitiVersoBancheEsigibiliEntroEsercizioSuccessivo + $DebitiDebitiVersoAltriFinanziatoriEsigibiliEntroEsercizioSuccessivo + $DebitiAccontiEsigibiliEntroEsercizioSuccessivo;
        $indiciBilancio['QUANTITA IMPORTANTI']['DEBITI FINANZIARI ENTRO 12 MESI'] =  number_format((float)($DebitiFinanziariEntroDodiciMesi), 2, ',', '.').'€';

        //PASSIVO CONSOLIDATO

        $DebitiDebitiVersoBancheEsigibiliOltreEsercizioSuccessivo = isset($bilancioJSON->DebitiDebitiVersoBancheEsigibiliOltreEsercizioSuccessivo) ? $bilancioJSON->DebitiDebitiVersoBancheEsigibiliOltreEsercizioSuccessivo : 0;

        $PassivoConsolidato = $PassivoRateiRisconti + $DebitiAltriDebitiEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiVersoIstitutiPrevidenzaSicurezzaSocialeEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiTributariEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiVersoControllantiEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiVersoImpreseCollegateEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiVersoImpreseControllateEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiRappresentatiTitoliCreditoEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiVersoFornitoriEsigibiliOltreEsercizioSuccessivo + $DebitiAccontiEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiVersoAltriFinanziatoriEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiVersoBancheEsigibiliOltreEsercizioSuccessivo + $DebitiDebitiVersoSociFinanziamentiEsigibiliOltreEsercizioSuccessivo + $DebitiObbligazioniConvertibiliEsigibiliOltreEsercizioSuccessivo + $DebitiObbligazioniEsigibiliOltreEsercizioSuccessivo + $TrattamentoFineRapportoLavoroSubordinato;
        $indiciBilancio['QUANTITA IMPORTANTI']['PASSIVO CONSOLIDATO'] =  number_format((float)($PassivoConsolidato), 2, ',', '.').'€';

        //CAPITALE FISSO

        $CapitaleFisso = $TotaleImmobilizzazioni;
        $indiciBilancio['QUANTITA IMPORTANTI']['CAPITALE FISSO'] =  number_format((float)($CapitaleFisso), 2, ',', '.').'€';

        //VARIAZIONE RIMANENZE

        $VariazioneRimanenze = $TotaleRimanenze - $CostiProduzioneVariazioniRimanenzeMateriePrimeSussidiarieConsumoMerci;
        $indiciBilancio['QUANTITA IMPORTANTI']['VARIAZIONE RIMANENZE'] =  number_format((float)($VariazioneRimanenze), 2, ',', '.').'€';

        //CASH FLOW OPERATIVO=UTILE NETTO + ACCANTONAMENTI + AMMORTAMENTI-IMPOSTE ANTICIPATE


        $ImposteRedditoEsercizioImposteAnticipate = isset($bilancioJSON->ImposteRedditoEsercizioCorrentiDifferiteAnticipateImposteDifferiteAnticipate) ? $bilancioJSON->ImposteRedditoEsercizioCorrentiDifferiteAnticipateImposteDifferiteAnticipate : $val = (isset($bilancioJSONprev->ImposteRedditoEsercizioCorrentiDifferiteAnticipateImposteDifferiteAnticipate) ? $bilancioJSONprev->ImposteRedditoEsercizioCorrentiDifferiteAnticipateImposteDifferiteAnticipate: 0);
        $CashFlowOperativo = $UtilePerditaEsercizio + $CostiProduzioneAmmortamentiSvalutazioniTotaleAmmortamentiSvalutazioni + $CostiProduzioneAccantonamentiRischi + $CostiProduzioneAltriAccantonamenti - $ImposteRedditoEsercizioImposteAnticipate;
        $indiciBilancio['QUANTITA IMPORTANTI']['CASH FLOW OPERATIVO'] =  number_format((float)($CashFlowOperativo), 2, ',', '.').'€';

        //IMPEGNI FINANZIARI PAGATI NELL ESERCIZIO

        // ### INDICI PATRIMONIALI ###

        //EI = ATTIVO CIRCOLANTE / TOTALE IMPIEGHI

        $EI = $AttivoCorrente / $TotaleAttivitaImpieghiCapitaleInvestito;
        $GiudizioEI = '';

        if($EI <= 0.3){
            $GiudizioEI = 'RIGIDA';
        }
        else if ($EI> 0.3 && $EI < 0.7){
            $GiudizioEI = 'DISCRETA';
        }
        else{
            $GiudizioEI = 'BUONA';
        }

        $indiciBilancio['INDICI PATRIMONIALI']['EI']['VALORE'] = number_format((float)($EI), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI PATRIMONIALI']['EI']['GIUDIZIO'] = $GiudizioEI;

        //RI = ATTIVO IMMOBILIZZATO / TOTALE IMPIEGHI

        $RI = $AttivoImmobilizzatoImmobilizzazioniNette / $TotaleAttivitaImpieghiCapitaleInvestito;

        $GiudizioRI = '';

        if($RI >= 0.7){
            $GiudizioRI = 'RIGIDA';
        }
        else if ($RI< 0.7 && $EI > 0.3){
            $GiudizioRI = 'DISCRETA';
        }
        else{
            $GiudizioEI = 'BUONA';
        }

        $indiciBilancio['INDICI PATRIMONIALI']['RI']['VALORE'] = number_format((float)($RI), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI PATRIMONIALI']['RI']['GIUDIZIO'] = $GiudizioRI;

        //EF = PASSIVITA' CORRENTI / TOTALE IMPIEGHI

        $EF = $PassivitaCorrentiCircolanti / $TotaleAttivitaImpieghiCapitaleInvestito;

        $GiudizioEF = '';

        if($EI <= 0.3){
            $GiudizioEF = 'OTTIMA';
        }
        else if ($EF> 0.3 && $EI < 0.5){
            $GiudizioEF = 'EQUILIBRIO';
        }
        else{
            $GiudizioEF = 'SCARSA';
        }

        $indiciBilancio['INDICI PATRIMONIALI']['EF']['VALORE'] = number_format((float)($EF), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI PATRIMONIALI']['EF']['GIUDIZIO'] = $GiudizioEF;

        //RF = PASSIVITA' CONSOLIDATE / TOTALE IMPIEGHI

        $RF = $PassivitaConsolidate / $TotaleAttivitaImpieghiCapitaleInvestito;

        $GiudizioRF = '';

        if($RF >= 0.7){
            $GiudizioRF = 'OTTIMA';
        }
        else if ($RF> 0.3 && $RF < 0.7){
            $GiudizioRF = 'EQUILIBRIO';
        }
        else{
            $GiudizioRF = 'SCARSA';
        }

        $indiciBilancio['INDICI PATRIMONIALI']['RF']['VALORE'] = number_format((float)($RF), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI PATRIMONIALI']['RF']['GIUDIZIO'] = $GiudizioRF;

        //QUOTA DI PASSIVO CIRCOLANTE

        $QuotaPassivoCircolante = $PassivitaCorrentiCircolanti / $PassivitaConsolidate;

        $GiudizioQuotaPassivoCircolante = '';

        if($QuotaPassivoCircolante >= 1){
            $GiudizioQuotaPassivoCircolante = 'PREVALENZA DI CIRCOLANTE';
        }
        else{
            $GiudizioQuotaPassivoCircolante = 'PREVALENZA DI CONSOLIDATO';
        }

        $indiciBilancio['INDICI PATRIMONIALI']['QUOTA DI PASSIVO CIRCOLANTE']['VALORE'] = number_format((float)($QuotaPassivoCircolante), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI PATRIMONIALI']['QUOTA DI PASSIVO CIRCOLANTE']['GIUDIZIO'] = $GiudizioQuotaPassivoCircolante;

        //QUOTA DI PASSIVO CONSOLIDATO

        $QuotaPassivoConsolidato = $PassivitaConsolidate / $PassivitaCorrentiCircolanti;

        $GiudizioQuotaPassivoConsolidato = '';

        if($QuotaPassivoCircolante >= 1){
            $GiudizioQuotaPassivoConsolidato = 'PREVALENZA DI CONSOLIDATO';
        }
        else{
            $GiudizioQuotaPassivoConsolidato = 'PREVALENZA DI CIRCOLANTE';
        }

        $indiciBilancio['INDICI PATRIMONIALI']['QUOTA DI PASSIVO CONSOLIDATO']['VALORE'] = number_format((float)($QuotaPassivoConsolidato), 2, ',', ' ').'%'  ;
        $indiciBilancio['INDICI PATRIMONIALI']['QUOTA DI PASSIVO CONSOLIDATO']['GIUDIZIO'] = $GiudizioQuotaPassivoConsolidato;

        //MS = PATRIMONIO NETTO - IMMOBILIZZAZIONI NETTE

        $MS = $CapitaleProprioPatrimonioNettoMezziPropriCorrente - $AttivoImmobilizzatoImmobilizzazioniNette;

        $GiudizioMS = '';

        if($MS <= 0){
            $GiudizioMS = 'RIGIDITà PATRIMONIALE';
        }
        else{
            $GiudizioMS = 'SOLIDITà PATRIMONIALE';
        }

        $indiciBilancio['INDICI PATRIMONIALI']['MS']['VALORE'] = number_format((float)($MS), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI PATRIMONIALI']['MS']['GIUDIZIO'] = $GiudizioMS;

        // MT = CREDITI (B) + DISPONIBILITA' LIQUIDE - DEBITI (B)

        $MT = $Crediti + $DisponibilitaLiquide - $PassivitaCorrentiCircolanti ;

        $GiudizioMT = '';

        if($MT <= 0){
            $GiudizioMT = 'RIGIDITà FINANZIARIA';
        }
        else{
            $GiudizioMT = 'SOLIDITà FINANZIARIA';
        }

        $indiciBilancio['INDICI PATRIMONIALI']['MT']['VALORE'] = number_format((float)($MT), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI PATRIMONIALI']['MT']['GIUDIZIO'] = $GiudizioMT;

        // ### INDICI ECONOMICI ###

        //COSTO DEL VENDUTO / RICAVI DI VENDITE

        $CostoVendutoFrattoRicaviDiVendite = $CostoVendutoCostoProduzione / $FatturatoRicaviVenditeTotaleVendite;

        $GiudizioCostoVendutoRicaviVendite = '';

        $indiciBilancio['INDICI ECONOMICI']['COSTO DEL VENDUTO / RICAVI DI VENDITE']['VALORE'] = number_format((float)($CostoVendutoFrattoRicaviDiVendite), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI ECONOMICI']['COSTO DEL VENDUTO / RICAVI DI VENDITE']['GIUDIZIO'] = $GiudizioCostoVendutoRicaviVendite;

        //COSTO DEL PERSONALE / RICAVI DI VENDITE

        $CostoDelPersonaleFrattoRicaviDiVendite = $CostoPersonale / $FatturatoRicaviVenditeTotaleVendite;

        $GiudizioCostoPersonaleRicaviVendite = '';

        if ($CostoDelPersonaleFrattoRicaviDiVendite <= 0.14){
            $GiudizioCostoPersonaleRicaviVendite = 'SCARSO';
        }
        else if ($CostoDelPersonaleFrattoRicaviDiVendite > 0.14 && $CostoDelPersonaleFrattoRicaviDiVendite < 0.18){
            $GiudizioCostoPersonaleRicaviVendite = 'EQUILIBRIO';
        }
        else{
            $GiudizioCostoPersonaleRicaviVendite = 'ESUBERO';
        }

        $indiciBilancio['INDICI ECONOMICI']['COSTO DEL PERSONALE / RICAVI DI VENDITE']['VALORE'] = number_format((float)($CostoDelPersonaleFrattoRicaviDiVendite), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI ECONOMICI']['COSTO DEL PERSONALE / RICAVI DI VENDITE']['GIUDIZIO'] = $GiudizioCostoPersonaleRicaviVendite;

        //MOL / RICAVI DI VENDITE (FATTURATO)

        $MOLFrattoRicaviDiVendite = $MargineOperativoLordoEBITDA / $FatturatoRicaviVenditeTotaleVendite;

        $GiudizioMOLRicaviVendite = '';

        if($MOLFrattoRicaviDiVendite < 0.1){
            $GiudizioMOLRicaviVendite = 'SCARSO';
        }
        else if($MOLFrattoRicaviDiVendite >= 0.1 && $MOLFrattoRicaviDiVendite <= 18){
            $GiudizioMOLRicaviVendite = 'BUONO';
        }
        else{
            $GiudizioMOLRicaviVendite = 'OTTIMO';
        }

        $indiciBilancio['INDICI ECONOMICI']['MOL / RICAVI DI VENDITE (FATTURATO)']['VALORE'] = number_format((float)($MOLFrattoRicaviDiVendite), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI ECONOMICI']['MOL / RICAVI DI VENDITE (FATTURATO)']['GIUDIZIO'] = $GiudizioRI;

        //ONERI FINANZIARI / RICAVI DI VENDITE (FATTURATO)

        $OneriFinanziariFrattoRicaviDiVendite = $OneriFinanziari / $FatturatoRicaviVenditeTotaleVendite;

        $GiudizioOneriFinanziariRicaviVendite = '';

        if($OneriFinanziariFrattoRicaviDiVendite > 0.05){
            $GiudizioOneriFinanziariRicaviVendite = 'ELEVATO';
        }
        else if($OneriFinanziariFrattoRicaviDiVendite >= 0.03 && $OneriFinanziariFrattoRicaviDiVendite <= 0.04){
            $GiudizioOneriFinanziariRicaviVendite = 'AL LIMITE';
        }
        else{
            $GiudizioOneriFinanziariRicaviVendite = 'OTTIMALE';
        }

        $indiciBilancio['INDICI ECONOMICI']['ONERI FINANZIARI / RICAVI DI VENDITE (FATTURATO)']['VALORE'] = number_format((float)($OneriFinanziariFrattoRicaviDiVendite), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI ECONOMICI']['ONERI FINANZIARI / RICAVI DI VENDITE (FATTURATO)']['GIUDIZIO'] = $GiudizioOneriFinanziariRicaviVendite;

        //RISULTATO PRIMA DELLE IMPOSTE / RICAVI DI VENDITE

        $RisultatoPrimaDelleImposteFrattoRicaviDiVendite = $RisultatoPrimaImposte / $FatturatoRicaviVenditeTotaleVendite;

        $GiudizioRisultatoPrimaImposteRicaviVendite = '';

        $indiciBilancio['INDICI ECONOMICI']['RISULTATO PRIMA DELLE IMPOSTE / RICAVI DI VENDITE']['VALORE'] = number_format((float)($RisultatoPrimaDelleImposteFrattoRicaviDiVendite), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI ECONOMICI']['RISULTATO PRIMA DELLE IMPOSTE / RICAVI DI VENDITE']['GIUDIZIO'] = $GiudizioRisultatoPrimaImposteRicaviVendite;

        //UTILE (PERDITA) D'ESERCIZIO / RICAVI DI VENDITE

        $UtilePerditaEsercizioFrattoRicaviDiVendite = $UtileRedditoNettoEsercizio / $FatturatoRicaviVenditeTotaleVendite;

        $GiudizioUtilePerditaEsercizioRicaviVendita = '';

        $indiciBilancio['INDICI ECONOMICI']['UTILE (PERDITA) D ESERCIZIO / RICAVI DI VENDITE']['VALORE'] = number_format((float)($UtilePerditaEsercizioFrattoRicaviDiVendite), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI ECONOMICI']['UTILE (PERDITA) D ESERCIZIO / RICAVI DI VENDITE']['GIUDIZIO'] = $GiudizioUtilePerditaEsercizioRicaviVendita;

        //i = TASSO MEDIO DI INTERESSE SUI PRESTITI

        $TassoMedioInteressePrestiti = 0.029;

        $GiudizioTassoMedioInteressePrestiti = '';

        $indiciBilancio['INDICI ECONOMICI']['TASSO MEDIO DI INTERESSE SUI PRESTITI']['VALORE'] = number_format((float)($TassoMedioInteressePrestiti), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI ECONOMICI']['TASSO MEDIO DI INTERESSE SUI PRESTITI']['GIUDIZIO'] = $GiudizioTassoMedioInteressePrestiti;

        //ROA = REDDITO NETTO / CAPITALE INVESTITO

        $ROA = $UtileRedditoNettoEsercizio / $TotaleAttivitaImpieghiCapitaleInvestito;

        $GiudizioROA = '';

        if($ROA < 0){
            $GiudizioROA = 'CRISI';
        }
        else if($ROA>=$TassoMedioInteressePrestiti){
            $GiudizioROA = 'EQUILIBRIO';
        }
        else{
            $GiudizioROA = 'REGOLARE';
        }

        $indiciBilancio['INDICI ECONOMICI']['ROA']['VALORE'] = number_format((float)($ROA), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI ECONOMICI']['ROA']['GIUDIZIO'] = $GiudizioROA;

        //ROI = REDDITO OPERATIVO / TOTALE IMPIEGHI

        $ROIredditoOpearativoFrattoTotaleImpieghi = $RedditoRisultatoOperativo / $TotaleAttivitaImpieghiCapitaleInvestito;

        $GiudizioROIredditoOpearativoTotaleImpieghi = '';

        if($ROIredditoOpearativoFrattoTotaleImpieghi <= 0.08){
            $GiudizioROIredditoOpearativoTotaleImpieghi = 'SCARSO';
        }
        else if($ROIredditoOpearativoFrattoTotaleImpieghi> 0.08 && $ROIredditoOpearativoFrattoTotaleImpieghi < 0.1 ){
            $GiudizioROIredditoOpearativoTotaleImpieghi = 'BUONO';
        }
        else{
            $GiudizioROIredditoOpearativoTotaleImpieghi = 'OTTIMO';
        }

        $indiciBilancio['INDICI ECONOMICI']['ROI = REDDITO OPERATIVO /TOTALE IMPIEGHI']['VALORE'] = number_format((float)($ROIredditoOpearativoFrattoTotaleImpieghi), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI ECONOMICI']['ROI = REDDITO OPERATIVO /TOTALE IMPIEGHI']['GIUDIZIO'] = $GiudizioROIredditoOpearativoTotaleImpieghi;

        //ROE = REDDITO NETTO / CAPITALE PROPRIO

        $ROEredditoNettoFrattoCapitaleProprio = $UtileRedditoNettoEsercizio / $CapitaleProprioPatrimonioNettoMezziPropriCorrente;

        $GiudizioROEredditoNettoCapitaleProprio = '';

        if($ROEredditoNettoFrattoCapitaleProprio){
            $GiudizioROEredditoNettoCapitaleProprio = '';
        }
        else if($ROEredditoNettoFrattoCapitaleProprio){
            $GiudizioROEredditoNettoCapitaleProprio = '';
        }
        else{
            $GiudizioROEredditoNettoCapitaleProprio = '';
        }

        $indiciBilancio['INDICI ECONOMICI']['ROE = REDDITO NETTO / CAPITALE PROPRIO']['VALORE'] = number_format((float)($ROEredditoNettoFrattoCapitaleProprio), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI ECONOMICI']['ROE = REDDITO NETTO / CAPITALE PROPRIO']['GIUDIZIO'] = $GiudizioROEredditoNettoCapitaleProprio;

        //TASSO DI INFLAZIONE MEDIO ANNUO

        $TassoInflazioneMedioAnnuo = -0.1;

        $GiudizioTassoInflazioneMedioAnnuo = '';

        if($TassoInflazioneMedioAnnuo){
            $GiudizioTassoInflazioneMedioAnnuo = '';
        }
        else if($TassoInflazioneMedioAnnuo){
            $GiudizioTassoInflazioneMedioAnnuo = '';
        }
        else{
            $GiudizioTassoInflazioneMedioAnnuo = '';
        }

        $indiciBilancio['INDICI ECONOMICI']['TASSO DI INFLAZIONE MEDIO ANNUO']['VALORE'] = number_format((float)($TassoInflazioneMedioAnnuo), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI ECONOMICI']['TASSO DI INFLAZIONE MEDIO ANNUO']['GIUDIZIO'] = $GiudizioTassoInflazioneMedioAnnuo;

        //RCI = RICAVI DI VENDITA / TOTALE DEGLI IMPIEGHI

        $RCI = $FatturatoRicaviVenditeTotaleVendite / $TotaleAttivitaImpieghiCapitaleInvestito;

        $GiudizioRCI = '';

        if($RCI){
            $GiudizioRCI = '';
        }
        else if($RCI){
            $GiudizioRCI = '';
        }
        else{

        }

        $indiciBilancio['INDICI ECONOMICI']['RCI = RICAVI DI VENDITA / TOTALE DEGLI IMPIEGHI']['VALORE'] = number_format((float)($RCI), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI ECONOMICI']['RCI = RICAVI DI VENDITA / TOTALE DEGLI IMPIEGHI']['GIUDIZIO'] = $GiudizioRCI;

        //ROS = REDDITO OPERATIVO / RICAVI DI VENDITA

        $ROSredditoOperativoFrattoRicaviDiVendita = $RedditoRisultatoOperativo / $FatturatoRicaviVenditeTotaleVendite;

        $GiudizioROSredditoOperativoRicaviVendita = '';

        if($ROSredditoOperativoFrattoRicaviDiVendita < 0.06){
            $GiudizioROSredditoOperativoRicaviVendita = 'SCARSO';
        }
        else if($ROSredditoOperativoFrattoRicaviDiVendita >= 0.06 && $ROSredditoOperativoFrattoRicaviDiVendita <= 7){
            $GiudizioROSredditoOperativoRicaviVendita = 'BUONO';
        }
        else{
            $GiudizioROSredditoOperativoRicaviVendita = 'OTTIMO';
        }

        $indiciBilancio['INDICI ECONOMICI']['ROS = REDDITO OPERATIVO / RICAVI DI VENDITA']['VALORE'] = number_format((float)($ROSredditoOperativoFrattoRicaviDiVendita), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI ECONOMICI']['ROS = REDDITO OPERATIVO / RICAVI DI VENDITA']['GIUDIZIO'] = $GiudizioROSredditoOperativoRicaviVendita;

        //IGNC = REDDITO NETTO / REDDITO OPERATIVO

        $IGNC = $UtileRedditoNettoEsercizio / $RedditoRisultatoOperativo;

        $GiudizioIGNC = '';

        if($IGNC == 1){
            $GiudizioIGNC = 'NESSUN EFFETTO G. STRAORDINARIA';
        }
        else if($RCI < 1){
            $GiudizioRCI = 'EFFETTO NEGATIVO G. STRAORDINARIA';
        }
        else{
            $GiudizioRCI = 'EFFETTO POSITIVO G. STRAORDINARIA';
        }

        $indiciBilancio['INDICI ECONOMICI']['IGNC = REDDITO NETTO / REDDITO OPERATIVO']['VALORE'] = number_format((float)($IGNC), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI ECONOMICI']['IGNC = REDDITO NETTO / REDDITO OPERATIVO']['GIUDIZIO'] = $GiudizioIGNC;

        //RR = TOTALE VENDITE / RIMANENZE

        $RR = $Rimanenze != 0 ? $FatturatoRicaviVenditeTotaleVendite / $Rimanenze : 0;

        $GiudizioRR = '';

        if($RR){
            $GiudizioRR = '';
        }
        else if($RR){
            $GiudizioRR = '';
        }
        else{
            $GiudizioRR = '';
        }

        $indiciBilancio['INDICI ECONOMICI']['RR = TOTALE VENDITE / RIMANENZE']['VALORE'] = number_format((float)($RR), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI ECONOMICI']['RR = TOTALE VENDITE / RIMANENZE']['GIUDIZIO'] = $GiudizioRR;

        // ### INDICI FINANZIARI ###

        //AF = CAPITALE PROPRIO / TOTALE IMPIEGHI

        $AF = $CapitaleProprioPatrimonioNettoMezziPropriCorrente / $TotaleAttivitaImpieghiCapitaleInvestito;

        $GiudizioAF = '';

        if($AF < 0.07){
            $GiudizioAF = 'CRITICO';
        }
        else if($AF >= 0.07 && $AF < 0.15){
            $GiudizioAF = 'SUFFICIENTE';
        }
        else if($AF >= 0.15 && $AF < 0.25){
            $GiudizioAF = 'BUONO';
        }
        else{
            $GiudizioAF = 'OTTIMO';
        }

        $indiciBilancio['INDICI FINANZIARI']['AF = CAPITALE PROPRIO / TOTALE IMPIEGHI']['VALORE'] = number_format((float)($AF), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI FINANZIARI']['AF = CAPITALE PROPRIO / TOTALE IMPIEGHI']['GIUDIZIO'] = $GiudizioAF;

        //LEVERAGE = TOTALE IMPIEGHI / CAPITALE PROPRIO

        $Leverage = $TotaleAttivitaImpieghiCapitaleInvestito / $CapitaleProprioPatrimonioNettoMezziPropriCorrente;

        $GiudizioLeverage = '';

        if ($Leverage >= 1 && $Leverage <= 2){
            $GiudizioLeverage = 'PREVALENZA DEL CAPITALE PROPRIO';
        }
        else{
            $GiudizioLeverage = 'PREVALENZA DEL CAPITALE DI TERZI';
        }

        $indiciBilancio['INDICI FINANZIARI']['LEVERAGE = TOTALE IMPIEGHI / CAPITALE PROPRIO']['VALORE'] = number_format((float)($Leverage), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI FINANZIARI']['LEVERAGE = TOTALE IMPIEGHI / CAPITALE PROPRIO']['GIUDIZIO'] = $GiudizioLeverage;

        //QD = ATTIVO CIRCOLANTE / PASSIVO CIRCOLANTE

        $QD = $AttivoCorrente / $PassivitaCorrentiCircolanti;

        $GiudizioQD = '';

        if($QD <= 1){
            $GiudizioQD = 'CRITICO';
        }
        else if($QD > 1 && $QD <= 1.2){
            $GiudizioQD = 'SUFFICIENTE';
        }
        else if($QD >1.2 && $QD <= 1.4){
            $GiudizioQD = 'BUONO';
        }
        else{
            $GiudizioQD = 'OTTIMO';
        }

        $indiciBilancio['INDICI FINANZIARI']['QD = ATTIVO CIRCOLANTE / PASSIVO CIRCOLANTE']['VALORE'] = number_format((float)($QD), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI FINANZIARI']['QD = ATTIVO CIRCOLANTE / PASSIVO CIRCOLANTE']['GIUDIZIO'] = $GiudizioQD;

        //QDS = ATTIVO CIRCOLANTE - RIMANENZE / PASSIVO CIRCOLANTE

        $QDS = ($AttivoCorrente-$Rimanenze) / $PassivitaCorrentiCircolanti;

        $GiudizioQDS = '';

        if($QDS <= 0.7){
            $GiudizioQDS = 'CRITICO';
        }
        else if($QDS > 0.7 && $QDS <= 0.9){
            $GiudizioQDS = 'SUFFICIENTE';
        }
        else if($QDS > 0.9 && $QDS <= 1){
            $GiudizioQDS = 'BUONO';
        }
        else{
            $GiudizioQDS = 'OTTIMO';
        }

        $indiciBilancio['INDICI FINANZIARI']['QDS = ATTIVO CIRCOLANTE - RIMANENZE / PASSIVO CIRCOLANTE']['VALORE'] = number_format((float)($QDS), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI FINANZIARI']['QDS = ATTIVO CIRCOLANTE - RIMANENZE / PASSIVO CIRCOLANTE']['GIUDIZIO'] = $GiudizioQDS;

        //AI = CAPITALE PROPRIO / IMMOBILIZZAZIONI

        $AI = $CapitaleProprioPatrimonioNettoMezziPropriCorrente / $AttivoImmobilizzatoImmobilizzazioniNette;

        $GiudizioAI = '';

        if($AI < 0.33){
            $GiudizioAI = 'SITUAZIONE FINANZIARIA PESSIMA';
        }
        else if($AI >= 0.33 && $AI < 0.5){
            $GiudizioAI = 'SITUAZIONE FINANZIARIA CRITICA';
        }
        else if($AI >= 0.5 && $AI <= 0.7){
            $GiudizioAI = 'SITUAZIONE FINANZIARIA BUONA';
        }
        else{
            $GiudizioAI = 'SITUAZIONE FINANZIARIA OTTIMA';
        }

        $indiciBilancio['INDICI FINANZIARI']['AI = CAPITALE PROPRIO / IMMOBILIZZAZIONI']['VALORE'] = number_format((float)($AI), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI FINANZIARI']['AI = CAPITALE PROPRIO / IMMOBILIZZAZIONI']['GIUDIZIO'] = $GiudizioAI;

        //AGI = CAPITALE PROPRIO + PASSIVITA' CONSOLIDATE / IMMOBILIZZAZIONI

        $AGI = ($CapitaleProprioPatrimonioNettoMezziPropriCorrente + $PassivitaConsolidate) / $AttivoImmobilizzatoImmobilizzazioniNette;

        $GiudizioAGI = '';

        $indiciBilancio['INDICI FINANZIARI']['AGI = CAPITALE PROPRIO + PASSIVITA CONSOLIDATE / IMMOBILIZZAZIONI']['VALORE'] = number_format((float)($AGI), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI FINANZIARI']['AGI = CAPITALE PROPRIO + PASSIVITA CONSOLIDATE / IMMOBILIZZAZIONI']['GIUDIZIO'] = $GiudizioAGI;

        //DF = CAPITALE DI TERZI / TOTALE IMPIEGHI

        $DF = $CapitaleDiTerzi / $TotaleAttivitaImpieghiCapitaleInvestito;

        $GiudizioDF = '';

        if($DF >= 0.5 && $DF <= 0.7){
            $GiudizioDF = 'EQUILIBRIO';
        }
        else{
            $GiudizioDF = 'SQUILIBRIO';
        }

        $indiciBilancio['INDICI FINANZIARI']['DF = CAPITALE DI TERZI / TOTALE IMPIEGHI']['VALORE'] = number_format((float)($DF), 2, ',', ' ').'%'  ;
        $indiciBilancio['INDICI FINANZIARI']['DF = CAPITALE DI TERZI / TOTALE IMPIEGHI']['GIUDIZIO'] = $GiudizioDF;

        //QI = CAPITALE DI TERZI / CAPITALE PROPRIO

        $QI = $CapitaleDiTerzi / $CapitaleProprioPatrimonioNettoMezziPropriCorrente;

        $GiudizioQI = '';

        if($QI == 1){
            $GiudizioQI = 'EQUILIBRIO';
        }
        else if($QI > 1){
            $GiudizioQI = 'PREVALENZA CAPITALE TERZI';
        }
        else{
            $GiudizioQI = 'PREVALENZA CAPITALE PROPRIO';
        }

        $indiciBilancio['INDICI FINANZIARI']['QI = CAPITALE DI TERZI / CAPITALE PROPRIO']['VALORE'] = number_format((float)($QI), 2, ',', ' ').'%' ;
        $indiciBilancio['INDICI FINANZIARI']['QI = CAPITALE DI TERZI / CAPITALE PROPRIO']['GIUDIZIO'] = $GiudizioQI;

        $totalIndicis = indici::whereHas('Analisistype', function ($query) {
            $query->where('name', '=', 'advanced');
        })->get();


        foreach($totalIndicis as $indice) {

            // dd($dataAnalisis);

            // $pesoROI = range::Where('indice', 'ROI')->Where('range_min', '>=', $ROI)->Where('range_max', '>=', $ROI)->with('pesi')->get();
            $indiceValue = $dataAnalisis[$indice->name];
            $scoring = range::Where('indice', $indice->name)->where(function ($query) use ($indiceValue) {
                $query->where('range_max', '>=', $indiceValue);
                $query->where('range_min', '<=', $indiceValue);
            })->with('pesi')->get();
            $pesoValue = $scoring[0]->pesi->getAttributes()['peso'];
            $scoreFromRange = $scoring[0]->getAttributes()['score'];

            $totalScore = $pesoValue*$scoreFromRange;
            $dataAnalisis[$indice->name.'_finalScore'] = $totalScore;

        }
//        dd($dataAnalisis,$indiciBilancio);

        $ritorno['dataAnalisis'] = $dataAnalisis;
        $ritorno['indiciBilancio'] = $indiciBilancio;


        return $ritorno;
    }

    public function analisiCR($anno, $mese)
    {



        $test = DB::table('centralerischi')->where('anno',$anno)->where('mese',$mese)->get();
        $cleanCR[$anno][$mese] = json_decode($test[0]->jsonData, true);
        $tensioniAnnuali = array();
        $sofferenze = array();
        $soldini = array();
        $sconfini = array();
        $yearlyDivision = array();
        $sconfiniPerAnniBanche = array();
        $tensioniLineCtredito = array();
        foreach ($cleanCR as $singleYearKey => $months) {
            foreach ($months as $singleMonthKey => $banks) {
                foreach ($banks as $bankKey => $creditRow) {
                    foreach ($creditRow as $singleCreditRowTypeKey => $singleCreditValue) {
                        if ($singleCreditRowTypeKey == 'Cassa') {
                            foreach ($singleCreditValue as $credit) {
                                $TipoGaranzia = $credit['Tipo Garanzia'];
                                $TipoAttività = false;
                                $Categoria = $credit['Categoria'];
                                $Accordato = $credit['Accordato'];
                                $Utilizzato = $credit['Utilizzato'];
                                $AccordatoOperativo = $credit['Accordato
Operativo'];
                                $SaldoMedio = $credit['Saldo Medio'];
                                $ImportoGarantito = $credit['Importo
Garantito'];
                                $TipoGaranzia = preg_replace("/\n/", " ", $TipoGaranzia);

                                if (str_contains($TipoGaranzia, 'Assenza') && str_contains($TipoGaranzia, 'garanzie') && str_contains($TipoGaranzia, 'e/o')) {
                                    $TipoGaranzia = "Assenza di garanzie reali e/o privilegi";
                                }

                                if (str_contains($Categoria, 'SCADENZA')) {
                                    if (isset($credit['Tipo Attività'])) {
                                        $TipoAttività = $credit['Tipo Attività'];
                                    }

                                }

                                $currentRow = $Categoria . ' ' . $Accordato . ' ' . $AccordatoOperativo . ' ' . $TipoGaranzia;

                                $currentRow = str_contains($Categoria, 'SCADENZA') ? $currentRow . ' ' . $TipoAttività : $currentRow;

                                $isSameRow = false;

                                if (isset($prevRow)) {
                                    if ($currentRow == $prevRow) {
                                        $isSameRow = true;
                                    }
                                }

                                if ($Accordato != '') {

                                    if (!array_key_exists($singleYearKey, $sconfiniPerAnniBanche)) {
                                        $sconfiniPerAnniBanche[$singleYearKey] = array();
                                    }

                                    if (!array_key_exists($bankKey, $sconfiniPerAnniBanche[$singleYearKey])) {
                                        $sconfiniPerAnniBanche[$singleYearKey][$bankKey] = array();
                                    }
                                    if (!array_key_exists($Categoria, $sconfiniPerAnniBanche[$singleYearKey][$bankKey])) {
                                        $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria] = array();
                                    }

                                    if (!array_key_exists($currentRow, $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria])) {
                                        $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow] = array();
                                    }

                                }

                                if ($Utilizzato > $AccordatoOperativo) {
                                    // PER BANCHE ANNI

                                    if (!array_key_exists('TotaleSconfini', $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow])) {

                                        $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TotaleSconfini'] = 1;
                                        $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TensioneLineaCredito'] = false;

                                    } else {

//                                      //SE NON è SETTATA LA SETTO A 1, SE è SETTATA LA INCREMENTO DI 1

                                        if ($sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TotaleSconfini'] < 3) {

                                            //SE NON SIAMO IN SITUAZIONE DI TENSIONE

                                            $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TensioneLineaCredito'] = false;

                                        } else {

                                            //SE SIAMO IN TENSIONE, DICIAMO PER QUALE ANNO E LINEA DI CREDITO

                                            if (!array_key_exists($singleYearKey, $tensioniLineCtredito)) {

                                                $tensioniLineCtredito[$singleYearKey] = array();

                                            }

                                            $tensioniLineCtredito[$singleYearKey][$Categoria][$currentRow] = true;


                                            $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TensioneLineaCredito'] = true;

                                        }

                                        $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TotaleSconfini'] = ($sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TotaleSconfini'] + 1);
                                        if ($sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TotaleSconfini'] >= 3) {
                                            $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TensioneLineaCredito'] = true;
                                        }
                                    }

                                } else {

                                    if (!array_key_exists('TotaleSconfini', $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow])) {

                                        $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TotaleSconfini'] = 0;
                                        $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TensioneLineaCredito'] = false;

                                    }

                                    if (!($sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TotaleSconfini'] >= 3)) {

                                        //SE NON SIAMO IN SITUAZIONE DI TENSIONE

                                        $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TensioneLineaCredito'] = false;

                                    } else {

                                        if (!array_key_exists($singleYearKey, $tensioniLineCtredito)) {

                                            $tensioniLineCtredito[$singleYearKey] = array();

                                        }

                                        $tensioniLineCtredito[$singleYearKey][$Categoria][$currentRow] = true;


                                        $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TensioneLineaCredito'] = true;

                                    }

                                }

                                //SE NON HO SCONFINATO
                                if (str_contains($Categoria, 'SCADENZA')) {
                                    if (isset($credit['Tipo Attività'])) {
                                        $TipoAttività = $credit['Tipo Attività'];
                                    }
                                }
                                $prevRow = $Categoria . ' ' . $Accordato . ' ' . $AccordatoOperativo . ' ' . $TipoGaranzia;

                                $prevRow = str_contains($Categoria, 'SCADENZA') ? $currentRow . ' ' . $TipoAttività : $currentRow;
                                if (!$isSameRow) {
                                    $soldini[$singleYearKey][$bankKey][$currentRow]['Accordato Operativo'] = str_replace('.', '', $AccordatoOperativo);
                                    $soldini[$singleYearKey][$bankKey][$currentRow]['Utilizzato'] = str_replace('.', '', $Utilizzato);
                                }
                            }
                        }
                        if($singleCreditRowTypeKey == 'Informativa') {
                            foreach ($singleCreditValue as $credit) {
//                                dd($credit);
                            }
                        }
                    }
                }
            }
        }


        foreach ($soldini as $anno => $banca) {
            foreach ($banca as $nomeBanca => $val) {
                foreach ($val as $data => $value) {
                    if (!isset($soldini[$anno][$nomeBanca]['Totale Accordato Operativo'])) {
                        $soldini[$anno][$nomeBanca]['Totale Accordato Operativo'] = 0;
                        $soldini[$anno][$nomeBanca]['Totale Utilizzato'] = 0;
                    }
                    $soldini[$anno][$nomeBanca]['Totale Accordato Operativo'] += $value['Accordato Operativo'];
                    $soldini[$anno][$nomeBanca]['Totale Utilizzato'] += $value['Utilizzato'];
                }
            }
        }


        $sconfinoAnnuale = false;
        $arraySconfiniAnnuali = array();
        $conteggioSconfini = 0;

        foreach ($sconfiniPerAnniBanche as $anno => $arrayBanche) {
            foreach ($arrayBanche as $nomeBanca => $arrayRischi) {
                foreach ($arrayRischi as $risk => $righe) {
                    foreach ($righe as $row => $tensione) {
                        if ($tensione['TotaleSconfini'] > 0) {
                            $sconfinoAnnuale = true;
                        }
                    }
                    if ($sconfinoAnnuale) {
                        $arraySconfiniAnnuali[$anno][$risk] = true;
                        $sconfinoAnnuale = false;
                    }
                }
            }
        }

        $sconfiniGeneral = array();
        foreach ($sconfiniPerAnniBanche as $singleYear => $banks) {
            foreach ($banks as $singleBank => $riskType) {
                foreach ($riskType as $singleRisk => $riskRow) {
                    foreach ($riskRow as $singleRiskRow => $riskData) {
                        $sconfiniGeneral[$singleYear][$singleBank][$singleRisk]['TotaleSconfini'] = 0;

                    }
                }
            }
        }
        $tensioniLine = array();
        foreach ($sconfiniPerAnniBanche as $singleYear => $banks) {
            foreach ($banks as $singleBank => $riskType) {
                foreach ($riskType as $singleRisk => $riskRow) {
                    foreach ($riskRow as $singleRiskRow => $riskData) {
                        $sconfiniGeneral[$singleYear][$singleBank][$singleRisk]['TotaleSconfini'] = $sconfiniGeneral[$singleYear][$singleBank][$singleRisk]['TotaleSconfini'] + $riskData['TotaleSconfini'];
                        if ($riskData['TensioneLineaCredito']) {
                            $tensioniLine[$singleYear][$singleRisk] = true;
                        }


                    }
                }
            }
        }

        $singleCR['sconfiniGeneral'] = $sconfiniGeneral;
        $singleCR['cleanCR'] = $cleanCR;
        $singleCR['soldini'] = $soldini;
        $singleCR['tensioniLineCtredito'] = $tensioniLineCtredito;
        $singleCR['arraySconfiniAnnuali'] = $arraySconfiniAnnuali;
        $singleCR['tensioniLine'] = $tensioniLine;

        return $singleCR;
    }

    public function allertaGeneral(){

        $count = 0;

        $crs = cr::select('anno','mese')->get();
        $crData = array();

        $periods = array();
        $mesiList = [0=>'gennaio', 1=>'febbraio', 2=>'marzo',3=>'aprile' ,4=>'maggio', 5=>'giugno', 6=>'luglio', 7=>'agosto', 8=>'settembre', 9=>'ottobre', 10=>'novembre', 11=>'dicembre'];

        foreach ($crs as $data=>$value){
            $periods[$value->anno][$value->mese] = null;
            $periods[$value->anno][$value->mese] = array_search($value->mese, $mesiList);
            asort($periods[$value->anno]);
        }

        ksort($periods);

//
//
//        dd($periods);

        $count = 0;

        $anniMesi = array();

        while ($count < 12){
            $anno = array_key_last($periods);
            $arrayAnno = array_pop($periods);


            if(is_array($arrayAnno)) {

                $dim = count($arrayAnno);

                while ($count < 12 && $dim > 0) {
                    $anniMesi[$anno][array_key_last($arrayAnno)] = array_pop($arrayAnno);

                    $dim = count($arrayAnno);
                    $count++;
                }
            }
        }


//        dd($anniMesi);

        $crUltimoAnno = array();

        foreach ($anniMesi as $anno=>$mesi){
            foreach ($mesi as $mese=>$index){
                $crUltimoAnno[$anno][$mese] = cr::where('anno',$anno)
                    ->where('mese',$mese)
                    ->get();
            }
        }


        $cleanCR = array();

        $rapportiContestati = 0;

        foreach ($crUltimoAnno as $anno=>$mesi){
            foreach ($mesi as $mese=>$items){
                foreach ($items as $item=>$data){
                    $tmp = array();

                    $tmp['Localizzazione'] = $data->localizzazione;
                    $tmp['Durata Originaria'] = $data->durata_originaria;
                    $tmp['Durata Residua'] = $data->durata_residua;
                    $tmp['Divisa'] = $data->divisa;
                    $tmp['Import Export'] = $data->import_export;
                    $tmp['Tipo Attività'] = $data->tipo_attivita;
                    $tmp['Stato Rapporto'] = $data->stato_rapporto;
                    $tmp['Tipo Garanzia'] = $data->tipo_garanzia;
                    $tmp['Ruolo Affidato'] = $data->ruolo_affidato;
                    $tmp['Accordato'] = $data->accordato;
                    $tmp['Accordato Operativo'] = $data->accordato_operativo;
                    $tmp['Utilizzato'] = $data->utilizzato;
                    $tmp['Saldo Medio'] = $data->saldo_medio;
                    $tmp['Importo Garantito'] = $data->importo_garantito;

                    $cleanCR[$data->anno][$data->mese][$data->nome_banca][$data->sezione][$data->categoria][] = $tmp;

                    if (str_contains($data->stato_rapporto, 'non contestati')){
                        $rapportiContestati++;
                    }
                }
            }
        }

        $tensioniAnnuali = array();
        $crediti_perdita = array();
        $sofferenze = array();
        $soldini = array();
        $soldiniConMesi = array();
        $sconfini = array();
        $yearlyDivision = array();
        $sconfiniPerAnniBanche= array();
        $tensioniLineCtredito = array();
        $arrayImpagati = array();
        $arrayScaduti = array();
        $arrayContestati = array();

        $sconfiniAnnoMeseBanca = array();
        $arrayGaranzieRicevute = array();

//        dd($cleanCR);
        $support = array();
        $conteggioMesi = 0;

        foreach($cleanCR as $singleYearKey => $months) {
            $conteggioMesi = 0;
            foreach($months as $singleMonthKey => $banks) {
                $conteggioMesi++;
                foreach($banks as $bankKey => $creditRow) {
                    foreach($creditRow as $singleCreditRowTypeKey => $singleCreditValue) {
                        if($singleCreditRowTypeKey == 'Cassa') {
                            foreach ($singleCreditValue as $credit=>$vals) {
                                foreach ($vals as $key=>$value){
                                    // credit == categoria, value == array con i dati
                                    $Categoria = $credit;
                                    $localizzazione = $value['Localizzazione'];
                                    $durataOriginaria = $value['Durata Originaria'];
                                    $durataResidua = $value['Durata Residua'];
                                    $divisa = $value['Divisa'];
                                    $importExport = $value['Import Export'];
                                    $tipoAttivita = $value['Tipo Attività'];
                                    $statoRapporto = $value['Stato Rapporto'];
                                    $tipoGaranzia = $value['Tipo Garanzia'];
                                    $ruoloAffidato = $value['Ruolo Affidato'];
                                    $accordato = $value['Accordato'];
                                    $accordatoOperativo = $value['Accordato Operativo'];
                                    $utilizzato = $value['Utilizzato'];



                                    $currentRow = $Categoria . ' ' . $accordato . ' ' . $accordatoOperativo . ' ' . $tipoGaranzia;

                                    if (str_contains($statoRapporto, 'Rapporti contestati')){
                                        $arrayContestati[$singleYearKey][$singleMonthKey][$bankKey][$Categoria][$currentRow] = $utilizzato;
                                    }

                                    $isSameRow = false;

                                    if (isset($prevRow)) {
                                        if ($currentRow == $prevRow) {
                                            $isSameRow = true;
                                        }
                                    }

                                    if ($accordato != '') {

                                        if (!array_key_exists($singleYearKey, $sconfiniPerAnniBanche)) {
                                            $sconfiniPerAnniBanche[$singleYearKey] = array();
                                        }

                                        if (!array_key_exists($singleYearKey, $sconfiniAnnoMeseBanca)) {
                                            $sconfiniAnnoMeseBanca[$singleYearKey] = array();
                                        }

                                        if (!array_key_exists($singleMonthKey, $sconfiniAnnoMeseBanca[$singleYearKey])) {
                                            $sconfiniAnnoMeseBanca[$singleYearKey][$singleMonthKey] = array();
                                        }

                                        if (!array_key_exists($bankKey, $sconfiniPerAnniBanche[$singleYearKey])) {
                                            $sconfiniPerAnniBanche[$singleYearKey][$bankKey] = array();
                                        }

                                        if (!array_key_exists($bankKey, $sconfiniAnnoMeseBanca)) {
                                            $sconfiniAnnoMeseBanca[$singleYearKey][$singleMonthKey][$bankKey] = array();
                                        }

                                        if (!array_key_exists($credit, $sconfiniPerAnniBanche[$singleYearKey][$bankKey])) {
                                            $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria] = array();
                                        }

                                        if (!array_key_exists($credit, $sconfiniAnnoMeseBanca)) {
                                            $sconfiniAnnoMeseBanca[$singleYearKey][$singleMonthKey][$bankKey][$Categoria] = array();
                                        }

                                        if (!array_key_exists($currentRow, $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria])) {
                                            $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow] = array();
                                        }

                                        if (!array_key_exists($currentRow, $sconfiniAnnoMeseBanca)) {
                                            $sconfiniAnnoMeseBanca[$singleYearKey][$singleMonthKey][$bankKey][$Categoria][$currentRow]['Presenza'] = false;
                                            $sconfiniAnnoMeseBanca[$singleYearKey][$singleMonthKey][$bankKey][$Categoria][$currentRow]['Utilizzato'] = 0;
                                            $sconfiniAnnoMeseBanca[$singleYearKey][$singleMonthKey][$bankKey][$Categoria][$currentRow]['Accordato Operativo'] = 0;
                                        }

                                    }

                                    if ($utilizzato > $accordatoOperativo) {
                                        // PER BANCHE ANNI

                                        $sconfiniAnnoMeseBanca[$singleYearKey][$singleMonthKey][$bankKey][$Categoria][$currentRow]['Presenza'] = true;
                                        $sconfiniAnnoMeseBanca[$singleYearKey][$singleMonthKey][$bankKey][$Categoria][$currentRow]['Utilizzato'] = $utilizzato;
                                        $sconfiniAnnoMeseBanca[$singleYearKey][$singleMonthKey][$bankKey][$Categoria][$currentRow]['Accordato Operativo'] = $accordatoOperativo;

                                        if (!array_key_exists('TotaleSconfini', $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow])) {

                                            $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TotaleSconfini'] = 1;
                                            $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TensioneLineaCredito'] = false;

                                        } else {

//                                      //SE NON è SETTATA LA SETTO A 1, SE è SETTATA LA INCREMENTO DI 1

                                            if ($sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TotaleSconfini'] < 3) {

                                                //SE NON SIAMO IN SITUAZIONE DI TENSIONE

                                                $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TensioneLineaCredito'] = false;

                                            } else {

                                                //SE SIAMO IN TENSIONE, DICIAMO PER QUALE ANNO E LINEA DI CREDITO

                                                if (!array_key_exists($singleYearKey, $tensioniLineCtredito)) {

                                                    $tensioniLineCtredito[$singleYearKey] = array();

                                                }

                                                $tensioniLineCtredito[$singleYearKey][$Categoria][$currentRow] = true;


                                                $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TensioneLineaCredito'] = true;

                                            }

                                            $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TotaleSconfini'] = ($sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TotaleSconfini'] + 1);
                                            if ($sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TotaleSconfini'] >= 3) {
                                                $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TensioneLineaCredito'] = true;
                                            }
                                        }

                                    } else {

                                        if (!array_key_exists('TotaleSconfini', $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow])) {

                                            $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TotaleSconfini'] = 0;
                                            $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TensioneLineaCredito'] = false;

                                        }

                                        if (!($sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TotaleSconfini'] >= 3)) {

                                            //SE NON SIAMO IN SITUAZIONE DI TENSIONE

                                            $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TensioneLineaCredito'] = false;

                                        } else {

                                            if (!array_key_exists($singleYearKey, $tensioniLineCtredito)) {

                                                $tensioniLineCtredito[$singleYearKey] = array();

                                            }

                                            $tensioniLineCtredito[$singleYearKey][$Categoria][$currentRow] = true;


                                            $sconfiniPerAnniBanche[$singleYearKey][$bankKey][$Categoria][$currentRow]['TensioneLineaCredito'] = true;

                                        }

                                    }

                                    //SE NON HO SCONFINATO
                                    if (str_contains($Categoria, 'SCADENZA')) {
                                        if (isset($value['Tipo Attività'])) {
                                            $TipoAttività = $value['Tipo Attività'];
                                        }
                                    }
                                    $prevRow = $Categoria . ' ' . $accordato . ' ' . $accordatoOperativo . ' ' . $tipoGaranzia;

                                    $prevRow = str_contains($Categoria, 'SCADENZA') ? $currentRow . ' ' . $tipoAttivita : $currentRow;
                                    if (!$isSameRow) {
                                        $soldini[$singleYearKey][$bankKey][$currentRow]['Accordato Operativo'] = str_replace('.', '', $accordatoOperativo);
                                        $soldini[$singleYearKey][$bankKey][$currentRow]['Utilizzato'] = str_replace('.', '', $utilizzato);
                                        $soldiniConMesi[$singleYearKey][$singleMonthKey][$bankKey][$currentRow]['Accordato Operativo'] = str_replace('.', '', $accordatoOperativo);
                                        $soldiniConMesi[$singleYearKey][$singleMonthKey][$bankKey][$currentRow]['Utilizzato'] = str_replace('.', '', $utilizzato);
                                    }
                                }
                            }
                        }
                        // IMPAGATI
                        if($singleCreditRowTypeKey == 'Informativa') {
                            foreach ($singleCreditValue as $credit=>$arrayValori) {
                                foreach ($arrayValori as $data=>$valori){
                                    if (isset($credit)) {
                                        if ($credit == 'SOFFERENZE - CREDITI PASSATI A PERDITA') {
                                            $crediti_perdita[$singleYearKey][$singleMonthKey][$bankKey] = $valori['Importo Garantito'];
                                        }
                                    }
                                    if ($credit == 'RISCHI AUTOLIQUIDANTI - CREDITI SCADUTI'){
                                        if ($valori['Stato Rapporto'] == 'Crediti impagati'){
                                            $arrayScaduti[$singleYearKey][$singleMonthKey][$bankKey][$valori['Stato Rapporto']] = $valori['Importo Garantito'];
                                        }
                                    }
                                    if (isset($valori['Stato Rapporto'])) {
                                        if ($valori['Stato Rapporto'] == 'Crediti impagati') {
                                            $arrayImpagati[$singleYearKey][$singleMonthKey][$bankKey][$valori['Importo Garantito']] = $valori['Importo Garantito'];
                                        }
                                    }
                                }
                            }
                        }
                        if($singleCreditRowTypeKey == 'Sofferenze') {
//                            dump($singleCreditValue);
                            foreach ($singleCreditValue as $credit=>$arrayValori) {
                                foreach ($arrayValori as $data=>$valori){
                                    if (isset($credit)) {
//                                    dd($valori);
                                        $sofferenze[$singleYearKey][$singleMonthKey][$bankKey][$valori['Tipo Garanzia']] = $valori['Utilizzato'];
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

//        dd($arrayContestati);
        //        dd($arrayImpagati, $arrayScaduti);

//dd($cleanCR);
        foreach ($soldini as $anno => $banca){
            foreach ($banca as $nomeBanca=>$val){
                foreach ($val as $data=>$value){
                    if (!isset($soldini[$anno][$nomeBanca]['Totale Accordato Operativo'])){
                        $soldini[$anno][$nomeBanca]['Totale Accordato Operativo'] = 0;
                        $soldini[$anno][$nomeBanca]['Totale Utilizzato'] = 0;
                    }
                    $soldini[$anno][$nomeBanca]['Totale Accordato Operativo'] += $value['Accordato Operativo'];
                    $soldini[$anno][$nomeBanca]['Totale Utilizzato'] += $value['Utilizzato'];
                }
            }
        }

        $sconfinoAnnuale = false;
        $arraySconfiniAnnuali = array();
        $conteggioSconfini = 0;

        foreach ($sconfiniPerAnniBanche as $anno => $arrayBanche){
            foreach ($arrayBanche as $nomeBanca=>$arrayRischi){
                foreach ($arrayRischi as $risk=> $righe) {
                    foreach ($righe as $row=>$tensione){
                        if ($tensione['TotaleSconfini'] > 0){
                            $sconfinoAnnuale = true;
                        }
                    }
                    if ($sconfinoAnnuale){
                        $arraySconfiniAnnuali[$anno][$risk] = true;
                        $sconfinoAnnuale = false;
                    }
                }
            }
        }

        $sconfiniGeneral = array();
        foreach($sconfiniPerAnniBanche as $singleYear => $banks) {
            foreach ($banks as $singleBank => $riskType) {
                foreach ($riskType as $singleRisk => $riskRow) {
                    foreach ($riskRow as $singleRiskRow => $riskData) {
                        $sconfiniGeneral[$singleYear][$singleBank][$singleRisk]['TotaleSconfini'] = 0;
                    }
                }
            }
        }
        $tensioniLine = array();
        foreach($sconfiniPerAnniBanche as $singleYear => $banks) {
            foreach ($banks as $singleBank => $riskType) {
                foreach ($riskType as $singleRisk => $riskRow) {
                    foreach ($riskRow as $singleRiskRow => $riskData) {
                        $sconfiniGeneral[$singleYear][$singleBank][$singleRisk]['TotaleSconfini'] = $sconfiniGeneral[$singleYear][$singleBank][$singleRisk]['TotaleSconfini']+$riskData['TotaleSconfini'];
                        if($riskData['TensioneLineaCredito']) {
                            $tensioniLine[$singleYear][$singleRisk] = true;
                        }
                    }
                }
            }
        }


        $firstYear = array_key_first($periods);

        $lastYear = array_key_last($periods);

      //  $inizioPeriodo = $firstYear.' '.array_key_first($periods[$firstYear]);
       // $finePeriodo = $lastYear.' '.array_key_last($periods[$lastYear]);

        $presenzaEntro90gg = array();
        $presenzaEntro180gg = array();
        $presenzaOltre180gg = array();
        $presenzeGeneral = array();
        $sconfiniAnnoMese = array();
        $contMesi = 0;
        $contSconfini = array();
        $importoSconfini = array();

//        dd($sconfiniAnnoMeseBanca);

        foreach ($sconfiniAnnoMeseBanca as $anno=>$arrayMesi){
            $contMesi = 0;
            foreach ($arrayMesi as $mese=>$arrayBanche){
                $contMesi++;
                foreach ($arrayBanche as $banca=>$lineeCredito){
                    foreach ($lineeCredito as $singolaLinea=>$rows){
                        foreach ($rows as $row=>$data){
                            if ($data['Presenza'] == true){
                                if (!isset($contSconfini[$anno][$banca][$singolaLinea][$row])){
                                    $contSconfini[$anno][$banca][$singolaLinea][$row] = 1;
                                }
                                else{
                                    $contSconfini[$anno][$banca][$singolaLinea][$row] = ($contSconfini[$anno][$banca][$singolaLinea][$row])+1;
                                }
                                if (isset($contSconfini[$anno][$banca][$singolaLinea][$row])){
                                    if ($contSconfini[$anno][$banca][$singolaLinea][$row] == $contMesi){
                                        $presenzaEntro90gg[$anno][$banca][$singolaLinea][$row]['Presenza'] = true;
                                        $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA MENO DI 90 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Utilizzato'] = $data['Utilizzato'];
                                        $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA MENO DI 90 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Importo Sconfinamento'] = $data['Accordato Operativo']-$data['Utilizzato'];

                                        if($data['Accordato Operativo'] == 0){
                                            $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA MENO DI 90 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Accordato nullo';
                                        }

                                        if ($singolaLinea == 'RISCHI A SCADENZA'){
                                            if (($data['Accordato Operativo'] / $data['Utilizzato']) < 1){
                                                $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA MENO DI 90 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Utilizzo anomalo, probabile errata segnalazione';
                                            }
                                            else if(($data['Accordato Operativo'] / $data['Utilizzato']) > 1){
                                                $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA MENO DI 90 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Presenza di rate insolute probabile errata segnalazione';
                                            }
                                        }

                                        if (str_contains($singolaLinea, 'RISCHI AUTOLIQUIDANTI')){
                                            if (($data['Utilizzato'] - $data['Accordato Operativo']) > 0){
                                                $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA MENO DI 90 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Sconfino da verificare, possibile errore di valuta';
                                            }
                                        }

                                    }
                                    if ($contMesi > 3){
                                        if ($contMesi > 6){
                                            if ($contSconfini[$anno][$banca][$singolaLinea][$row] == $contMesi){
                                                $presenzaOltre180gg[$anno][$banca][$singolaLinea][$row]['Presenza'] = true;
                                                //SEGNALINO
                                                $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Utilizzato'] = $data['Utilizzato'];
                                                $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Importo Sconfinamento'] = $data['Accordato Operativo']-$data['Utilizzato'];

                                                if($data['Accordato Operativo'] == 0){
                                                    $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Accordato nullo';
                                                }

                                                if ($singolaLinea == 'RISCHI A SCADENZA'){
                                                    if (($data['Accordato Operativo'] / $data['Utilizzato']) < 1){
                                                        $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Utilizzo anomalo, probabile errata segnalazione';
                                                    }
                                                    else if(($data['Accordato Operativo'] / $data['Utilizzato']) > 1){
                                                        $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Presenza di rate insolute probabile errata segnalazione';
                                                    }
                                                }

                                                if (str_contains($singolaLinea,'RISCHI AUTOLIQUIDANTI')){
                                                    if (($data['Utilizzato'] - $data['Accordato Operativo']) > 0){
                                                        $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Sconfino da verificare, possibile errore di valuta';
                                                    }
                                                }
                                            }
                                        }
                                        else if ($contSconfini[$anno][$banca][$singolaLinea][$row] == $contMesi){
                                            $presenzaEntro180gg[$anno][$banca][$singolaLinea][$row]['Presenza'] = true;
                                            $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 90 GIORNI E MENO DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Utilizzato'] = $data['Utilizzato'];
                                            $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 90 GIORNI E MENO DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Importo Sconfinamento'] = $data['Accordato Operativo']-$data['Utilizzato'];

                                            if($data['Accordato Operativo'] == 0){
                                                $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 90 GIORNI E MENO DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Accordato nullo';
                                            }

                                            if ($singolaLinea == 'RISCHI A SCADENZA'){
                                                if (($data['Accordato Operativo'] / $data['Utilizzato']) < 1){
                                                    $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 90 GIORNI E MENO DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Utilizzo anomalo, probabile errata segnalazione';
                                                }
                                                else if(($data['Accordato Operativo'] / $data['Utilizzato']) > 1){
                                                    $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 90 GIORNI E MENO DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Presenza di rate insolute probabile errata segnalazione';
                                                }
                                            }

                                            if (str_contains($singolaLinea,'RISCHI AUTOLIQUIDANTI')){
                                                if (($data['Utilizzato'] - $data['Accordato Operativo']) > 0){
                                                    $importoSconfini['ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 90 GIORNI E MENO DI 180 GIORNI'][$anno][$mese][$banca][$singolaLinea][$row]['Tipo errata segnalazione'] = 'Sconfino da verificare, possibile errore di valuta';
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

//        dd($importoSconfini);

        $analisiIndebitamento = array();

        foreach($soldiniConMesi as $singleYear=>$multipleMonths){
            foreach ($multipleMonths as $singleMonth=>$multipleBanks){
                foreach($multipleBanks as $singleBank=>$data) {
                    foreach ($data as $key=>$value){
                        if (str_contains($key, 'A SCADENZA')){
                            if (!isset($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A SCADENZA']['Accordato Operativo']) && !isset($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A SCADENZA']['Utilizzato'])){
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A SCADENZA']['Accordato Operativo'] = 0;
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A SCADENZA']['Utilizzato'] = 0;
                            }
                            else{
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A SCADENZA']['Accordato Operativo'] = ($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A SCADENZA']['Accordato Operativo'])+$value['Accordato Operativo'];
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A SCADENZA']['Utilizzato'] = ($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A SCADENZA']['Accordato Operativo'])+$value['Accordato Operativo'];
                            }
                        }
                        if (str_contains($key, 'A REVOCA')){
                            if (!isset($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A REVOCA']['Accordato Operativo']) && !isset($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A REVOCA']['Utilizzato'])){
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A REVOCA']['Accordato Operativo'] = 0;
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A REVOCA']['Utilizzato'] = 0;
                            }
                            else{
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A REVOCA']['Accordato Operativo'] = ($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A REVOCA']['Accordato Operativo'])+$value['Accordato Operativo'];
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A REVOCA']['Utilizzato'] = ($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI A REVOCA']['Accordato Operativo'])+$value['Accordato Operativo'];
                            }
                        }
                        if (str_contains($key, 'AUTOLIQUIDANTI')){
                            if (!isset($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI AUTOLIQUIDANTI - CREDITI SCADUTI']['Accordato Operativo']) && !isset($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI AUTOLIQUIDANTI - CREDITI SCADUTI']['Utilizzato'])){
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI AUTOLIQUIDANTI - CREDITI SCADUTI']['Accordato Operativo'] = 0;
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI AUTOLIQUIDANTI - CREDITI SCADUTI']['Utilizzato'] = 0;
                            }
                            else{
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI AUTOLIQUIDANTI - CREDITI SCADUTI']['Accordato Operativo'] = ($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI AUTOLIQUIDANTI']['Accordato Operativo'])+$value['Accordato Operativo'];
                                $analisiIndebitamento[$singleYear][$singleMonth]['RISCHI AUTOLIQUIDANTI - CREDITI SCADUTI']['Utilizzato'] = ($analisiIndebitamento[$singleYear][$singleMonth]['RISCHI AUTOLIQUIDANTI']['Accordato Operativo'])+$value['Accordato Operativo'];
                            }
                        }
                    }
                }
            }
        }

        $arraySofferenze = array();

        foreach ($sofferenze as $singoloAnno=>$arrayMesi){
            foreach ($arrayMesi as $singoloMese=>$arrayBanche){
                $arraySofferenze[$singoloAnno][$singoloMese] = 0;
                foreach ($arrayBanche as $rows){
                    foreach ($rows as $rowKey=>$rowValue){
                        $arraySofferenze[$singoloAnno][$singoloMese] = ($arraySofferenze[$singoloAnno][$singoloMese])+$rowValue;
                    }
                }
            }
        }

        $arrayCreditiPerdita = array();

        foreach ($crediti_perdita as $singoloAnno=>$arrayMesi){
            foreach ($arrayMesi as $singoloMese=>$arrayBanche){
                $arrayCreditiPerdita[$singoloAnno][$singoloMese] = 0;
                foreach ($arrayBanche as $singolaBanca=>$bancaValue){
                    $arrayCreditiPerdita[$singoloAnno][$singoloMese] = ($arrayCreditiPerdita[$singoloAnno][$singoloMese])+$bancaValue;
                }
            }
        }

        $mesiContestati = array();

        foreach ($arrayContestati as $singoloAnno=>$arrayMesi){
            foreach ($arrayMesi as $singoloMese=>$arrayBanche){
                $mesiContestati[$singoloAnno][$singoloMese] = 0;
                foreach ($arrayBanche as $singolaBanca=>$arrayCategoria){
                    foreach ($arrayCategoria as $singolaCategoria=>$multipleRows){
                        foreach ($multipleRows as $singleRow=>$data){
                            $mesiContestati[$singoloAnno][$singoloMese] = ($mesiContestati[$singoloAnno][$singoloMese])+$data;
                        }
                    }
                }
            }
        }

        $scadutiPerMese = array();

        foreach ($arrayScaduti as $singoloAnno=>$arrayMesi){
            foreach ($arrayMesi as $singoloMese=>$arrayBanche){
                $scadutiPerMese[$singoloAnno][$singoloMese] = 0;
                foreach ($arrayBanche as $singolaBanca=>$bancaValue){
                    $scadutiPerMese[$singoloAnno][$singoloMese] = ($scadutiPerMese[$singoloAnno][$singoloMese])+$bancaValue['Crediti impagati'];
                }
            }
        }

        $arrayImpagatiGeneral = array();

        foreach ($arrayImpagati as $singoloAnno=>$arrayMesi){
            foreach ($arrayMesi as $singoloMese=>$arrayBanche){
                $arrayImpagatiGeneral[$singoloAnno][$singoloMese] = 0;
                foreach ($arrayBanche as $singolaBanca=>$bancaValue){
                    foreach ($bancaValue as $key=>$val){
                        $arrayImpagatiGeneral[$singoloAnno][$singoloMese] = ($arrayImpagatiGeneral[$singoloAnno][$singoloMese])+$key;
                    }
                }
            }
        }
//        dd($arrayImpagatiGeneral);

//        dd($analisiIndebitamento);

        $arrayIndebitamentoEntro180 = array();
        $arrayIndebitamentoOltre180 = array();

        //        dd($importoSconfini);

        foreach ($importoSconfini as $differentPeriods=>$differentYears){
            if ($differentPeriods == 'ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 90 GIORNI E MENO DI 180 GIORNI'){
                foreach ($differentYears as $singleYear=>$multipleMonths){
                    foreach ($multipleMonths as $singleMonth=>$multipleBanks){
                        $arrayIndebitamentoEntro180[$singleYear][$singleMonth] = 0;
                        foreach ($multipleBanks as $singleBank=>$multipleCreditLines){
                            foreach ($multipleCreditLines as $singleLine=>$multipleRows){
                                foreach ($multipleRows as $singleRow=>$data){
                                    $arrayIndebitamentoEntro180[$singleYear][$singleMonth] = ($arrayIndebitamentoEntro180[$singleYear][$singleMonth]) + $data['Importo Sconfinamento'];
                                }
                            }
                        }
                    }
                }
            }
            if ($differentPeriods == 'ERRATE SEGNALAZIONI: SCONF. DA PIÙ DI 180 GIORNI'){
                foreach ($differentYears as $singleYear=>$multipleMonths){
                    foreach ($multipleMonths as $singleMonth=>$multipleBanks){
                        $arrayIndebitamentoEntro180[$singleYear][$singleMonth] = 0;
                        foreach ($multipleBanks as $singleBank=>$multipleCreditLines){
                            foreach ($multipleCreditLines as $singleLine=>$multipleRows){
                                foreach ($multipleRows as $singleRow=>$data){
                                    $arrayIndebitamentoOltre180[$singleYear][$singleMonth] = ($arrayIndebitamentoEntro180[$singleYear][$singleMonth]) + $data['Importo Sconfinamento'];
                                }
                            }
                        }
                    }
                }
            }
        }

        $tensioni = array();

        foreach ($sconfiniPerAnniBanche as $anno=>$banche){
            foreach ($banche as $banca=>$creditLines) {
                foreach ($creditLines as $lineaCredito=>$rows){
                    foreach ($rows as $row=>$value){
                        if (isset($value['TensioneLineaCredito']) && $value['TensioneLineaCredito'] == true){
                            $tensioni[$lineaCredito] = true;
                        }
                    }
                }
            }
        }

        $sconfiniScadenza = 0;
        $sconfiniRevoca = 0;
        $sconfiniAutoliquidanti = 0;

        foreach($sconfiniGeneral as $anno=>$banks){
            foreach ($banks as $banca=>$lineeCredito){
                foreach ($lineeCredito as $data=>$value){
                    if ($data == 'RISCHI A SCADENZA' && $value['TotaleSconfini'] != 0){
                        $sconfiniScadenza += $value['TotaleSconfini'];
                    }
                    if ($data == 'RISCHI A REVOCA' && $value['TotaleSconfini'] != 0){
                        $sconfiniRevoca += $value['TotaleSconfini'];
                    }
                    if ($data == 'RISCHI AUTOLIQUIDANTI' && $value['TotaleSconfini'] != 0){
                        $sconfiniAutoliquidanti += $value['TotaleSconfini'];
                    }
                }
            }
        }

        $presenzaSconfini = !(($sconfiniScadenza == 0 && $sconfiniRevoca == 0 && $sconfiniAutoliquidanti == 0));

        $scoreCR = 0;
        if (!isset($tensioni['RISCHI A REVOCA'])){
            $scoreCR += 0.55;
        }

        if (!isset($tensioni['RISCHI AUTOLIQUIDANTI'])){
            $scoreCR += 0.55;
        }

        if (!isset($tensioni['RISCHI A SCADENZA'])){
            $scoreCR += 0.55;
        }

        if (count($arrayImpagati)<1){
            $scoreCR += 1;
        }

        if (!$presenzaSconfini){
            $scoreCR += 1;
        }

        if (count($presenzaEntro180gg)<1){
            $scoreCR +=1.1;
        }

        if (count($presenzaOltre180gg)<1){
            $scoreCR += 1.2;
        }

        if (count($sofferenze)<1){
            $scoreCR += 1.35;
        }
        if (count($crediti_perdita)<1){
            $scoreCR += 1.35;
        }

        //INIZIO CR SISTEMA ALLERTA

        $analisiCRsistemaAllerta = 0;
        $alerts = array();
        $accordatoOperativoPerMeseBanca = array();

        foreach ($soldiniConMesi as $anno=>$mesi){
            foreach ($mesi as $mese=>$banche){
                foreach ($banche as $banca=>$rows){
                    $accordatoOperativoPerBanca[$anno][$banca]['RISCHI A REVOCA'] = 0;
                    $accordatoOperativoPerBanca[$anno][$banca]['RISCHI A SCADENZA'] = 0;
                    $accordatoOperativoPerBanca[$anno][$banca]['RISCHI AUTOLIQUIDANTI'] = 0;
                    $accordatoOperativoPerMeseBanca[$anno][$mese][$banca]['RISCHI A SCADENZA'] = 0;
                    $accordatoOperativoPerMeseBanca[$anno][$mese][$banca]['RISCHI A REVOCA'] = 0;
                    $accordatoOperativoPerMeseBanca[$anno][$mese][$banca]['RISCHI AUTOLIQUIDANTI'] = 0;

                    foreach ($rows as $row=>$data){
                        if (str_contains($row, 'REVOCA')){
                            $accordatoOperativoPerBanca[$anno][$banca]['RISCHI A REVOCA'] = ($accordatoOperativoPerBanca[$anno][$banca]['RISCHI A REVOCA'])+$data['Accordato Operativo'];
                            $accordatoOperativoPerMeseBanca[$anno][$mese][$banca]['RISCHI A REVOCA'] = ($accordatoOperativoPerMeseBanca[$anno][$mese][$banca]['RISCHI A REVOCA'])+$data['Accordato Operativo'];
                        }
                        if (str_contains($row, 'SCADENZA')){
                            $accordatoOperativoPerBanca[$anno][$banca]['RISCHI A SCADENZA'] = ($accordatoOperativoPerBanca[$anno][$banca]['RISCHI A SCADENZA'])+$data['Accordato Operativo'];
                            $accordatoOperativoPerMeseBanca[$anno][$mese][$banca]['RISCHI A SCADENZA'] = ($accordatoOperativoPerMeseBanca[$anno][$mese][$banca]['RISCHI A SCADENZA'])+$data['Accordato Operativo'];
                        }
                        if (str_contains($row, 'AUTOLIQUIDANTI')){
                            $accordatoOperativoPerBanca[$anno][$banca]['RISCHI AUTOLIQUIDANTI'] = ($accordatoOperativoPerBanca[$anno][$banca]['RISCHI AUTOLIQUIDANTI'])+$data['Accordato Operativo'];
                            $accordatoOperativoPerMeseBanca[$anno][$mese][$banca]['RISCHI AUTOLIQUIDANTI'] = ($accordatoOperativoPerMeseBanca[$anno][$mese][$banca]['RISCHI AUTOLIQUIDANTI'])+$data['Accordato Operativo'];
                        }
                    }
                }
            }
        }

        // VALUTAZIONE INDICE 1

        if ($scoreCR<=5){
            $analisiCRsistemaAllerta += 0.4;
            $alerts['1'] = true;
        }

        // VALUTAZIONE INDICE 2

        $esposizioneMediaAziendale = array();

        foreach ($soldini as $anno=>$banche){
            foreach ($banche as $banca=>$data){
                if (!isset($esposizioneMediaAziendale[$banca])){
                    $esposizioneMediaAziendale[$banca] = 0;
                }
                $esposizioneMediaAziendale[$banca] = ($esposizioneMediaAziendale[$banca])+$data['Totale Accordato Operativo'];
            }
        }

        foreach ($esposizioneMediaAziendale as $bank=>$value){
            $esposizioneMediaAziendale[$bank] = $value/12;
        }

        $nSconfininelPeriodo = array();

        $sconfiniSignificativi = array();

        foreach($sconfiniAnnoMeseBanca as $singleYear=>$monthsArray){
            foreach($monthsArray as $singleMonth=>$banksArray){
                foreach ($banksArray as $singleBank=>$creditLines){
                    foreach ($creditLines as $singleLine=>$rows){
                        $nSconfininelPeriodo[$singleYear][$singleBank][$singleLine] = 0;
                        foreach ($rows as $row=>$data){
                            if ((float)$data['Utilizzato'] - (float)$data['Accordato Operativo'] > ($esposizioneMediaAziendale[$singleBank]/100)){
                                $sconfiniSignificativi[$singleYear][$singleMonth][$singleBank][$singleLine] = true;
                                $alerts['2'][$singleBank][$singleLine] = true;
                                $nSconfininelPeriodo[$singleYear][$singleBank][$singleLine] = ($nSconfininelPeriodo[$singleYear][$singleBank][$singleLine])+1;
                            }
                        }
                        if($nSconfininelPeriodo[$singleYear][$singleBank][$singleLine] > 3){
                            $alerts['2'][$singleBank][$singleLine] = true;
                        }
                    }
                }
            }
        }

        // VALUTAZIONE INDICE 3

        $criticitaNumeroSconfini = array();
        $criticitaNumeroSconfiniScadenza = array();

        foreach ($nSconfininelPeriodo as $anno=>$banche){
            foreach ($banche as $banca=>$linee){
                foreach ($linee as $linea=>$value){
                    if (!isset($conteggio[$banca][$linea])){
                        $conteggio[$banca][$linea] = 0;
                    }
                    if ($value){
                        $conteggio[$banca][$linea] = ($conteggio[$banca][$linea])+1;
                        if ($conteggio[$banca][$linea]>=3){
                            $criticitaNumeroSconfini[$banca][$linea] = true;
                            if(str_contains($linea,'SCADENZA')){
                                $criticitaNumeroSconfiniScadenza[$banca][$linea] = true;
                                $alerts['3'][$banca] = true;
                            }
                        }
                    }
                }
            }
        }

        // VALUTAZIONE INDICE 4

        //

        // VALUTAZIONE INDICI 5 E 15

        // INDICI 5 E 15

        $counterAumentoGaranzie = array();
        $arrayGaranzieAttivateNegative = array();

        foreach ($arrayGaranzieRicevute as $singleYear=>$multipleMonths){
            foreach ($multipleMonths as $singleMonth=>$multipleBanks){
                foreach ($multipleBanks as $singleBank=>$data){
                    if (str_contains($data['Stato Rapporto'], 'esito negativo')){
                        $alerts['15'][$singleBank] = true;
                    }
                    $currentGaranziaRicevuta[$singleYear][$singleMonth][$singleBank] = $data['Importo Garantito'];
                    if (!isset($previousGaranziaRicevuta[$singleYear][$singleMonth][$singleBank])){
                        $previousGaranziaRicevuta[$singleYear][$singleMonth][$singleBank] = $data['Importo Garantito'];
                    }
                    else{
                        if ($currentGaranziaRicevuta[$singleYear][$singleMonth][$singleBank] > $previousGaranziaRicevuta[$singleYear][$singleMonth][$singleBank]){
                            if (!isset($counterAumentoGaranzie[$singleBank])){
                                $counterAumentoGaranzie[$singleBank] = 0;
                            }
                            $counterAumentoGaranzie[$singleBank] = ($counterAumentoGaranzie[$singleBank])+1;
                            if ($counterAumentoGaranzie[$singleBank] > 2){
                                $alerts['5'][$singleBank] = true;
                            }
                        }
                    }
                    $previousGaranziaRicevuta[$singleYear][$singleMonth][$singleBank] = $data['Importo Garantito'];
                }
            }
        }

        //

        // VALUTAZIONE INDICE 6

        $utilizzatoPerMeseBanca = array();

        foreach ($soldiniConMesi as $singleYear=>$multipleMonths){
            foreach ($multipleMonths as $singleMonth=>$multipleBanks){
                foreach ($multipleBanks as $singleBank=>$rows){
                    $utilizzatoPerBanca[$singleBank] = 0;
                    foreach ($rows as $row=>$data){
                        if (!isset($utilizzatoPerBanca[$singleBank])){
                            $utilizzatoPerBanca[$singleBank] = 0;
                            $utilizzatoPerMeseBanca[$singleYear][$singleMonth][$singleBank] = 0;
                        }
                        $utilizzatoPerBanca[$singleBank] = ($utilizzatoPerBanca[$singleBank])+$data['Utilizzato'];
                        $utilizzatoPerMeseBanca[$singleYear][$singleMonth][$singleBank] = $data['Utilizzato'];
                    }
                }
            }
        }

        $impagatiPerBanca = array();
        $impagatiPerBancaMese = array();

        foreach ($arrayImpagati as $anno=>$mesi){
            foreach ($mesi as $mese=>$banche){
                $currMonth = $mese;
                if (!isset($prevMonth)){
                    $prevMonth = $currMonth;
                }
                foreach ($banche as $banca=>$data){
                    if(!isset($impagatiCount[$banca])){
                        $impagatiCount[$banca] = 0;
                    }
                    foreach ($data as $index=>$value){
                        if (!isset($impagatiPerBanca[$banca])){
                            $impagatiPerBanca[$banca] = 0;
                        }
                        $impagatiPerBanca[$banca] = ($impagatiPerBanca[$banca])+$value;
                        $impagatiPerBancaMese[$anno][$mese][$banca] = $value;
                        if ($impagatiPerBancaMese[$anno][$currMonth][$banca] > $impagatiPerBancaMese[$anno][$prevMonth][$banca]){
                            $impagatiCount[$banca] = ($impagatiCount[$banca])+1;
                        }
                        if ($impagatiCount[$banca] >= 3){
                            $alerts['6'][$banca] = true;
                        }
                    }
                }
            }
        }

        $scadutiPerBanca = array();

        foreach ($arrayScaduti as $singleYear=>$multipleMonths){
            foreach ($multipleMonths as $singleMonth=>$multipleBanks){
                foreach($multipleBanks as $singleBank=>$data){
                    if (!isset($scadutiPerBanca[$singleBank])){
                        $scadutiPerBanca[$singleBank] = 0;
                    }
                    $scadutiPerBanca[$singleBank] = ($scadutiPerBanca[$singleBank])+$data['Crediti impagati'];
                }
            }
        }

        foreach ($utilizzatoPerBanca as $banca=>$utilizzato){
            if (isset($scadutiPerBanca[$banca])){
                if ($scadutiPerBanca[$banca] > ($utilizzatoPerBanca[$banca]/4)){
                    $alerts['6'][$banca] = true;
                }
            }
            if (isset($impagatiPerBanca[$banca])){
                if ($impagatiPerBanca[$banca] > ($utilizzatoPerBanca[$banca]/4)){
                    $alerts['6'][$banca] = true;
                }
            }
        }

        $utilizzatoMedioPerBanca = array();

        foreach ($utilizzatoPerBanca as $banca=>$utilizzato){
            $utilizzatoMedioPerBanca[$banca] = $utilizzato/12;
        }

        //

        // VALUTAZIONE 7

        $conteggioAumentoAccordatoNeiMesi = array();
        $valoreAumentoMensileAccordato = array();


        foreach ($soldiniConMesi as $singleYear=>$multipleMonths){
            unset($previousRow, $previousMonth, $currentRow, $currentMonth);
            foreach ($multipleMonths as $singleMonth=>$multipleBanks){
                $currentMonth = $singleMonth;
                foreach ($multipleBanks as $singleBank=>$rows){
                    $conteggioAumentoAccordatoNeiMesi[$singleYear][$singleBank] = 0; //array importante
                    foreach ($rows as $row=>$data){
                        if (!str_contains($row, 'AUTOLIQUIDANTI')) {
                            $currentRow = $row;

                            if (!isset($previousRow)) {
                                $previousRow = $currentRow;
                            }

                            if (!isset($previousMonth)) {
                                $previousMonth = $currentMonth;
                            }
                            if ($currentMonth != $previousMonth && $currentRow != $previousRow) {
                                if (isset($soldiniConMesi[$singleYear][$currentMonth][$singleBank][$currentRow]) && isset($soldiniConMesi[$singleYear][$previousMonth][$singleBank][$previousRow])) {
                                    if ($soldiniConMesi[$singleYear][$currentMonth][$singleBank][$currentRow]['Accordato Operativo'] > $soldiniConMesi[$singleYear][$previousMonth][$singleBank][$previousRow]['Accordato Operativo']) {
                                        $conteggioAumentoAccordatoNeiMesi[$singleYear][$singleBank] = ($conteggioAumentoAccordatoNeiMesi[$singleYear][$singleBank])+1;
                                        $valoreAumentoMensileAccordato[$singleBank][$singleMonth] = $soldiniConMesi[$singleYear][$currentMonth][$singleBank][$currentRow]['Accordato Operativo'] - $soldiniConMesi[$singleYear][$previousMonth][$singleBank][$previousRow]['Accordato Operativo'];
                                        if ($valoreAumentoMensileAccordato[$singleBank][$singleMonth] > ($soldiniConMesi[$singleYear][$currentMonth][$singleBank][$currentRow]['Accordato Operativo']*25/100) || $conteggioAumentoAccordatoNeiMesi[$singleYear][$singleBank] > 3){
                                            $alerts['7'][$singleBank] = true;
                                        }
                                    }
                                }
                            }
                            $previousRow = $currentRow;
                        }
                    }
                }
            }
            $previousMonth = $currentMonth;
        }

        //

        // VALUTAIZIONE INDICE 8

        foreach ($accordatoOperativoPerMeseBanca as $singleYear=>$multipleMonths){
            foreach ($multipleMonths as $singleMonth=>$multipleBanks){
                $currMonth = $singleMonth;
                if (!isset($prevMonth)){
                    $prevMonth = $currMonth;
                }
                foreach ($multipleBanks as $singleBank=>$data){
                    if (isset($accordatoOperativoPerMeseBanca[$singleYear][$currMonth][$singleBank]['RISCHI A SCADENZA']) && isset($accordatoOperativoPerMeseBanca[$singleYear][$prevMonth][$singleBank]['RISCHI A SCADENZA'])) {
                        if ($accordatoOperativoPerMeseBanca[$singleYear][$currMonth][$singleBank]['RISCHI A SCADENZA'] > $accordatoOperativoPerMeseBanca[$singleYear][$prevMonth][$singleBank]['RISCHI A SCADENZA']) {
                            if (($accordatoOperativoPerMeseBanca[$singleYear][$currMonth][$singleBank]['RISCHI A SCADENZA'] - $accordatoOperativoPerMeseBanca[$singleYear][$prevMonth][$singleBank]['RISCHI A SCADENZA']) > ($accordatoOperativoPerMeseBanca[$singleYear][$prevMonth][$singleBank]['RISCHI A SCADENZA'] / 5)) {
                                $alerts['8'][$singleBank] = true;
                            }
                        }
                    }
                }
            }
        }

        //

        // VALUTAZIONE INDICE 9

        foreach ($utilizzatoPerMeseBanca as $singleYear=>$multipleMonths){
            foreach ($multipleMonths as $singleMonth=>$multipleBanks){
                $currentUtilizzatoMonth = $singleMonth;
                foreach ($multipleBanks as $singleBank=>$value){
                    if (!isset($previousUtilizzatoMonth)){
                        $previousUtilizzatoMonth = $currentUtilizzatoMonth;
                    }
                    if (isset($utilizzatoPerMeseBanca[$singleYear][$currentUtilizzatoMonth][$singleBank]) && isset($utilizzatoPerMeseBanca[$singleYear][$previousUtilizzatoMonth][$singleBank])){
                        if ($utilizzatoPerMeseBanca[$singleYear][$currentUtilizzatoMonth][$singleBank] > $utilizzatoPerMeseBanca[$singleYear][$previousUtilizzatoMonth][$singleBank]){
                            $aumentiUtilizzato[$singleYear][$currentUtilizzatoMonth][$singleBank] = $utilizzatoPerMeseBanca[$singleYear][$currentUtilizzatoMonth][$singleBank] - $utilizzatoPerMeseBanca[$singleYear][$previousUtilizzatoMonth][$singleBank];
                            if (!($aumentiUtilizzato[$singleYear][$currentUtilizzatoMonth][$singleBank] > $utilizzatoPerMeseBanca[$singleYear][$currentUtilizzatoMonth][$singleBank]/5)){
                                unset($aumentiUtilizzato[$singleYear][$currentUtilizzatoMonth][$singleBank]);
                            }
                            else{
                                $alerts['9'][$singleBank] = true;
                            }
                        }
                    }
                }
                $previousUtilizzatoMonth = $currentUtilizzatoMonth;
            }
        }

        $valoreMedioAccordatoPerBanca = array();

        foreach ($valoreAumentoMensileAccordato as $singleBank=>$multipleMonths){
            $valoreMedioAccordatoPerBanca[$singleBank] = 0;
            foreach ($multipleMonths as $singleMonth=>$value){
                $valoreMedioAccordatoPerBanca[$singleBank] = ($valoreMedioAccordatoPerBanca[$singleBank])+$value;
            }
        }

        foreach ($valoreMedioAccordatoPerBanca as $banca=>$valore){
            $valoreMedioAccordatoPerBanca[$banca] = $valore/12;
        }


        $accordatoMedioMensile = array();
        $utilizzatoPerBanca = array();
        $rowCount= 0;

        foreach ($soldiniConMesi as $singleYear=>$multipleMonths){
            foreach ($multipleMonths as $singleMonth=>$multipleBanks){
                foreach ($multipleBanks as $singleBank=>$rows){
                    $accordatoMedioMensile[$singleYear][$singleMonth][$singleBank] = 0;
                    foreach ($rows as $row=>$data){
                        $rowCount++;
                        if (!isset($accordatoMedioMensile[$singleYear][$singleMonth][$singleBank])){
                            $accordatoMedioMensile[$singleYear][$singleMonth][$singleBank] = 0;
                        }
                        $accordatoMedioMensile[$singleYear][$singleMonth][$singleBank] = ($accordatoMedioMensile[$singleYear][$singleMonth][$singleBank])+$data['Accordato Operativo'];
                    }
                    $accordatoMedioMensile[$singleYear][$singleMonth][$singleBank] = ($accordatoMedioMensile[$singleYear][$singleMonth][$singleBank])/$rowCount;
                }
            }
        }

        //

        // VALUTAZIONE INDICE 10

        $accordatoOperativoPerBanca = array();
        $alertSupport = array();

        foreach ($accordatoOperativoPerMeseBanca as $singleYear=>$multipleMonths){
            foreach ($multipleMonths as $singleMonth=>$multipleBanks){
                foreach ($multipleBanks as $singleBank=>$multipleLines){
                    $currentMonth = $singleMonth;
                    if (!isset($previousMonth)){
                        $previousMonth = $currentMonth;
                    }
                    if (isset($accordatoOperativoPerMeseBanca[$singleYear][$currentMonth][$singleBank]['RISCHI AUTOLIQUIDANTI']) && isset($accordatoOperativoPerMeseBanca[$singleYear][$previousMonth][$singleBank]['RISCHI AUTOLIQUIDANTI'])) {
                        if ($accordatoOperativoPerMeseBanca[$singleYear][$currentMonth][$singleBank]['RISCHI AUTOLIQUIDANTI'] > $accordatoOperativoPerMeseBanca[$singleYear][$previousMonth][$singleBank]['RISCHI AUTOLIQUIDANTI']) {
                            if (($accordatoOperativoPerMeseBanca[$singleYear][$currentMonth][$singleBank]['RISCHI AUTOLIQUIDANTI'] - $accordatoOperativoPerMeseBanca[$singleYear][$previousMonth][$singleBank]['RISCHI AUTOLIQUIDANTI']) > ($accordatoOperativoPerMeseBanca[$singleYear][$currentMonth][$singleBank]['RISCHI AUTOLIQUIDANTI'] / 15 * 100)) {
                                if (!isset($alerts['10'][$singleBank])) {
                                    $alertSupport[$singleBank] = 0;
                                } else {
                                    $alertSupport[$singleBank] = ($alertSupport[$singleBank]) + 1;
                                    if ($alertSupport[$singleBank] > 4){

                                    }
                                }
                            }
                        }
                    }
                    $previousMonth = $currentMonth;
                }
            }
        }

        $rapportoUtilizzatoAccordatoAutoliquidanti = array();
        $rapportoAutoLiqMedio = array();

        foreach ($accordatoOperativoPerMeseBanca as $singleYear=>$multipleMonths){
            foreach ($multipleMonths as $singleMonth=>$multipleBanks){
                foreach ($multipleBanks as $singleBank=>$multipleLines){
                    if($utilizzatoPerMeseBanca[$singleYear][$singleMonth][$singleBank] == 0){
                        $rapportoUtilizzatoAccordatoAutoliquidanti[$singleYear][$singleMonth][$singleBank] = 0;
                    }
                    else{
                        $rapportoUtilizzatoAccordatoAutoliquidanti[$singleYear][$singleMonth][$singleBank] = $multipleLines['RISCHI AUTOLIQUIDANTI']/$utilizzatoPerMeseBanca[$singleYear][$singleMonth][$singleBank];
                        if (!isset($rapportoAutoLiqMedio[$singleBank])){
                            $rapportoAutoLiqMedio[$singleBank] = 0;
                        }
                        $rapportoAutoLiqMedio[$singleBank] = $rapportoUtilizzatoAccordatoAutoliquidanti[$singleYear][$singleMonth][$singleBank];
                    }
                }
            }
        }

        foreach ($rapportoAutoLiqMedio as $bank=>$rapporto){
            if ($rapporto == 0.98){
                $alerts['10'][$bank] = true;
            }
        }

        //

        // VALUTAZIONE INDICI 11, 12, 13



        //

        // VALUTAZIONE INDICE 14



        //

        $annoRiferimento = array_key_first($anniMesi);
        $mesiAnno = array_pop($anniMesi);

        $contatoreSupporto = 0;

        foreach ($mesiAnno as $mese=>$valore) {
            if ($contatoreSupporto > 1) {
                continue;
            }
            if (!$contatoreSupporto) {
                $lastMonthofPeriod = $mese;
            } else if ($contatoreSupporto == 1) {
                $penultimoMese = $mese;
            }
            else if ($contatoreSupporto == 2){
                $terzultimoMese = $mese;
            }
            $contatoreSupporto++;
        }

        $accordatoMedioMensile = array();
        $rowCount= 0;

        foreach ($soldiniConMesi as $singleYear=>$multipleMonths){
            foreach ($multipleMonths as $singleMonth=>$multipleBanks){
                foreach ($multipleBanks as $singleBank=>$rows){
                    $accordatoMedioMensile[$singleYear][$singleMonth][$singleBank] = 0;
                    foreach ($rows as $row=>$data){
                        $rowCount++;
                        if (!isset($accordatoMedioMensile[$singleYear][$singleMonth][$singleBank])){
                            $accordatoMedioMensile[$singleYear][$singleMonth][$singleBank] = 0;
                        }
                        $accordatoMedioMensile[$singleYear][$singleMonth][$singleBank] = ($accordatoMedioMensile[$singleYear][$singleMonth][$singleBank])+$data['Accordato Operativo'];
                    }
                    $accordatoMedioMensile[$singleYear][$singleMonth][$singleBank] = ($accordatoMedioMensile[$singleYear][$singleMonth][$singleBank])/$rowCount;
                    $rowCount= 0;
                }
            }
        }

        // VALUTAZIONE INDICE 16

        if (count($arraySofferenze)==0 || count($arrayCreditiPerdita)==0){
            $alerts['16'] = true;
        }

        $arrayQuestionario = array();

        $questionario = DB::table('questionario')->get();
        foreach ($questionario as $item=>$data){
            $arrayQuestionario[$data->parameter]['Result'] = $data->result;
            $arrayQuestionario[$data->parameter]['Details'] = $data->details == null ? '' : $data->details;
        }

        $arrayForwardLooking = array();

        $forwardLooking = DB::table('forwardLooking')->get();
        foreach ($forwardLooking as $item=>$data){
            $arrayForwardLooking[$data->question] = $data->answer;
        }

        return view('allerta.general', compact(['alerts','arrayQuestionario','arrayForwardLooking']));
    }


}
