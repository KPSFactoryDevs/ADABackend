<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Bilanci;

/**
 * Class DashboardController.
 */
class DashboardController extends Controller
{
    /**
     * @return \Illuminate\View\View
     */
    public function index()
    {


        $bilancis = Bilanci::paginate(25);

        return view('backend.dashboard', compact('bilancis'));
    }
}
